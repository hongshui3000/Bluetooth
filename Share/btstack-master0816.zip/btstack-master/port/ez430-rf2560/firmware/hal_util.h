#ifndef __HAL_UTIL_H
#define __HAL_UTIL_H


#endif // __HAL_UTIL_H
