


- iBeacon example:

    - [iBeacon](#section:iBeacon): iBeaconScanner.

- ANCS example:

    - [ANCS](#section:ANCS): .

- LE Central example:

    - [LECentral](#section:LECentral): .

- LE Peripheral example:

    - [LEPeripheral](#section:LEPeripheral): .


