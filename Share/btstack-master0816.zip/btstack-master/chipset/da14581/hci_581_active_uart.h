
/** 
 * hci_581_active_uart.h converted from hci_581_active_uart.hex 
 */

#ifndef __hci_581_active_uart_H
#define __hci_581_active_uart_H

#include <stdint.h>

extern const uint8_t  da14581_fw_data[];
extern const uint32_t da14581_fw_size;
extern const char *   da14581_fw_name;

#endif
