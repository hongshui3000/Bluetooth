

## BLE ANCS Client API {#sec:ancsClientAPIAppendix}

    
    void ancs_client_init(void);
    void ancs_client_register_callback(btstack_packet_handler_t callback);
    const char * ancs_client_attribute_name_for_id(int id);
    


## BLE ATT Database API {#sec:attDbAPIAppendix}

    
    /**
     * @brief Init ATT DB storage
     */
    void att_db_util_init(void);
    
    /**
     * @brief Add primary service for 16-bit UUID
     */
    void att_db_util_add_service_uuid16(uint16_t udid16);
    
    /**
     * @brief Add primary service for 128-bit UUID
     */
    void att_db_util_add_service_uuid128(uint8_t * udid128);
    
    /**
     * @brief Add Characteristic with 16-bit UUID, properties, and data
     * @returns attribute value handle
     * @see ATT_PROPERTY_* in ble/att_db.h
     */
    uint16_t att_db_util_add_characteristic_uuid16(uint16_t   udid16,  uint16_t properties, uint8_t * data, uint16_t data_len);
    
    /**
     * @brief Add Characteristic with 128-bit UUID, properties, and data
     * @returns attribute value handle
     * @see ATT_PROPERTY_* in ble/att_db.h
     */
    uint16_t att_db_util_add_characteristic_uuid128(uint8_t * udid128, uint16_t properties, uint8_t * data, uint16_t data_len);
    
    /** 
     * @brief Get address of constructed ATT DB
     */
    uint8_t * att_db_util_get_address(void);
    
    /**
     * @brief Get size of constructed ATT DB 
     */
    uint16_t att_db_util_get_size(void);
    


## BLE ATT Server API {#sec:attServerAPIAppendix}

    /*
     * @brief setup ATT server
     * @param db attribute database created by compile-gatt.ph
     * @param read_callback, see att_db.h, can be NULL
     * @param write_callback, see attl.h, can be NULL
     */
    void att_server_init(uint8_t const * db, att_read_callback_t read_callback, att_write_callback_t write_callback);
    
    /*
     * @brief register packet handler for ATT server events:
     *        - ATT_EVENT_CAN_SEND_NOW
     *        - ATT_EVENT_HANDLE_VALUE_INDICATION_COMPLETE
     *        - ATT_EVENT_MTU_EXCHANGE_COMPLETE 
     * @param handler
     */
    void att_server_register_packet_handler(btstack_packet_handler_t handler);
    
    /*
     * @brief tests if a notification or indication can be send right now
     * @param con_handle
     * @return 1, if packet can be sent
     */
    int  att_server_can_send_packet_now(hci_con_handle_t con_handle);
    
    /** 
     * @brief Request emission of ATT_EVENT_CAN_SEND_NOW as soon as possible
     * @note ATT_EVENT_CAN_SEND_NOW might be emitted during call to this function
     *       so packet handler should be ready to handle it
     * @param con_handle
     */
    void att_server_request_can_send_now_event(hci_con_handle_t con_handle);
    
    /** 
     * @brief Request callback when sending is possible
     * @note callback might happend during call to this function
     * @param callback_registration to point to callback function and context information
     * @param con_handle
     */
    void att_server_register_can_send_now_callback(btstack_context_callback_registration_t * callback_registration, hci_con_handle_t con_handle);
    
    /*
     * @brief notify client about attribute value change
     * @param con_handle
     * @param attribute_handle
     * @param value
     * @param value_len
     * @return 0 if ok, error otherwise
     */
    int att_server_notify(hci_con_handle_t con_handle, uint16_t attribute_handle, uint8_t *value, uint16_t value_len);
    
    /*
     * @brief indicate value change to client. client is supposed to reply with an indication_response
     * @param con_handle
     * @param attribute_handle
     * @param value
     * @param value_len
     * @return 0 if ok, error otherwise
     */
    int att_server_indicate(hci_con_handle_t con_handle, uint16_t attribute_handle, uint8_t *value, uint16_t value_len);
    


## BLE GATT Client API {#sec:gattClientAPIAppendix}

    
    typedef struct {
        uint16_t start_group_handle;
        uint16_t end_group_handle;
        uint16_t uuid16;
        uint8_t  uuid128[16];
    } gatt_client_service_t;
    
    typedef struct {
        uint16_t start_handle;
        uint16_t value_handle;
        uint16_t end_handle;
        uint16_t properties;
        uint16_t uuid16;
        uint8_t  uuid128[16];
    } gatt_client_characteristic_t;
    
    typedef struct {
        uint16_t handle;
        uint16_t uuid16;
        uint8_t  uuid128[16];
    } gatt_client_characteristic_descriptor_t;
    
    /** 
     * @brief Set up GATT client.
     */
    void gatt_client_init(void);
    
    /** 
     * @brief MTU is available after the first query has completed. If status is equal to 0, it returns the real value, otherwise the default value of 23. 
     */
    uint8_t gatt_client_get_mtu(hci_con_handle_t con_handle, uint16_t * mtu);
    
    /** 
     * @brief Returns if the GATT client is ready to receive a query. It is used with daemon. 
     */
    int gatt_client_is_ready(hci_con_handle_t con_handle);
    
    /** 
     * @brief Discovers all primary services. For each found service, an le_service_event_t with type set to GATT_EVENT_SERVICE_QUERY_RESULT will be generated and passed to the registered callback. The gatt_complete_event_t, with type set to GATT_EVENT_QUERY_COMPLETE, marks the end of discovery. 
     */
    uint8_t gatt_client_discover_primary_services(btstack_packet_handler_t callback, hci_con_handle_t con_handle);
    
    /** 
     * @brief Discovers a specific primary service given its UUID. This service may exist multiple times. For each found service, an le_service_event_t with type set to GATT_EVENT_SERVICE_QUERY_RESULT will be generated and passed to the registered callback. The gatt_complete_event_t, with type set to GATT_EVENT_QUERY_COMPLETE, marks the end of discovery. 
     */
    uint8_t gatt_client_discover_primary_services_by_uuid16(btstack_packet_handler_t callback, hci_con_handle_t con_handle, uint16_t uuid16);
    uint8_t gatt_client_discover_primary_services_by_uuid128(btstack_packet_handler_t callback, hci_con_handle_t con_handle, const uint8_t  * uuid);
    
    /** 
     * @brief Finds included services within the specified service. For each found included service, an le_service_event_t with type set to GATT_EVENT_INCLUDED_SERVICE_QUERY_RESULT will be generated and passed to the registered callback. The gatt_complete_event_t with type set to GATT_EVENT_QUERY_COMPLETE, marks the end of discovery. Information about included service type (primary/secondary) can be retrieved either by sending an ATT find information request for the returned start group handle (returning the handle and the UUID for primary or secondary service) or by comparing the service to the list of all primary services. 
     */
    uint8_t gatt_client_find_included_services_for_service(btstack_packet_handler_t callback, hci_con_handle_t con_handle, gatt_client_service_t  *service);
    
    /** 
     * @brief Discovers all characteristics within the specified service. For each found characteristic, an le_characteristics_event_t with type set to GATT_EVENT_CHARACTERISTIC_QUERY_RESULT will be generated and passed to the registered callback. The gatt_complete_event_t with type set to GATT_EVENT_QUERY_COMPLETE, marks the end of discovery.
     */
    uint8_t gatt_client_discover_characteristics_for_service(btstack_packet_handler_t callback, hci_con_handle_t con_handle, gatt_client_service_t  *service);
    
    /** 
     * @brief The following four functions are used to discover all characteristics within the specified service or handle range, and return those that match the given UUID. For each found characteristic, an le_characteristic_event_t with type set to GATT_EVENT_CHARACTERISTIC_QUERY_RESULT will be generated and passed to the registered callback. The gatt_complete_event_t with type set to GATT_EVENT_QUERY_COMPLETE, marks the end of discovery.
     */
    uint8_t gatt_client_discover_characteristics_for_handle_range_by_uuid16(btstack_packet_handler_t callback, hci_con_handle_t con_handle, uint16_t start_handle, uint16_t end_handle, uint16_t uuid16);
    uint8_t gatt_client_discover_characteristics_for_handle_range_by_uuid128(btstack_packet_handler_t callback, hci_con_handle_t con_handle, uint16_t start_handle, uint16_t end_handle, uint8_t  * uuid);
    uint8_t gatt_client_discover_characteristics_for_service_by_uuid16(btstack_packet_handler_t callback, hci_con_handle_t con_handle, gatt_client_service_t  *service, uint16_t  uuid16);
    uint8_t gatt_client_discover_characteristics_for_service_by_uuid128(btstack_packet_handler_t callback, hci_con_handle_t con_handle, gatt_client_service_t  *service, uint8_t  * uuid128);
    
    /** 
     * @brief Discovers attribute handle and UUID of a characteristic descriptor within the specified characteristic. For each found descriptor, an le_characteristic_descriptor_event_t with type set to GATT_EVENT_ALL_CHARACTERISTIC_DESCRIPTORS_QUERY_RESULT will be generated and passed to the registered callback. The gatt_complete_event_t with type set to GATT_EVENT_QUERY_COMPLETE, marks the end of discovery.
     */
    uint8_t gatt_client_discover_characteristic_descriptors(btstack_packet_handler_t callback, hci_con_handle_t con_handle, gatt_client_characteristic_t  *characteristic);
    
    /** 
     * @brief Reads the characteristic value using the characteristic's value handle. If the characteristic value is found, an le_characteristic_value_event_t with type set to GATT_EVENT_CHARACTERISTIC_VALUE_QUERY_RESULT will be generated and passed to the registered callback. The gatt_complete_event_t with type set to GATT_EVENT_QUERY_COMPLETE, marks the end of read.
     */
    uint8_t gatt_client_read_value_of_characteristic(btstack_packet_handler_t callback, hci_con_handle_t con_handle, gatt_client_characteristic_t  *characteristic);
    uint8_t gatt_client_read_value_of_characteristic_using_value_handle(btstack_packet_handler_t callback, hci_con_handle_t con_handle, uint16_t characteristic_value_handle);
    
    /**
     * @brief Reads the characteric value of all characteristics with the uuid. For each found, an le_characteristic_value_event_t with type set to GATT_EVENT_CHARACTERISTIC_VALUE_QUERY_RESULT will be generated and passed to the registered callback. The gatt_complete_event_t with type set to GATT_EVENT_QUERY_COMPLETE, marks the end of read.
     */
    uint8_t gatt_client_read_value_of_characteristics_by_uuid16(btstack_packet_handler_t callback, hci_con_handle_t con_handle, uint16_t start_handle, uint16_t end_handle, uint16_t uuid16);
    uint8_t gatt_client_read_value_of_characteristics_by_uuid128(btstack_packet_handler_t callback, hci_con_handle_t con_handle, uint16_t start_handle, uint16_t end_handle, uint8_t * uuid128);
    
    /** 
     * @brief Reads the long characteristic value using the characteristic's value handle. The value will be returned in several blobs. For each blob, an le_characteristic_value_event_t with type set to GATT_EVENT_CHARACTERISTIC_VALUE_QUERY_RESULT and updated value offset will be generated and passed to the registered callback. The gatt_complete_event_t with type set to GATT_EVENT_QUERY_COMPLETE, mark the end of read.
     */
    uint8_t gatt_client_read_long_value_of_characteristic(btstack_packet_handler_t callback, hci_con_handle_t con_handle, gatt_client_characteristic_t  *characteristic);
    uint8_t gatt_client_read_long_value_of_characteristic_using_value_handle(btstack_packet_handler_t callback, hci_con_handle_t con_handle, uint16_t characteristic_value_handle);
    uint8_t gatt_client_read_long_value_of_characteristic_using_value_handle_with_offset(btstack_packet_handler_t callback, hci_con_handle_t con_handle, uint16_t characteristic_value_handle, uint16_t offset);
    
    /*
     * @brief Read multiple characteristic values
     * @param number handles
     * @param list_of_handles list of handles 
     */
    uint8_t gatt_client_read_multiple_characteristic_values(btstack_packet_handler_t callback, hci_con_handle_t con_handle, int num_value_handles, uint16_t * value_handles);
    
    /** 
     * @brief Writes the characteristic value using the characteristic's value handle without an acknowledgment that the write was successfully performed.
     */
    uint8_t gatt_client_write_value_of_characteristic_without_response(hci_con_handle_t con_handle, uint16_t characteristic_value_handle, uint16_t length, uint8_t  * data);
    
    /** 
     * @brief Writes the authenticated characteristic value using the characteristic's value handle without an acknowledgment that the write was successfully performed.
     */
    uint8_t gatt_client_signed_write_without_response(btstack_packet_handler_t callback, hci_con_handle_t con_handle, uint16_t handle, uint16_t message_len, uint8_t  * message);
    
    /** 
     * @brief Writes the characteristic value using the characteristic's value handle. The gatt_complete_event_t with type set to GATT_EVENT_QUERY_COMPLETE, marks the end of write. The write is successfully performed, if the event's status field is set to 0.
     */
    uint8_t gatt_client_write_value_of_characteristic(btstack_packet_handler_t callback, hci_con_handle_t con_handle, uint16_t characteristic_value_handle, uint16_t length, uint8_t  * data);
    uint8_t gatt_client_write_long_value_of_characteristic(btstack_packet_handler_t callback, hci_con_handle_t con_handle, uint16_t characteristic_value_handle, uint16_t length, uint8_t  * data);
    uint8_t gatt_client_write_long_value_of_characteristic_with_offset(btstack_packet_handler_t callback, hci_con_handle_t con_handle, uint16_t characteristic_value_handle, uint16_t offset, uint16_t length, uint8_t  * data);
    
    /** 
     * @brief Writes of the long characteristic value using the characteristic's value handle. It uses server response to validate that the write was correctly received. The gatt_complete_event_t with type set to GATT_EVENT_QUERY_COMPLETE marks the end of write. The write is successfully performed, if the event's status field is set to 0.
     */
    uint8_t gatt_client_reliable_write_long_value_of_characteristic(btstack_packet_handler_t callback, hci_con_handle_t con_handle, uint16_t characteristic_value_handle, uint16_t length, uint8_t  * data);
    
    /** 
     * @brief Reads the characteristic descriptor using its handle. If the characteristic descriptor is found, an le_characteristic_descriptor_event_t with type set to GATT_EVENT_CHARACTERISTIC_DESCRIPTOR_QUERY_RESULT will be generated and passed to the registered callback. The gatt_complete_event_t with type set to GATT_EVENT_QUERY_COMPLETE, marks the end of read.
     */
    uint8_t gatt_client_read_characteristic_descriptor(btstack_packet_handler_t callback, hci_con_handle_t con_handle, gatt_client_characteristic_descriptor_t  * descriptor);
    uint8_t gatt_client_read_characteristic_descriptor_using_descriptor_handle(btstack_packet_handler_t callback, hci_con_handle_t con_handle, uint16_t descriptor_handle);
    
    /** 
     * @brief Reads the long characteristic descriptor using its handle. It will be returned in several blobs. For each blob, an le_characteristic_descriptor_event_t with type set to GATT_EVENT_CHARACTERISTIC_DESCRIPTOR_QUERY_RESULT will be generated and passed to the registered callback. The gatt_complete_event_t with type set to GATT_EVENT_QUERY_COMPLETE, marks the end of read.
     */
    uint8_t gatt_client_read_long_characteristic_descriptor(btstack_packet_handler_t callback, hci_con_handle_t con_handle, gatt_client_characteristic_descriptor_t  * descriptor);
    uint8_t gatt_client_read_long_characteristic_descriptor_using_descriptor_handle(btstack_packet_handler_t callback, hci_con_handle_t con_handle, uint16_t descriptor_handle);
    uint8_t gatt_client_read_long_characteristic_descriptor_using_descriptor_handle_with_offset(btstack_packet_handler_t callback, hci_con_handle_t con_handle, uint16_t descriptor_handle, uint16_t offset);
    
    /** 
     * @brief Writes the characteristic descriptor using its handle. The gatt_complete_event_t with type set to GATT_EVENT_QUERY_COMPLETE, marks the end of write. The write is successfully performed, if the event's status field is set to 0.
     */
    uint8_t gatt_client_write_characteristic_descriptor(btstack_packet_handler_t callback, hci_con_handle_t con_handle, gatt_client_characteristic_descriptor_t  * descriptor, uint16_t length, uint8_t  * data);
    uint8_t gatt_client_write_characteristic_descriptor_using_descriptor_handle(btstack_packet_handler_t callback, hci_con_handle_t con_handle, uint16_t descriptor_handle, uint16_t length, uint8_t  * data);
    uint8_t gatt_client_write_long_characteristic_descriptor(btstack_packet_handler_t callback, hci_con_handle_t con_handle, gatt_client_characteristic_descriptor_t  * descriptor, uint16_t length, uint8_t  * data);
    uint8_t gatt_client_write_long_characteristic_descriptor_using_descriptor_handle(btstack_packet_handler_t callback, hci_con_handle_t con_handle, uint16_t descriptor_handle, uint16_t length, uint8_t  * data);
    uint8_t gatt_client_write_long_characteristic_descriptor_using_descriptor_handle_with_offset(btstack_packet_handler_t callback, hci_con_handle_t con_handle, uint16_t descriptor_handle, uint16_t offset, uint16_t length, uint8_t  * data);
    
    /** 
     * @brief Writes the client characteristic configuration of the specified characteristic. It is used to subscribe for notifications or indications of the characteristic value. For notifications or indications specify: GATT_CLIENT_CHARACTERISTICS_CONFIGURATION_NOTIFICATION resp. GATT_CLIENT_CHARACTERISTICS_CONFIGURATION_INDICATION as configuration value.
     */
    uint8_t gatt_client_write_client_characteristic_configuration(btstack_packet_handler_t callback, hci_con_handle_t con_handle, gatt_client_characteristic_t * characteristic, uint16_t configuration);
    
    /**
     * @brief Register for notifications and indications of a characteristic enabled by gatt_client_write_client_characteristic_configuration
     * @param notification struct used to store registration
     * @param packet_handler
     * @param con_handle
     * @param characteristic
     */
    void gatt_client_listen_for_characteristic_value_updates(gatt_client_notification_t * notification, btstack_packet_handler_t packet_handler, hci_con_handle_t con_handle, gatt_client_characteristic_t * characteristic);
    
    /**
     * @brief Stop listening to characteristic value updates registered with gatt_client_listen_for_characteristic_value_updates
     * @param notification struct used in gatt_client_listen_for_characteristic_value_updates
     */
    void gatt_client_stop_listening_for_characteristic_value_updates(gatt_client_notification_t * notification);
    
    /**
     * @brief -> gatt complete event
     */
    uint8_t gatt_client_prepare_write(btstack_packet_handler_t callback, hci_con_handle_t con_handle, uint16_t attribute_handle, uint16_t offset, uint16_t length, uint8_t * data);
    
    /**
     * @brief -> gatt complete event
     */
    uint8_t gatt_client_execute_write(btstack_packet_handler_t callback, hci_con_handle_t con_handle);
    
    /**
     * @brief -> gatt complete event
     */
    uint8_t gatt_client_cancel_write(btstack_packet_handler_t callback, hci_con_handle_t con_handle);
    


## BLE Device Database API {#sec:leDeviceDbAPIAppendix}

    
    /**
     * @brief init
     */
    void le_device_db_init(void);
    
    
    /**
     * @brief sets local bd addr. allows for db per Bluetooth controller
     * @param bd_addr
     */
    void le_device_db_set_local_bd_addr(bd_addr_t bd_addr);
    
    /**
     * @brief add device to db
     * @param addr_type, address of the device
     * @param irk of the device
     * @returns index if successful, -1 otherwise
     */
    int le_device_db_add(int addr_type, bd_addr_t addr, sm_key_t irk);
    
    /**
     * @brief get number of devices in db for enumeration
     * @returns number of device in db
     */
    int le_device_db_count(void);
    
    /**
     * @brief get device information: addr type and address needed to identify device
     * @param index
     * @param addr_type, address of the device as output
     * @param irk of the device
     */
    void le_device_db_info(int index, int * addr_type, bd_addr_t addr, sm_key_t irk);
    
    
    /**
     * @brief set remote encryption info
     * @brief index
     * @brief ediv 
     * @brief rand
     * @brief ltk
     * @brief key size
     * @brief authenticated
     * @brief authorized
     */
    void le_device_db_encryption_set(int index, uint16_t ediv, uint8_t rand[8], sm_key_t ltk, int key_size, int authenticated, int authorized);
    
    /**
     * @brief get remote encryption info
     * @brief index
     * @brief ediv 
     * @brief rand
     * @brief ltk
     * @brief key size
     * @brief authenticated
     * @brief authorized
     */
    void le_device_db_encryption_get(int index, uint16_t * ediv, uint8_t rand[8], sm_key_t ltk,  int * key_size, int * authenticated, int * authorized);
    
    #ifdef ENABLE_LE_SIGNED_WRITE
    
    /**
     * @brief set local signing key for this device
     * @param index
     * @param signing key as input
     */
    void le_device_db_local_csrk_set(int index, sm_key_t csrk);
    
    /**
     * @brief get local signing key for this device
     * @param index
     * @param signing key as output
     */
    void le_device_db_local_csrk_get(int index, sm_key_t csrk);
    
    /**
     * @brief set remote signing key for this device
     * @param index
     * @param signing key as input
     */
    void le_device_db_remote_csrk_set(int index, sm_key_t csrk);
    
    /**
     * @brief get remote signing key for this device
     * @param index
     * @param signing key as output
     */
    void le_device_db_remote_csrk_get(int index, sm_key_t csrk);
    
    /**
     * @brief query last used/seen signing counter
     * @param index
     * @returns next expected counter, 0 after devices was added
     */
    uint32_t le_device_db_remote_counter_get(int index);
    
    /**
     * @brief update signing counter
     * @param index
     * @param counter to store
     */
    void le_device_db_remote_counter_set(int index, uint32_t counter);
    
    /**
     * @brief query last used/seen signing counter
     * @param index
     * @returns next expected counter, 0 after devices was added
     */
    uint32_t le_device_db_local_counter_get(int index);
    
    /**
     * @brief update signing counter
     * @param index
     * @param counter to store
     */
    void le_device_db_local_counter_set(int index, uint32_t counter);
    
    #endif
    
    /**
     * @brief free device
     * @param index
     */
    void le_device_db_remove(int index);
    
    void le_device_db_dump(void);
    


## BLE Security Manager API {#sec:smAPIAppendix}

    
    /**
     * @brief Initializes the Security Manager, connects to L2CAP
     */
    void sm_init(void);
    
    /**
     * @brief Set secret ER key for key generation as described in Core V4.0, Vol 3, Part G, 5.2.2 
     * @param er
     */
    void sm_set_er(sm_key_t er);
    
    /**
     * @brief Set secret IR key for key generation as described in Core V4.0, Vol 3, Part G, 5.2.2 
     */
    void sm_set_ir(sm_key_t ir);
    
    /**
     *
     * @brief Registers OOB Data Callback. The callback should set the oob_data and return 1 if OOB data is availble
     * @param get_oob_data_callback
     */
    void sm_register_oob_data_callback( int (*get_oob_data_callback)(uint8_t addres_type, bd_addr_t addr, uint8_t * oob_data));
    
    /**
     * @brief Add event packet handler. 
     */
    void sm_add_event_handler(btstack_packet_callback_registration_t * callback_handler);
    
    /**
     * @brief Limit the STK generation methods. Bonding is stopped if the resulting one isn't in the list
     * @param OR combination of SM_STK_GENERATION_METHOD_ 
     */
    void sm_set_accepted_stk_generation_methods(uint8_t accepted_stk_generation_methods);
    
    /**
     * @brief Set the accepted encryption key size range. Bonding is stopped if the result isn't within the range
     * @param min_size (default 7)
     * @param max_size (default 16)
     */
    void sm_set_encryption_key_size_range(uint8_t min_size, uint8_t max_size);
    
    /**
     * @brief Sets the requested authentication requirements, bonding yes/no, MITM yes/no, SC yes/no, keypress yes/no
     * @param OR combination of SM_AUTHREQ_ flags
     */
    void sm_set_authentication_requirements(uint8_t auth_req);
    
    /**
     * @brief Sets the available IO Capabilities
     * @param IO_CAPABILITY_
     */
    void sm_set_io_capabilities(io_capability_t io_capability);
    
    /**
     * @brief Let Peripheral request an encrypted connection right after connecting
     * @note Not used normally. Bonding is triggered by access to protected attributes in ATT Server
     */
    void sm_set_request_security(int enable);
    
    /** 
     * @brief Trigger Security Request
     * @note Not used normally. Bonding is triggered by access to protected attributes in ATT Server
     */
    void sm_send_security_request(hci_con_handle_t con_handle);
    
    /**
     * @brief Decline bonding triggered by event before
     * @param con_handle
     */
    void sm_bonding_decline(hci_con_handle_t con_handle);
    
    /**
     * @brief Confirm Just Works bonding 
     * @param con_handle
     */
    void sm_just_works_confirm(hci_con_handle_t con_handle);
    
    /**
     * @brief Confirm value from SM_EVENT_NUMERIC_COMPARISON_REQUEST for Numeric Comparison bonding 
     * @param con_handle
     */
    void sm_numeric_comparison_confirm(hci_con_handle_t con_handle);
    
    /**
     * @brief Reports passkey input by user
     * @param con_handle
     * @param passkey in [0..999999]
     */
    void sm_passkey_input(hci_con_handle_t con_handle, uint32_t passkey);
    
    /**
     * @brief Send keypress notification for keyboard only devices
     * @param con_handle
     * @param action see SM_KEYPRESS_* in bluetooth.h
     */
    void sm_keypress_notification(hci_con_handle_t con_handle, uint8_t action);
    
    /**
     *
     * @brief Get encryption key size.
     * @param con_handle
     * @return 0 if not encrypted, 7-16 otherwise
     */
    int sm_encryption_key_size(hci_con_handle_t con_handle);
    
    /**
     * @brief Get authentication property.
     * @param con_handle
     * @return 1 if bonded with OOB/Passkey (AND MITM protection)
     */
    int sm_authenticated(hci_con_handle_t con_handle);
    
    /**
     * @brief Queries authorization state.
     * @param con_handle
     * @return authorization_state for the current session
     */
    authorization_state_t sm_authorization_state(hci_con_handle_t con_handle);
    
    /**
     * @brief Used by att_server.c to request user authorization.
     * @param con_handle
     */
    void sm_request_pairing(hci_con_handle_t con_handle);
    
    /**
     * @brief Report user authorization decline.
     * @param con_handle
     */
    void sm_authorization_decline(hci_con_handle_t con_handle);
    
    /**
     * @brief Report user authorization grant.
     * @param con_handle
     */
    void sm_authorization_grant(hci_con_handle_t con_handle);
    
    
    /**
     * @brief Check if CMAC AES engine is ready
     * @return ready
     */
     int sm_cmac_ready(void);
    
    /*
     * @brief Generic CMAC AES
     * @param key
     * @param message_len
     * @param get_byte_callback
     * @param done_callback
     * @note hash is 16 bytes in big endian
     */
    void sm_cmac_general_start(const sm_key_t key, uint16_t message_len, uint8_t (*get_byte_callback)(uint16_t offset), void (*done_callback)(uint8_t * hash));
    
    /**
     * @brief Support for signed writes, used by att_server.
     * @note Message is in little endian to allows passing in ATT PDU without flipping. 
     * @note signing data: [opcode, attribute_handle, message, sign_counter]
     * @note calculated hash in done_callback is big endian and has 16 byte. 
     * @param key
     * @param opcde
     * @param attribute_handle
     * @param message_len
     * @param message
     * @param sign_counter
     */
    void sm_cmac_signed_write_start(const sm_key_t key, uint8_t opcode, uint16_t attribute_handle, uint16_t message_len, const uint8_t * message, uint32_t sign_counter, void (*done_callback)(uint8_t * hash));
    
    /*
     * @brief Match address against bonded devices
     * @return 0 if successfully added to lookup queue
     * @note Triggers SM_IDENTITY_RESOLVING_* events
     */
    int sm_address_resolution_lookup(uint8_t addr_type, bd_addr_t addr);
    
    /**
     * @brief Identify device in LE Device DB.
     * @param handle
     * @return index from le_device_db or -1 if not found/identified
     */
    int sm_le_device_index(hci_con_handle_t con_handle );
    
    /**
     * @brief Set Elliptic Key Public/Private Keypair
     * @note Using the same key for more than one device is not recommended. 
     * @param qx 32 bytes
     * @param qy 32 bytes
     * @param d  32 bytes
     */
    void sm_use_fixed_ec_keypair(uint8_t * qx, uint8_t * qy, uint8_t * d);
    


## BNEP API {#sec:bnepAPIAppendix}

    
    /**
     * @brief Set up BNEP.
     */
    void bnep_init(void);
    
    /**
     * @brief Check if a data packet can be send out.
     */
    int bnep_can_send_packet_now(uint16_t bnep_cid);
    
    /** 
     * @brief Request emission of BNEP_CAN_SEND_NOW as soon as possible
     * @note BNEP_CAN_SEND_NOW might be emitted during call to this function
     *       so packet handler should be ready to handle it
     * @param bnep_cid
     */
    void bnep_request_can_send_now_event(uint16_t bnep_cid);
    
    /**
     * @brief Send a data packet.
     */
    int bnep_send(uint16_t bnep_cid, uint8_t *packet, uint16_t len);
    
    /**
     * @brief Set the network protocol filter.
     */
    int bnep_set_net_type_filter(uint16_t bnep_cid, bnep_net_filter_t *filter, uint16_t len);
    
    /**
     * @brief Set the multicast address filter.
     */
    int bnep_set_multicast_filter(uint16_t bnep_cid, bnep_multi_filter_t *filter, uint16_t len);
    
    /**
     * @brief Set security level required for incoming connections, need to be called before registering services.
     */
    void bnep_set_required_security_level(gap_security_level_t security_level);
    
    /**
     * @brief Creates BNEP connection (channel) to a given server on a remote device with baseband address. A new baseband connection will be initiated if necessary. 
     */
    int bnep_connect(btstack_packet_handler_t packet_handler, bd_addr_t addr, uint16_t l2cap_psm, uint16_t uuid_src, uint16_t uuid_dest);
    
    /**
     * @brief Disconnects BNEP channel with given identifier. 
     */
    void bnep_disconnect(bd_addr_t addr);
    
    /**
     * @brief Registers BNEP service, set a maximum frame size and assigns a packet handler. On embedded systems, use NULL for connection parameter. 
     */
    uint8_t bnep_register_service(btstack_packet_handler_t packet_handler, uint16_t service_uuid, uint16_t max_frame_size);
    
    /**
     * @brief Unregister BNEP service.
     */
    void bnep_unregister_service(uint16_t service_uuid);


## Link Key DB API {#sec:lkDbAPIAppendix}

    
    typedef struct {
    
        // management
        void (*open)(void);
        void (*set_local_bd_addr)(bd_addr_t bd_addr);
        void (*close)(void);
        
        // link key
        int  (*get_link_key)(bd_addr_t bd_addr, link_key_t link_key, link_key_type_t * type);
        void (*put_link_key)(bd_addr_t bd_addr, link_key_t link_key, link_key_type_t   type);
        void (*delete_link_key)(bd_addr_t bd_addr);
    
    } btstack_link_key_db_t;
    


## HSP Headset API {#sec:hspHSAPIAppendix}

    
    /**
     * @brief Set up HSP HS.
     * @param rfcomm_channel_nr
     */
    void hsp_hs_init(uint8_t rfcomm_channel_nr);
    
    /**
     * @brief Create HSP Headset (HS) SDP service record. 
     * @param service Empty buffer in which a new service record will be stored.
     * @param rfcomm_channel_nr
     * @param name
     * @param have_remote_audio_control 
     */
    void hsp_hs_create_sdp_record(uint8_t * service, uint32_t service_record_handle, int rfcomm_channel_nr, const char * name, uint8_t have_remote_audio_control);
    
    /**
     * @brief Register packet handler to receive HSP HS events.
     *
     * The HSP HS event has type HCI_EVENT_HSP_META with following subtypes:                      
     * - HSP_SUBEVENT_RFCOMM_CONNECTION_COMPLETE
     * - HSP_SUBEVENT_RFCOMM_DISCONNECTION_COMPLETE
     * - HSP_SUBEVENT_AUDIO_CONNECTION_COMPLETE    
     * - HSP_SUBEVENT_AUDIO_DISCONNECTION_COMPLETE 
     * - HSP_SUBEVENT_RING                         
     * - HSP_SUBEVENT_MICROPHONE_GAIN_CHANGED      
     * - HSP_SUBEVENT_SPEAKER_GAIN_CHANGED         
     * - HSP_SUBEVENT_AG_INDICATION     
     *
     * @param callback 
     */
    void hsp_hs_register_packet_handler(btstack_packet_handler_t callback);
    
    /**
     * @brief Connect to HSP Audio Gateway.
     *
     * Perform SDP query for an RFCOMM service on a remote device, 
     * and establish an RFCOMM connection if such service is found. Reception of the  
     * HSP_SUBEVENT_RFCOMM_CONNECTION_COMPLETE with status 0
     * indicates if the connection is successfully established. 
     *
     * @param bd_addr
     */
    void hsp_hs_connect(bd_addr_t bd_addr);
    
    /**
     * @brief Disconnect from HSP Audio Gateway
     *
     * Releases the RFCOMM channel. Reception of the  
     * HSP_SUBEVENT_RFCOMM_DISCONNECTION_COMPLETE with status 0
     * indicates if the connection is successfully released. 
     * @param bd_addr
     */
    void hsp_hs_disconnect(void);
    
    
    /**
     * @brief Send button press action. Toggle establish/release of audio connection. 
     */
    void hsp_hs_send_button_press(void);
    
    /**
     * @brief Triger establishing audio connection.
     * 
     * Reception of the HSP_SUBEVENT_AUDIO_CONNECTION_COMPLETE with status 0
     * indicates if the audio connection is successfully established. 
     * @param bd_addr
     */
    void hsp_hs_establish_audio_connection(void);
    
    /**
     * @brief Trigger releasing audio connection.
     *
     * Reception of the HSP_SUBEVENT_AUDIO_DISCONNECTION_COMPLETE with status 0
     * indicates if the connection is successfully released. 
     * @param bd_addr
     */
    void hsp_hs_release_audio_connection(void);
    
    /**
     * @brief Set microphone gain. 
     * 
     * The new gain value will be confirmed by the HSP Audio Gateway. 
     * A HSP_SUBEVENT_MICROPHONE_GAIN_CHANGED event will be received.
     * @param gain Valid range: [0,15]
     */
    void hsp_hs_set_microphone_gain(uint8_t gain);
    
    /**
     * @brief Set speaker gain. 
     * 
     * The new gain value will be confirmed by the HSP Audio Gateway. 
     * A HSP_SUBEVENT_SPEAKER_GAIN_CHANGED event will be received.
     * @param gain - valid range: [0,15]
     */
    void hsp_hs_set_speaker_gain(uint8_t gain);
    
    
    
    /**
     * @brief Enable custom indications.
     * 
     * Custom indications are disabled by default. 
     * When enabled, custom indications are received via the HSP_SUBEVENT_AG_INDICATION.
     * @param enable
     */
    void hsp_hs_enable_custom_indications(int enable);
    
    /**
     * @brief Send answer to custom indication.
     *
     * On HSP_SUBEVENT_AG_INDICATION, the client needs to respond
     * with this function with the result to the custom indication
     * @param result 
     */
    int hsp_hs_send_result(const char * result);
    


## HSP Audio Gateway API {#sec:hspAGAPIAppendix}

    
    /**
     * @brief Set up HSP AG.
     * @param rfcomm_channel_nr
     */
    void hsp_ag_init(uint8_t rfcomm_channel_nr);
    
    /**
     * @brief Create HSP Audio Gateway (AG) SDP service record. 
     * @param service Empty buffer in which a new service record will be stored.
     * @param service_record_handle
     * @param rfcomm_channel_nr
     * @param name
     */
    void hsp_ag_create_sdp_record(uint8_t * service, uint32_t service_record_handle, int rfcomm_channel_nr, const char * name);
    
    /**
     * @brief Register packet handler to receive HSP AG events.
    
     * The HSP AG event has type HCI_EVENT_HSP_META with following subtypes:  
     * - HSP_SUBEVENT_RFCOMM_CONNECTION_COMPLETE
     * - HSP_SUBEVENT_RFCOMM_DISCONNECTION_COMPLETE
     * - HSP_SUBEVENT_AUDIO_CONNECTION_COMPLETE    
     * - HSP_SUBEVENT_AUDIO_DISCONNECTION_COMPLETE                       
     * - HSP_SUBEVENT_MICROPHONE_GAIN_CHANGED      
     * - HSP_SUBEVENT_SPEAKER_GAIN_CHANGED         
     * - HSP_SUBEVENT_HS_COMMAND      
     *
     * @param callback 
     */
    void hsp_ag_register_packet_handler(btstack_packet_handler_t callback);
    
    /**
     * @brief Connect to HSP Headset.
     *
     * Perform SDP query for an RFCOMM service on a remote device, 
     * and establish an RFCOMM connection if such service is found. Reception of the  
     * HSP_SUBEVENT_RFCOMM_CONNECTION_COMPLETE with status 0
     * indicates if the connection is successfully established. 
     *
     * @param bd_addr
     */
    void hsp_ag_connect(bd_addr_t bd_addr);
    
    /**
     * @brief Disconnect from HSP Headset
     *
     * Reception of the HSP_SUBEVENT_RFCOMM_DISCONNECTION_COMPLETE with status 0
     * indicates if the connection is successfully released. 
     * @param bd_addr
     */
    void hsp_ag_disconnect(void);
    
    
    /**
     * @brief Establish audio connection.
     * 
     * Reception of the HSP_SUBEVENT_AUDIO_CONNECTION_COMPLETE with status 0
     * indicates if the audio connection is successfully established. 
     * @param bd_addr
     */
    void hsp_ag_establish_audio_connection(void);
    
    /**
     * @brief Release audio connection.
     *
     * Reception of the HSP_SUBEVENT_AUDIO_DISCONNECTION_COMPLETE with status 0
     * indicates if the connection is successfully released. 
     * @param bd_addr
     */
    void hsp_ag_release_audio_connection(void);
    
    /**
     * @brief Set microphone gain. 
     * @param gain Valid range: [0,15]
     */
    void hsp_ag_set_microphone_gain(uint8_t gain);
    
    /**
     * @brief Set speaker gain. 
     * @param gain Valid range: [0,15]
     */
    void hsp_ag_set_speaker_gain(uint8_t gain);
    
    /**
     * @brief Start ringing because of incoming call.
     */
    void hsp_ag_start_ringing(void);
    
    /**
     * @brief Stop ringing (e.g. call was terminated).
     */
    void hsp_ag_stop_ringing(void);
    
    /**
     * @brief Enable custom AT commands.
     * 
     * Custom commands are disabled by default. 
     * When enabled, custom AT commands are received via the HSP_SUBEVENT_HS_COMMAND.
     * @param enable
     */
    void hsp_ag_enable_custom_commands(int enable);
    
    /**
     * @brief Send a custom AT command to HSP Headset.
     *
     * On HSP_SUBEVENT_AG_INDICATION, the client needs to respond
     * with this function with the result to the custom command.
     * @param result 
     */
    int hsp_ag_send_result(char * result);
    


## HFP Hands-Free API {#sec:hfpHFAPIAppendix}

    
    /**
     * @brief Create HFP Hands-Free (HF) SDP service record. 
     * @param service
     * @param rfcomm_channel_nr
     * @param name
     * @param suported_features 32-bit bitmap, see HFP_HFSF_* values in hfp.h
     * @param wide_band_speech supported
     */
    void hfp_hf_create_sdp_record(uint8_t * service, uint32_t service_record_handle, int rfcomm_channel_nr, const char * name, uint16_t supported_features, int wide_band_speech);
    
    /**
     * @brief Set up HFP Hands-Free (HF) device without additional supported features. 
     * @param rfcomm_channel_nr
     */
    void hfp_hf_init(uint16_t rfcomm_channel_nr);
    
    /**
     * @brief Set codecs. 
     * @param codecs_nr
     * @param codecs
     */
    void hfp_hf_init_codecs(int codecs_nr, uint8_t * codecs);
    
    /**
     * @brief Set supported features.
     * @param supported_features 32-bit bitmap, see HFP_HFSF_* values in hfp.h
     */
    void hfp_hf_init_supported_features(uint32_t supported_features);
    
    /**
     * @brief Set HF indicators. 
     * @param indicators_nr
     * @param indicators
     */
    void hfp_hf_init_hf_indicators(int indicators_nr, uint16_t * indicators);
    
    
    /**
     * @brief Register callback for the HFP Hands-Free (HF) client. 
     * @param callback
     */
    void hfp_hf_register_packet_handler(btstack_packet_handler_t callback);
    
    /**
     * @brief Establish RFCOMM connection with the AG with given Bluetooth address, 
     * and perform service level connection (SLC) agreement:
     * - exchange supported features
     * - retrieve Audio Gateway (AG) indicators and their status 
     * - enable indicator status update in the AG
     * - notify the AG about its own available codecs, if possible
     * - retrieve the AG information describing the call hold and multiparty services, if possible
     * - retrieve which HF indicators are enabled on the AG, if possible
     * The status of SLC connection establishment is reported via
     * HFP_SUBEVENT_SERVICE_LEVEL_CONNECTION_ESTABLISHED.
     *
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_establish_service_level_connection(bd_addr_t bd_addr);
    
    /**
     * @brief Release the RFCOMM channel and the audio connection between the HF and the AG. 
     * The status of releasing the SLC connection is reported via
     * HFP_SUBEVENT_SERVICE_LEVEL_CONNECTION_RELEASED.
     *
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_release_service_level_connection(hci_con_handle_t acl_handle);
    
    /**
     * @brief Enable status update for all indicators in the AG.
     * The status field of the HFP_SUBEVENT_COMPLETE reports if the command was accepted.
     * The status of an AG indicator is reported via HFP_SUBEVENT_AG_INDICATOR_STATUS_CHANGED.
     *
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_enable_status_update_for_all_ag_indicators(hci_con_handle_t acl_handle);
    
    /**
     * @brief Disable status update for all indicators in the AG.
     * The status field of the HFP_SUBEVENT_COMPLETE reports if the command was accepted.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_disable_status_update_for_all_ag_indicators(hci_con_handle_t acl_handle);
    
    /**
     * @brief Enable or disable status update for the individual indicators in the AG using bitmap.
     * The status field of the HFP_SUBEVENT_COMPLETE reports if the command was accepted.
     * The status of an AG indicator is reported via HFP_SUBEVENT_AG_INDICATOR_STATUS_CHANGED.
     * 
     * @param bd_addr Bluetooth address of the AG
     * @param indicators_status_bitmap 32-bit bitmap, 0 - indicator is disabled, 1 - indicator is enabled
     */
    void hfp_hf_set_status_update_for_individual_ag_indicators(hci_con_handle_t acl_handle, uint32_t indicators_status_bitmap);
    
    /**
     * @brief Query the name of the currently selected Network operator by AG. 
     * 
     * The name is restricted to max 16 characters. The result is reported via 
     * HFP_SUBEVENT_NETWORK_OPERATOR_CHANGED subtype 
     * containing network operator mode, format and name.
     * If no operator is selected, format and operator are omitted.
     * 
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_query_operator_selection(hci_con_handle_t acl_handle);
    
    /**
     * @brief Enable Extended Audio Gateway Error result codes in the AG.
     * Whenever there is an error relating to the functionality of the AG as a 
     * result of AT command, the AG shall send +CME ERROR. This error is reported via 
     * HFP_SUBEVENT_EXTENDED_AUDIO_GATEWAY_ERROR, see hfp_cme_error_t in hfp.h
     *
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_enable_report_extended_audio_gateway_error_result_code(hci_con_handle_t acl_handle);
    
    /**
     * @brief Disable Extended Audio Gateway Error result codes in the AG.
     *
     * @param bd_addr Bluetooth address of the AG
     */
     void hfp_hf_disable_report_extended_audio_gateway_error_result_code(hci_con_handle_t acl_handle);
    
    /**
     * @brief Establish audio connection. 
     * The status of audio connection establishment is reported via
     * HFP_SUBEVENT_AUDIO_CONNECTION_ESTABLISHED.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_establish_audio_connection(hci_con_handle_t acl_handle);
    
    /**
     * @brief Release audio connection.
     * The status of releasing of the audio connection is reported via
     * HFP_SUBEVENT_AUDIO_CONNECTION_RELEASED.
     *
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_release_audio_connection(hci_con_handle_t acl_handle);
    
    /**
     * @brief Answer incoming call.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_answer_incoming_call(hci_con_handle_t acl_handle);
    
    /**
     * @brief Reject incoming call.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_reject_incoming_call(hci_con_handle_t acl_handle);
    
    /**
     * @brief Release all held calls or sets User Determined User Busy (UDUB) for a waiting call.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_user_busy(hci_con_handle_t acl_handle);
    
    /**
     * @brief Release all active calls (if any exist) and accepts the other (held or waiting) call.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_end_active_and_accept_other(hci_con_handle_t acl_handle);
    
    /**
     * @brief Place all active calls (if any exist) on hold and accepts the other (held or waiting) call.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_swap_calls(hci_con_handle_t acl_handle);
    
    /**
     * @brief Add a held call to the conversation.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_join_held_call(hci_con_handle_t acl_handle);
    
    /**
     * @brief Connect the two calls and disconnects the subscriber from both calls (Explicit Call
    Transfer).
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_connect_calls(hci_con_handle_t acl_handle);
    
    /**
     * @brief Terminate an incoming or an outgoing call. 
     * HFP_SUBEVENT_CALL_TERMINATED is sent upon call termination.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_terminate_call(hci_con_handle_t acl_handle);
    
    /**
     * @brief Initiate outgoing voice call by providing the destination phone number to the AG. 
     * @param bd_addr Bluetooth address of the AG
     * @param number
     */
    void hfp_hf_dial_number(hci_con_handle_t acl_handle, char * number);
    
    /**
     * @brief Initiate outgoing voice call using the memory dialing feature of the AG.
     * @param bd_addr Bluetooth address of the AG
     * @param memory_id
     */
    void hfp_hf_dial_memory(hci_con_handle_t acl_handle, int memory_id);
    
    /**
     * @brief Initiate outgoing voice call by recalling the last number dialed by the AG.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_redial_last_number(hci_con_handle_t acl_handle);
    
    /*
     * @brief Enable the “Call Waiting notification” function in the AG. 
     * The AG shall send the corresponding result code to the HF whenever 
     * an incoming call is waiting during an ongoing call. In that event,
     * the HFP_SUBEVENT_CALL_WAITING_NOTIFICATION is emitted.
     *
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_activate_call_waiting_notification(hci_con_handle_t acl_handle);
    
    /*
     * @brief Disable the “Call Waiting notification” function in the AG.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_deactivate_call_waiting_notification(hci_con_handle_t acl_handle);
    
    /*
     * @brief Enable the “Calling Line Identification notification” function in the AG. 
     * The AG shall issue the corresponding result code just after every RING indication,
     * when the HF is alerted in an incoming call. In that event,
     * the HFP_SUBEVENT_CALLING_LINE_INDETIFICATION_NOTIFICATION is emitted.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_activate_calling_line_notification(hci_con_handle_t acl_handle);
    
    /*
     * @brief Disable the “Calling Line Identification notification” function in the AG.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_deactivate_calling_line_notification(hci_con_handle_t acl_handle);
    
    
    /*
     * @brief Activate echo canceling and noise reduction in the AG. By default, 
     * if the AG supports its own embedded echo canceling and/or noise reduction 
     * functions, it shall have them activated until this function is called.
     * If the AG does not support any echo canceling and noise reduction functions, 
     * it shall respond with the ERROR indicator (TODO)
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_activate_echo_canceling_and_noise_reduction(hci_con_handle_t acl_handle);
    
    /*
     * @brief Deactivate echo canceling and noise reduction in the AG.
     */
    void hfp_hf_deactivate_echo_canceling_and_noise_reduction(hci_con_handle_t acl_handle);
    
    /*
     * @brief Activate voice recognition function.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_activate_voice_recognition_notification(hci_con_handle_t acl_handle);
    
    /*
     * @brief Dectivate voice recognition function.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_deactivate_voice_recognition_notification(hci_con_handle_t acl_handle);
    
    /*
     * @brief Set microphone gain. 
     * @param bd_addr Bluetooth address of the AG
     * @param gain Valid range: [0,15]
     */
    void hfp_hf_set_microphone_gain(hci_con_handle_t acl_handle, int gain);
    
    /*
     * @brief Set speaker gain.
     * @param bd_addr Bluetooth address of the AG
     * @param gain Valid range: [0,15]
     */
    void hfp_hf_set_speaker_gain(hci_con_handle_t acl_handle, int gain);
    
    /*
     * @brief Instruct the AG to transmit a DTMF code.
     * @param bd_addr Bluetooth address of the AG
     * @param dtmf_code
     */
    void hfp_hf_send_dtmf_code(hci_con_handle_t acl_handle, char code);
    
    /*
     * @brief Read numbers from the AG for the purpose of creating 
     * a unique voice tag and storing the number and its linked voice
     * tag in the HF’s memory. 
     * The number is reported via HFP_SUBEVENT_NUMBER_FOR_VOICE_TAG.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_request_phone_number_for_voice_tag(hci_con_handle_t acl_handle);
    
    /*
     * @brief Query the list of current calls in AG. 
     * The result is received via HFP_SUBEVENT_ENHANCED_CALL_STATUS.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_query_current_call_status(hci_con_handle_t acl_handle);
    
    /*
     * @brief Release a call with index in the AG.
     * @param bd_addr Bluetooth address of the AG
     * @param index
     */
    void hfp_hf_release_call_with_index(hci_con_handle_t acl_handle, int index);
    
    /*
     * @brief Place all parties of a multiparty call on hold with the 
     * exception of the specified call.
     * @param bd_addr Bluetooth address of the AG
     * @param index
     */
    void hfp_hf_private_consultation_with_call(hci_con_handle_t acl_handle, int index);
    
    /*
     * @brief Query the status of the “Response and Hold” state of the AG.
     * The result is reported via HFP_SUBEVENT_RESPONSE_AND_HOLD_STATUS.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_rrh_query_status(hci_con_handle_t acl_handle);
    
    /*
     * @brief Put an incoming call on hold in the AG.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_rrh_hold_call(hci_con_handle_t acl_handle);
    
    /*
     * @brief Accept held incoming call in the AG.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_rrh_accept_held_call(hci_con_handle_t acl_handle);
    
    /*
     * @brief Reject held incoming call in the AG.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_rrh_reject_held_call(hci_con_handle_t acl_handle);
    
    /*
     * @brief Query the AG subscriber number.
     * The result is reported via HFP_SUBEVENT_SUBSCRIBER_NUMBER_INFORMATION.
     * @param bd_addr Bluetooth address of the AG
     */
    void hfp_hf_query_subscriber_number(hci_con_handle_t acl_handle);
    
    /*
     * @brief Set HF indicator.
     * @param bd_addr Bluetooth address of the AG
     * @param assigned_number
     * @param value
     */
    void hfp_hf_set_hf_indicator(hci_con_handle_t acl_handle, int assigned_number, int value);
    


## HFP Audio Gateway API {#sec:hfpAGAPIAppendix}

    typedef struct {
        uint8_t type;
        const char * number;
    } hfp_phone_number_t;
    
    /**
     * @brief Create HFP Audio Gateway (AG) SDP service record. 
     * @param service
     * @param rfcomm_channel_nr
     * @param name
     * @param ability_to_reject_call
     * @param suported_features 32-bit bitmap, see HFP_AGSF_* values in hfp.h
     * @param wide_band_speech supported 
     */
    void hfp_ag_create_sdp_record(uint8_t * service, uint32_t service_record_handle, int rfcomm_channel_nr, const char * name, uint8_t ability_to_reject_call, uint16_t supported_features, int wide_band_speech);
    
    /**
     * @brief Set up HFP Audio Gateway (AG) device without additional supported features.
     * @param rfcomm_channel_nr
     */
    void hfp_ag_init(uint16_t rfcomm_channel_nr);
    
    /**
     * @brief Set codecs. 
     * @param codecs_nr
     * @param codecs
     */
    void hfp_ag_init_codecs(int codecs_nr, uint8_t * codecs);
    
    /**
     * @brief Set supported features.
     * @param supported_features 32-bit bitmap, see HFP_AGSF_* values in hfp.h
     */
    void hfp_ag_init_supported_features(uint32_t supported_features);
    
    /**
     * @brief Set AG indicators. 
     * @param indicators_nr
     * @param indicators
     */
    void hfp_ag_init_ag_indicators(int ag_indicators_nr, hfp_ag_indicator_t * ag_indicators);
    
    /**
     * @brief Set HF indicators. 
     * @param indicators_nr
     * @param indicators
     */
    void hfp_ag_init_hf_indicators(int hf_indicators_nr, hfp_generic_status_indicator_t * hf_indicators);
    
    /**
     * @brief Set Call Hold services. 
     * @param indicators_nr
     * @param indicators
     */
    void hfp_ag_init_call_hold_services(int call_hold_services_nr, const char * call_hold_services[]);
    
    
    /**
     * @brief Register callback for the HFP Audio Gateway (AG) client. 
     * @param callback
     */
    void hfp_ag_register_packet_handler(btstack_packet_handler_t callback);
    
    /**
     * @brief Enable in-band ring tone.
     * @param use_in_band_ring_tone
     */
    void hfp_ag_set_use_in_band_ring_tone(int use_in_band_ring_tone);
    
    
    // actions used by local device / user
    
    /**
     * @brief Establish RFCOMM connection, and perform service level connection agreement:
     * - exchange of supported features
     * - report Audio Gateway (AG) indicators and their status 
     * - enable indicator status update in the AG
     * - accept the information about available codecs in the Hands-Free (HF), if sent
     * - report own information describing the call hold and multiparty services, if possible
     * - report which HF indicators are enabled on the AG, if possible
     * The status of SLC connection establishment is reported via
     * HFP_SUBEVENT_SERVICE_LEVEL_CONNECTION_ESTABLISHED.
     *
     * @param bd_addr Bluetooth address of the HF
     */
    void hfp_ag_establish_service_level_connection(bd_addr_t bd_addr);
    
    /**
     * @brief Release the RFCOMM channel and the audio connection between the HF and the AG. 
     * If the audio connection exists, it will be released.
     * The status of releasing the SLC connection is reported via
     * HFP_SUBEVENT_SERVICE_LEVEL_CONNECTION_RELEASED.
     *
     * @param bd_addr Bluetooth address of the HF
     */
    void hfp_ag_release_service_level_connection(hci_con_handle_t acl_handle);
    
    /**
     * @brief Establish audio connection.
     * The status of Audio connection establishment is reported via is reported via
     * HSP_SUBEVENT_AUDIO_CONNECTION_COMPLETE.
     * @param bd_addr Bluetooth address of the HF
     */
    void hfp_ag_establish_audio_connection(hci_con_handle_t acl_handle);
    
    /**
     * @brief Release audio connection.
     * The status of releasing the Audio connection is reported via is reported via
     * HSP_SUBEVENT_AUDIO_DISCONNECTION_COMPLETE.
     * @param bd_addr Bluetooth address of the HF
     */
    void hfp_ag_release_audio_connection(hci_con_handle_t acl_handle);
    
    /**
     * @brief Put the current call on hold, if it exists, and accept incoming call. 
     */
    void hfp_ag_answer_incoming_call(void);
    
    /**
     * @brief Join held call with active call.
     */
    void hfp_ag_join_held_call(void);
    
    /**
     * @brief Reject incoming call, if exists, or terminate active call.
     */
    void hfp_ag_terminate_call(void);
    
    /*
     * @brief Put incoming call on hold.
     */
    void hfp_ag_hold_incoming_call(void);
    
    /*
     * @brief Accept the held incoming call.
     */
    void hfp_ag_accept_held_incoming_call(void);
    
    /*
     * @brief Reject the held incoming call.
     */
    void hfp_ag_reject_held_incoming_call(void);
    
    /*
     * @brief Set microphone gain. 
     * @param bd_addr Bluetooth address of the HF
     * @param gain Valid range: [0,15]
     */
    void hfp_ag_set_microphone_gain(hci_con_handle_t acl_handle, int gain);
    
    /*
     * @brief Set speaker gain.
     * @param bd_addr Bluetooth address of the HF
     * @param gain Valid range: [0,15]
     */
    void hfp_ag_set_speaker_gain(hci_con_handle_t acl_handle, int gain);
    
    /*
     * @brief Set battery level.
     * @param level Valid range: [0,5]
     */
    void hfp_ag_set_battery_level(int level);
    
    /*
     * @brief Clear last dialed number.
     */
    void hfp_ag_clear_last_dialed_number(void);
    
    /*
     * @brief Notify the HF that an incoming call is waiting 
     * during an ongoing call. The notification will be sent only if the HF has
     * has previously enabled the "Call Waiting notification" in the AG. 
     * @param bd_addr Bluetooth address of the HF
     */
    void hfp_ag_notify_incoming_call_waiting(hci_con_handle_t acl_handle);
    
    // Voice Recognition
    
    /*
     * @brief Activate voice recognition.
     * @param bd_addr Bluetooth address of the HF
     * @param activate
     */
    void hfp_ag_activate_voice_recognition(hci_con_handle_t acl_handle, int activate);
    
    /*
     * @brief Send a phone number back to the HF.
     * @param bd_addr Bluetooth address of the HF
     * @param phone_number
     */
    void hfp_ag_send_phone_number_for_voice_tag(hci_con_handle_t acl_handle, const char * phone_number);
    
    /*
     * @brief Reject sending a phone number to the HF.
     * @param bd_addr Bluetooth address of the HF
     */
    void hfp_ag_reject_phone_number_for_voice_tag(hci_con_handle_t acl_handle);
    
    /**
     * @brief Store phone number with initiated call.
     * @param type
     * @param number
     */
    void hfp_ag_set_clip(uint8_t type, const char * number);
    
    
    // Cellular Actions
    
    /**
     * @brief Pass the accept incoming call event to the AG.
     */
    void hfp_ag_incoming_call(void);
    
    /**
     * @brief Pass the reject outgoing call event to the AG.
     */
    void hfp_ag_outgoing_call_rejected(void);
    
    /**
     * @brief Pass the accept outgoing call event to the AG.
     */
    void hfp_ag_outgoing_call_accepted(void);
    
    /**
     * @brief Pass the outgoing call ringing event to the AG.
     */
    void hfp_ag_outgoing_call_ringing(void);
    
    /**
     * @brief Pass the outgoing call established event to the AG.
     */
    void hfp_ag_outgoing_call_established(void);
    
    /**
     * @brief Pass the call droped event to the AG.
     */
    void hfp_ag_call_dropped(void);
    
    /*
     * @brief Set network registration status.  
     * @param status 0 - not registered, 1 - registered 
     */
    void hfp_ag_set_registration_status(int status);
    
    /*
     * @brief Set network signal strength.
     * @param strength [0-5]
     */
    void hfp_ag_set_signal_strength(int strength);
    
    /*
     * @brief Set roaming status.
     * @param status 0 - no roaming, 1 - roaming active
     */
    void hfp_ag_set_roaming_status(int status);
    
    /*
     * @brief Set subcriber number information, e.g. the phone number 
     * @param numbers
     * @param numbers_count
     */
    void hfp_ag_set_subcriber_number_information(hfp_phone_number_t * numbers, int numbers_count);
    
    /*
     * @brief Called by cellular unit after a DTMF code was transmitted, so that the next one can be emitted.
     * @param bd_addr Bluetooth address of the HF 
     */
    void hfp_ag_send_dtmf_code_done(hci_con_handle_t acl_handle);
    
    /**
     * @brief Report Extended Audio Gateway Error result codes in the AG.
     * Whenever there is an error relating to the functionality of the AG as a 
     * result of AT command, the AG shall send +CME ERROR:
     * - +CME ERROR: 0  - AG failure
     * - +CME ERROR: 1  - no connection to phone 
     * - +CME ERROR: 3  - operation not allowed 
     * - +CME ERROR: 4  - operation not supported 
     * - +CME ERROR: 5  - PH-SIM PIN required 
     * - +CME ERROR: 10 - SIM not inserted 
     * - +CME ERROR: 11 - SIM PIN required 
     * - +CME ERROR: 12 - SIM PUK required 
     * - +CME ERROR: 13 - SIM failure
     * - +CME ERROR: 14 - SIM busy
     * - +CME ERROR: 16 - incorrect password 
     * - +CME ERROR: 17 - SIM PIN2 required 
     * - +CME ERROR: 18 - SIM PUK2 required 
     * - +CME ERROR: 20 - memory full
     * - +CME ERROR: 21 - invalid index
     * - +CME ERROR: 23 - memory failure
     * - +CME ERROR: 24 - text string too long
     * - +CME ERROR: 25 - invalid characters in text string
     * - +CME ERROR: 26 - dial string too long
     * - +CME ERROR: 27 - invalid characters in dial string
     * - +CME ERROR: 30 - no network service
     * - +CME ERROR: 31 - network Timeout.
     * - +CME ERROR: 32 - network not allowed – Emergency calls only
     *
     * @param bd_addr Bluetooth address of the HF
     * @param error
     */
    void hfp_ag_report_extended_audio_gateway_error_result_code(hci_con_handle_t acl_handle, hfp_cme_error_t error);
    


## PAN API {#sec:panAPIAppendix}

    
    /** 
     * @brief Creates SDP record for PANU BNEP service in provided empty buffer.
     * @note Make sure the buffer is big enough.
     *
     * @param service is an empty buffer to store service record
     * @param service_record_handle for new service
     * @param network_packet_types array of types terminated by a 0x0000 entry
     * @param name if NULL, the default service name will be assigned
     * @param description if NULL, the default service description will be assigned
     * @param security_desc 
     */
    void pan_create_panu_sdp_record(uint8_t *service, uint32_t service_record_handle, uint16_t * network_packet_types, const char *name,
    	const char *description, security_description_t security_desc);
    
    /** 
     * @brief Creates SDP record for GN BNEP service in provided empty buffer.
     * @note Make sure the buffer is big enough.
     *
     * @param service is an empty buffer to store service record
     * @param service_record_handle for new service
     * @param network_packet_types array of types terminated by a 0x0000 entry
     * @param name if NULL, the default service name will be assigned
     * @param description if NULL, the default service description will be assigned
     * @param security_desc 
     * @param IPv4Subnet is optional subnet definition, e.g. "10.0.0.0/8"
     * @param IPv6Subnet is optional subnet definition given in the standard IETF format with the absolute attribute IDs
     */
    void pan_create_gn_sdp_service(uint8_t *service, uint32_t service_record_handle, uint16_t * network_packet_types, const char *name,
    	const char *description, security_description_t security_desc, const char *IPv4Subnet,
    	const char *IPv6Subnet);
    
    /** 
     * @brief Creates SDP record for NAP BNEP service in provided empty buffer.
     * @note Make sure the buffer is big enough.
     *
     * @param service is an empty buffer to store service record
     * @param service_record_handle for new service
     * @param name if NULL, the default service name will be assigned
     * @param network_packet_types array of types terminated by a 0x0000 entry
     * @param description if NULL, the default service description will be assigned
     * @param security_desc 
     * @param net_access_type type of available network access
     * @param max_net_access_rate based on net_access_type measured in byte/s
     * @param IPv4Subnet is optional subnet definition, e.g. "10.0.0.0/8"
     * @param IPv6Subnet is optional subnet definition given in the standard IETF format with the absolute attribute IDs
     */
    void pan_create_nap_sdp_record(uint8_t *service, uint32_t service_record_handle, uint16_t * network_packet_types, const char *name,
    	const char *description, security_description_t security_desc, net_access_type_t net_access_type,
    	uint32_t max_net_access_rate, const char *IPv4Subnet, const char *IPv6Subnet);
    


## RFCOMM API {#sec:rfcommAPIAppendix}

    
    /** 
     * @brief Set up RFCOMM.
     */
    void rfcomm_init(void);
    
    /** 
     * @brief Set security level required for incoming connections, need to be called before registering services.
     */
    void rfcomm_set_required_security_level(gap_security_level_t security_level);
    
    /* 
     * @brief Create RFCOMM connection to a given server channel on a remote deivce.
     * This channel will automatically provide enough credits to the remote side.
     * @param addr
     * @param server_channel
     * @param out_cid
     * @result status
     */
    uint8_t rfcomm_create_channel(btstack_packet_handler_t packet_handler, bd_addr_t addr, uint8_t server_channel, uint16_t * out_cid);
    
    /* 
     * @brief Create RFCOMM connection to a given server channel on a remote deivce.
     * This channel will use explicit credit management. During channel establishment, an initial  amount of credits is provided.
     * @param addr
     * @param server_channel
     * @param initial_credits
     * @param out_cid
     * @result status
     */
    uint8_t rfcomm_create_channel_with_initial_credits(btstack_packet_handler_t packet_handler, bd_addr_t addr, uint8_t server_channel, uint8_t initial_credits, uint16_t * out_cid);
    
    /** 
     * @brief Disconnects RFCOMM channel with given identifier. 
     */
    void rfcomm_disconnect(uint16_t rfcomm_cid);
    
    /** 
     * @brief Registers RFCOMM service for a server channel and a maximum frame size, and assigns a packet handler.
     * This channel provides credits automatically to the remote side -> no flow control
     * @param packet handler for all channels of this service
     * @param channel 
     * @param max_frame_size
     */
    uint8_t rfcomm_register_service(btstack_packet_handler_t packet_handler, uint8_t channel, uint16_t max_frame_size);
    
    /** 
     * @brief Registers RFCOMM service for a server channel and a maximum frame size, and assigns a packet handler. 
     * This channel will use explicit credit management. During channel establishment, an initial amount of credits is provided.
     * @param packet handler for all channels of this service
     * @param channel 
     * @param max_frame_size
     * @param initial_credits
     */
    uint8_t rfcomm_register_service_with_initial_credits(btstack_packet_handler_t packet_handler, uint8_t channel, uint16_t max_frame_size, uint8_t initial_credits);
    
    /** 
     * @brief Unregister RFCOMM service.
     */
    void rfcomm_unregister_service(uint8_t service_channel);
    
    /** 
     * @brief Accepts incoming RFCOMM connection.
     */
    void rfcomm_accept_connection(uint16_t rfcomm_cid);
    
    /** 
     * @brief Deny incoming RFCOMM connection.
     */
    void rfcomm_decline_connection(uint16_t rfcomm_cid);
    
    /** 
     * @brief Grant more incoming credits to the remote side for the given RFCOMM channel identifier.
     */
    void rfcomm_grant_credits(uint16_t rfcomm_cid, uint8_t credits);
    
    /** 
     * @brief Checks if RFCOMM can send packet. 
     * @param rfcomm_cid
     * @result != 0 if can send now
     */
    int rfcomm_can_send_packet_now(uint16_t rfcomm_cid);
    
    /** 
     * @brief Request emission of RFCOMM_EVENT_CAN_SEND_NOW as soon as possible
     * @note RFCOMM_EVENT_CAN_SEND_NOW might be emitted during call to this function
     *       so packet handler should be ready to handle it
     * @param rfcomm_cid
     */
    void rfcomm_request_can_send_now_event(uint16_t rfcomm_cid);
    
    /** 
     * @brief Sends RFCOMM data packet to the RFCOMM channel with given identifier.
     * @param rfcomm_cid
     */
    int  rfcomm_send(uint16_t rfcomm_cid, uint8_t *data, uint16_t len);
    
    /** 
     * @brief Sends Local Line Status, see LINE_STATUS_..
     * @param rfcomm_cid
     * @param line_status
     */
    int rfcomm_send_local_line_status(uint16_t rfcomm_cid, uint8_t line_status);
    
    /** 
     * @brief Send local modem status. see MODEM_STAUS_..
     * @param rfcomm_cid
     * @param modem_status
     */
    int rfcomm_send_modem_status(uint16_t rfcomm_cid, uint8_t modem_status);
    
    /** 
     * @brief Configure remote port 
     * @param rfcomm_cid
     * @param baud_rate
     * @param data_bits
     * @param stop_bits
     * @param parity
     * @param flow_control
     */
    int rfcomm_send_port_configuration(uint16_t rfcomm_cid, rpn_baud_t baud_rate, rpn_data_bits_t data_bits, rpn_stop_bits_t stop_bits, rpn_parity_t parity, rpn_flow_control_t flow_control);
    
    /** 
     * @brief Query remote port 
     * @param rfcomm_cid
     */
    int rfcomm_query_port_configuration(uint16_t rfcomm_cid);
    
    /** 
     * @brief Query max frame size
     * @param rfcomm_cid
     */
    uint16_t  rfcomm_get_max_frame_size(uint16_t rfcomm_cid);
    
    /** 
     * @brief Allow to create RFCOMM packet in outgoing buffer.
     * if (rfcomm_can_send_packet_now(cid)){
     *     rfcomm_reserve_packet_buffer();
     *     uint8_t * buffer = rfcomm_get_outgoing_buffer();
     *     uint16_t buffer_size = rfcomm_get_max_frame_size(cid);
     *     // .. setup data in buffer with len
     *     rfcomm_send_prepared(cid, len)
     * }
     */
    int       rfcomm_reserve_packet_buffer(void);
    uint8_t * rfcomm_get_outgoing_buffer(void);
    int       rfcomm_send_prepared(uint16_t rfcomm_cid, uint16_t len);
    void      rfcomm_release_packet_buffer(void);
    
    /**
     * CRC8 functions using ETSI TS 101 369 V6.3.0.
     * Only used by RFCOMM
     */
    uint8_t crc8_check(uint8_t *data, uint16_t len, uint8_t check_sum);
    uint8_t crc8_calc(uint8_t *data, uint16_t len);
    


## SDP Client API {#sec:sdpClientAPIAppendix}

    
    typedef struct de_state {
        uint8_t  in_state_GET_DE_HEADER_LENGTH ;
        uint32_t addon_header_bytes;
        uint32_t de_size;
        uint32_t de_offset;
    } de_state_t; 
    
    void de_state_init(de_state_t * state);
    int  de_state_size(uint8_t eventByte, de_state_t *de_state);
    
    /** 
     * @brief Checks if the SDP Client is ready
     * @return 1 when no query is active
     */
    int sdp_client_ready(void);
    
    /** 
     * @brief Queries the SDP service of the remote device given a service search pattern and a list of attribute IDs. 
     * The remote data is handled by the SDP parser. The SDP parser delivers attribute values and done event via the callback.
     * @param callback for attributes values and done event
     * @param remote address
     * @param des_service_search_pattern 
     * @param des_attribute_id_list
     */
    uint8_t sdp_client_query(btstack_packet_handler_t callback, bd_addr_t remote, const uint8_t * des_service_search_pattern, const uint8_t * des_attribute_id_list);
    
    /*
     * @brief Searches SDP records on a remote device for all services with a given UUID.
     * @note calls sdp_client_query with service search pattern based on uuid16
     */
    uint8_t sdp_client_query_uuid16(btstack_packet_handler_t callback, bd_addr_t remote, uint16_t uuid16);
    
    /*
     * @brief Searches SDP records on a remote device for all services with a given UUID.
     * @note calls sdp_client_query with service search pattern based on uuid128
     */
    uint8_t sdp_client_query_uuid128(btstack_packet_handler_t callback, bd_addr_t remote, const uint8_t* uuid128);
    
    
    /** 
     * @brief Retrieves all attribute IDs of a SDP record specified by its service record handle and a list of attribute IDs. 
     * The remote data is handled by the SDP parser. The SDP parser delivers attribute values and done event via the callback.
     * @note only provided if ENABLE_SDP_EXTRA_QUERIES is defined
     * @param callback for attributes values and done event 
     * @param remote address
     * @param search_service_record_handle 
     * @param des_attributeIDList
     */
    uint8_t sdp_client_service_attribute_search(btstack_packet_handler_t callback, bd_addr_t remote, uint32_t search_service_record_handle, const uint8_t * des_attributeIDList);
    
    /** 
     * @brief Query the list of SDP records that match a given service search pattern. 
     * The remote data is handled by the SDP parser. The SDP parser delivers attribute values and done event via the callback.
     * @note only provided if ENABLE_SDP_EXTRA_QUERIES is defined
     * @param callback for attributes values and done event
     * @param remote address
     * @param des_service_search_pattern 
     */
    uint8_t sdp_client_service_search(btstack_packet_handler_t callback, bd_addr_t remote, const uint8_t * des_service_search_pattern);
    
    #ifdef ENABLE_SDP_EXTRA_QUERIES
    void sdp_client_parse_service_record_handle_list(uint8_t* packet, uint16_t total_count, uint16_t current_count);
    #endif
    


## SDP RFCOMM Query API {#sec:sdpQueriesAPIAppendix}

    
    /** 
     * @brief Searches SDP records on a remote device for RFCOMM services with a given 16-bit UUID.
     * @note calls sdp_service_search_pattern_for_uuid16 that uses global buffer
     */
    uint8_t sdp_client_query_rfcomm_channel_and_name_for_uuid(btstack_packet_handler_t callback, bd_addr_t remote, uint16_t uuid);
    
    /** 
     * @brief Searches SDP records on a remote device for RFCOMM services with a given 128-bit UUID.
     * @note calls sdp_service_search_pattern_for_uuid128 that uses global buffer
     */
    uint8_t sdp_client_query_rfcomm_channel_and_name_for_uuid128(btstack_packet_handler_t callback, bd_addr_t remote, const uint8_t * uuid128);
    
    /** 
     * @brief Searches SDP records on a remote device for RFCOMM services with a given service search pattern.
     */
    uint8_t sdp_client_query_rfcomm_channel_and_name_for_search_pattern(btstack_packet_handler_t callback, bd_addr_t remote, const uint8_t * des_serviceSearchPattern);
    


## SDP Server API {#sec:sdpSrvAPIAppendix}

    
    /** 
     * @brief Set up SDP.
     */
    void sdp_init(void);
    
    /**
     * @brief Register Service Record with database using ServiceRecordHandle stored in record
     * @pre AttributeIDs are in ascending order
     * @pre ServiceRecordHandle is first attribute and valid
     * @param record is not copied!
     * @result status
     */
    uint8_t sdp_register_service(const uint8_t * record);
    
    /** 
     * @brief Unregister service record internally.
     */
    void sdp_unregister_service(uint32_t service_record_handle);
    


## SDP Utils API {#sec:sdpUtilAPIAppendix}

        
    typedef enum {
        DE_NIL = 0,
        DE_UINT,
        DE_INT,
        DE_UUID,
        DE_STRING,
        DE_BOOL,
        DE_DES,
        DE_DEA,
        DE_URL
    } de_type_t;
    
    typedef enum {
        DE_SIZE_8 = 0,
        DE_SIZE_16,
        DE_SIZE_32,
        DE_SIZE_64,
        DE_SIZE_128,
        DE_SIZE_VAR_8,
        DE_SIZE_VAR_16,
        DE_SIZE_VAR_32
    } de_size_t;
    
    // MARK: DateElement
    void      de_dump_data_element(const uint8_t * record);
    int       de_get_len(const uint8_t * header);
    de_size_t de_get_size_type(const uint8_t * header);
    de_type_t de_get_element_type(const uint8_t * header);
    int       de_get_header_size(const uint8_t * header);
    int       de_element_get_uint16(const uint8_t * element, uint16_t * value);
    int       de_get_data_size(const uint8_t * header);
    uint32_t  de_get_uuid32(const uint8_t * element);
    int       de_get_normalized_uuid(uint8_t *uuid128, const uint8_t *element);
    
    void      de_create_sequence(uint8_t * header);
    void      de_store_descriptor_with_len(uint8_t * header, de_type_t type, de_size_t size, uint32_t len);
    uint8_t * de_push_sequence(uint8_t *header);
    void      de_pop_sequence(uint8_t * parent, uint8_t * child);
    void      de_add_number(uint8_t *seq, de_type_t type, de_size_t size, uint32_t value);
    void      de_add_data( uint8_t *seq, de_type_t type, uint16_t size, uint8_t *data);
    
    void      de_add_uuid128(uint8_t * seq, uint8_t * uuid);
    
    // MARK: DES iterator
    typedef struct {
        uint8_t * element;
        uint16_t pos;
        uint16_t length;
    } des_iterator_t;
    
    int des_iterator_init(des_iterator_t * it, uint8_t * element);
    int  des_iterator_has_more(des_iterator_t * it);
    de_type_t des_iterator_get_type (des_iterator_t * it);
    uint16_t des_iterator_get_size (des_iterator_t * it);
    uint8_t * des_iterator_get_element(des_iterator_t * it);
    void des_iterator_next(des_iterator_t * it);
    
    // MARK: SDP
    uint16_t  sdp_append_attributes_in_attributeIDList(uint8_t *record, uint8_t *attributeIDList, uint16_t startOffset, uint16_t maxBytes, uint8_t *buffer);
    uint8_t * sdp_get_attribute_value_for_attribute_id(uint8_t * record, uint16_t attributeID);
    uint8_t   sdp_set_attribute_value_for_attribute_id(uint8_t * record, uint16_t attributeID, uint32_t value);
    int       sdp_record_matches_service_search_pattern(uint8_t *record, uint8_t *serviceSearchPattern);
    int       spd_get_filtered_size(uint8_t *record, uint8_t *attributeIDList);
    int       sdp_filter_attributes_in_attributeIDList(uint8_t *record, uint8_t *attributeIDList, uint16_t startOffset, uint16_t maxBytes, uint16_t *usedBytes, uint8_t *buffer);  
    int       sdp_attribute_list_constains_id(uint8_t *attributeIDList, uint16_t attributeID);
    int       sdp_traversal_match_pattern(uint8_t * element, de_type_t attributeType, de_size_t size, void *my_context);
    
    /*
     * @brief Returns service search pattern for given UUID-16
     * @note Uses fixed buffer
     */
    uint8_t* sdp_service_search_pattern_for_uuid16(uint16_t uuid16);
    
    /*
     * @brief Returns service search pattern for given UUID-128
     * @note Uses fixed buffer
     */
    uint8_t* sdp_service_search_pattern_for_uuid128(const uint8_t * uuid128);
    


## BLE Advertisements Parser API {#sec:advParserAPIAppendix}

    
    typedef struct ad_context {
         const uint8_t * data;
         uint8_t   offset;
         uint8_t   length;
    } ad_context_t;
    
    // Advertising or Scan Response data iterator
    void ad_iterator_init(ad_context_t *context, uint8_t ad_len, const uint8_t * ad_data);
    int  ad_iterator_has_more(const ad_context_t * context);
    void ad_iterator_next(ad_context_t * context);
    
    // Access functions
    uint8_t         ad_iterator_get_data_type(const ad_context_t * context);
    uint8_t         ad_iterator_get_data_len(const ad_context_t * context);
    const uint8_t * ad_iterator_get_data(const ad_context_t * context);
    
    // convenience function on complete advertisements
    int ad_data_contains_uuid16(uint8_t ad_len, const uint8_t * ad_data, uint16_t uuid);
    int ad_data_contains_uuid128(uint8_t ad_len, const uint8_t * ad_data, const uint8_t * uuid128);
    


## BTstack Chipset API {#sec:btMemoryAPIAppendix}



## BTstack Hardware Control API {#sec:btControlAPIAppendix}



## HCI Event Getter API {#sec:btEventAPIAppendix}

    
    /**
     * @brief Get event type
     * @param event
     * @return type of event
     */
    static inline uint8_t hci_event_packet_get_type(const uint8_t * event){
        return event[0];
    }
    
    /***
     * @brief Get subevent code for ancs event
     * @param event packet
     * @return subevent_code
     */
    static inline uint8_t hci_event_ancs_meta_get_subevent_code(const uint8_t * event){
        return event[2];
    }
    /***
     * @brief Get subevent code for avdtp event
     * @param event packet
     * @return subevent_code
     */
    static inline uint8_t hci_event_avdtp_meta_get_subevent_code(const uint8_t * event){
        return event[2];
    }
    /***
     * @brief Get subevent code for a2dp event
     * @param event packet
     * @return subevent_code
     */
    static inline uint8_t hci_event_a2dp_meta_get_subevent_code(const uint8_t * event){
        return event[2];
    }
    /***
     * @brief Get subevent code for avrcp event
     * @param event packet
     * @return subevent_code
     */
    static inline uint8_t hci_event_avrcp_meta_get_subevent_code(const uint8_t * event){
        return event[2];
    }
    /***
     * @brief Get subevent code for goep event
     * @param event packet
     * @return subevent_code
     */
    static inline uint8_t hci_event_goep_meta_get_subevent_code(const uint8_t * event){
        return event[2];
    }
    /***
     * @brief Get subevent code for hfp event
     * @param event packet
     * @return subevent_code
     */
    static inline uint8_t hci_event_hfp_meta_get_subevent_code(const uint8_t * event){
        return event[2];
    }
    /***
     * @brief Get subevent code for hsp event
     * @param event packet
     * @return subevent_code
     */
    static inline uint8_t hci_event_hsp_meta_get_subevent_code(const uint8_t * event){
        return event[2];
    }
    /***
     * @brief Get subevent code for pbap event
     * @param event packet
     * @return subevent_code
     */
    static inline uint8_t hci_event_pbap_meta_get_subevent_code(const uint8_t * event){
        return event[2];
    }
    /***
     * @brief Get subevent code for le event
     * @param event packet
     * @return subevent_code
     */
    static inline uint8_t hci_event_le_meta_get_subevent_code(const uint8_t * event){
        return event[2];
    }
    /***
     * @brief Get subevent code for hid event
     * @param event packet
     * @return subevent_code
     */
    static inline uint8_t hci_event_hid_meta_get_subevent_code(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field status from event HCI_EVENT_INQUIRY_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_inquiry_complete_get_status(const uint8_t * event){
        return event[2];
    }
    
    /**
     * @brief Get field num_responses from event HCI_EVENT_INQUIRY_RESULT
     * @param event packet
     * @return num_responses
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_inquiry_result_get_num_responses(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field bd_addr from event HCI_EVENT_INQUIRY_RESULT
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void hci_event_inquiry_result_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[3], bd_addr);    
    }
    /**
     * @brief Get field page_scan_repetition_mode from event HCI_EVENT_INQUIRY_RESULT
     * @param event packet
     * @return page_scan_repetition_mode
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_inquiry_result_get_page_scan_repetition_mode(const uint8_t * event){
        return event[9];
    }
    /**
     * @brief Get field reserved1 from event HCI_EVENT_INQUIRY_RESULT
     * @param event packet
     * @return reserved1
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_inquiry_result_get_reserved1(const uint8_t * event){
        return event[10];
    }
    /**
     * @brief Get field reserved2 from event HCI_EVENT_INQUIRY_RESULT
     * @param event packet
     * @return reserved2
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_inquiry_result_get_reserved2(const uint8_t * event){
        return event[11];
    }
    /**
     * @brief Get field class_of_device from event HCI_EVENT_INQUIRY_RESULT
     * @param event packet
     * @return class_of_device
     * @note: btstack_type 3
     */
    static inline uint32_t hci_event_inquiry_result_get_class_of_device(const uint8_t * event){
        return little_endian_read_24(event, 12);
    }
    /**
     * @brief Get field clock_offset from event HCI_EVENT_INQUIRY_RESULT
     * @param event packet
     * @return clock_offset
     * @note: btstack_type 2
     */
    static inline uint16_t hci_event_inquiry_result_get_clock_offset(const uint8_t * event){
        return little_endian_read_16(event, 15);
    }
    
    /**
     * @brief Get field status from event HCI_EVENT_CONNECTION_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_connection_complete_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field connection_handle from event HCI_EVENT_CONNECTION_COMPLETE
     * @param event packet
     * @return connection_handle
     * @note: btstack_type 2
     */
    static inline uint16_t hci_event_connection_complete_get_connection_handle(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field bd_addr from event HCI_EVENT_CONNECTION_COMPLETE
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void hci_event_connection_complete_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[5], bd_addr);    
    }
    /**
     * @brief Get field link_type from event HCI_EVENT_CONNECTION_COMPLETE
     * @param event packet
     * @return link_type
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_connection_complete_get_link_type(const uint8_t * event){
        return event[11];
    }
    /**
     * @brief Get field encryption_enabled from event HCI_EVENT_CONNECTION_COMPLETE
     * @param event packet
     * @return encryption_enabled
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_connection_complete_get_encryption_enabled(const uint8_t * event){
        return event[12];
    }
    
    /**
     * @brief Get field bd_addr from event HCI_EVENT_CONNECTION_REQUEST
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void hci_event_connection_request_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[2], bd_addr);    
    }
    /**
     * @brief Get field class_of_device from event HCI_EVENT_CONNECTION_REQUEST
     * @param event packet
     * @return class_of_device
     * @note: btstack_type 3
     */
    static inline uint32_t hci_event_connection_request_get_class_of_device(const uint8_t * event){
        return little_endian_read_24(event, 8);
    }
    /**
     * @brief Get field link_type from event HCI_EVENT_CONNECTION_REQUEST
     * @param event packet
     * @return link_type
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_connection_request_get_link_type(const uint8_t * event){
        return event[11];
    }
    
    /**
     * @brief Get field status from event HCI_EVENT_DISCONNECTION_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_disconnection_complete_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field connection_handle from event HCI_EVENT_DISCONNECTION_COMPLETE
     * @param event packet
     * @return connection_handle
     * @note: btstack_type 2
     */
    static inline uint16_t hci_event_disconnection_complete_get_connection_handle(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field reason from event HCI_EVENT_DISCONNECTION_COMPLETE
     * @param event packet
     * @return reason
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_disconnection_complete_get_reason(const uint8_t * event){
        return event[5];
    }
    
    /**
     * @brief Get field status from event HCI_EVENT_AUTHENTICATION_COMPLETE_EVENT
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_authentication_complete_event_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field connection_handle from event HCI_EVENT_AUTHENTICATION_COMPLETE_EVENT
     * @param event packet
     * @return connection_handle
     * @note: btstack_type 2
     */
    static inline uint16_t hci_event_authentication_complete_event_get_connection_handle(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    
    /**
     * @brief Get field status from event HCI_EVENT_REMOTE_NAME_REQUEST_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_remote_name_request_complete_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field bd_addr from event HCI_EVENT_REMOTE_NAME_REQUEST_COMPLETE
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void hci_event_remote_name_request_complete_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[3], bd_addr);    
    }
    /**
     * @brief Get field remote_name from event HCI_EVENT_REMOTE_NAME_REQUEST_COMPLETE
     * @param event packet
     * @return remote_name
     * @note: btstack_type N
     */
    static inline const char * hci_event_remote_name_request_complete_get_remote_name(const uint8_t * event){
        return (const char *) &event[9];
    }
    
    /**
     * @brief Get field status from event HCI_EVENT_ENCRYPTION_CHANGE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_encryption_change_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field connection_handle from event HCI_EVENT_ENCRYPTION_CHANGE
     * @param event packet
     * @return connection_handle
     * @note: btstack_type 2
     */
    static inline uint16_t hci_event_encryption_change_get_connection_handle(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field encryption_enabled from event HCI_EVENT_ENCRYPTION_CHANGE
     * @param event packet
     * @return encryption_enabled
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_encryption_change_get_encryption_enabled(const uint8_t * event){
        return event[5];
    }
    
    /**
     * @brief Get field status from event HCI_EVENT_CHANGE_CONNECTION_LINK_KEY_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_change_connection_link_key_complete_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field connection_handle from event HCI_EVENT_CHANGE_CONNECTION_LINK_KEY_COMPLETE
     * @param event packet
     * @return connection_handle
     * @note: btstack_type 2
     */
    static inline uint16_t hci_event_change_connection_link_key_complete_get_connection_handle(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    
    /**
     * @brief Get field status from event HCI_EVENT_MASTER_LINK_KEY_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_master_link_key_complete_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field connection_handle from event HCI_EVENT_MASTER_LINK_KEY_COMPLETE
     * @param event packet
     * @return connection_handle
     * @note: btstack_type 2
     */
    static inline uint16_t hci_event_master_link_key_complete_get_connection_handle(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field key_flag from event HCI_EVENT_MASTER_LINK_KEY_COMPLETE
     * @param event packet
     * @return key_flag
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_master_link_key_complete_get_key_flag(const uint8_t * event){
        return event[5];
    }
    
    /**
     * @brief Get field num_hci_command_packets from event HCI_EVENT_COMMAND_COMPLETE
     * @param event packet
     * @return num_hci_command_packets
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_command_complete_get_num_hci_command_packets(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field command_opcode from event HCI_EVENT_COMMAND_COMPLETE
     * @param event packet
     * @return command_opcode
     * @note: btstack_type 2
     */
    static inline uint16_t hci_event_command_complete_get_command_opcode(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field return_parameters from event HCI_EVENT_COMMAND_COMPLETE
     * @param event packet
     * @return return_parameters
     * @note: btstack_type R
     */
    static inline const uint8_t * hci_event_command_complete_get_return_parameters(const uint8_t * event){
        return &event[5];
    }
    
    /**
     * @brief Get field status from event HCI_EVENT_COMMAND_STATUS
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_command_status_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field num_hci_command_packets from event HCI_EVENT_COMMAND_STATUS
     * @param event packet
     * @return num_hci_command_packets
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_command_status_get_num_hci_command_packets(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field command_opcode from event HCI_EVENT_COMMAND_STATUS
     * @param event packet
     * @return command_opcode
     * @note: btstack_type 2
     */
    static inline uint16_t hci_event_command_status_get_command_opcode(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    
    /**
     * @brief Get field hardware_code from event HCI_EVENT_HARDWARE_ERROR
     * @param event packet
     * @return hardware_code
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_hardware_error_get_hardware_code(const uint8_t * event){
        return event[2];
    }
    
    /**
     * @brief Get field status from event HCI_EVENT_ROLE_CHANGE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_role_change_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field bd_addr from event HCI_EVENT_ROLE_CHANGE
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void hci_event_role_change_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[3], bd_addr);    
    }
    /**
     * @brief Get field role from event HCI_EVENT_ROLE_CHANGE
     * @param event packet
     * @return role
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_role_change_get_role(const uint8_t * event){
        return event[9];
    }
    
    /**
     * @brief Get field status from event HCI_EVENT_MODE_CHANGE_EVENT
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_mode_change_event_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field handle from event HCI_EVENT_MODE_CHANGE_EVENT
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t hci_event_mode_change_event_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field mode from event HCI_EVENT_MODE_CHANGE_EVENT
     * @param event packet
     * @return mode
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_mode_change_event_get_mode(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field interval from event HCI_EVENT_MODE_CHANGE_EVENT
     * @param event packet
     * @return interval
     * @note: btstack_type 2
     */
    static inline uint16_t hci_event_mode_change_event_get_interval(const uint8_t * event){
        return little_endian_read_16(event, 6);
    }
    
    /**
     * @brief Get field bd_addr from event HCI_EVENT_PIN_CODE_REQUEST
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void hci_event_pin_code_request_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[2], bd_addr);    
    }
    
    /**
     * @brief Get field bd_addr from event HCI_EVENT_LINK_KEY_REQUEST
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void hci_event_link_key_request_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[2], bd_addr);    
    }
    
    /**
     * @brief Get field link_type from event HCI_EVENT_DATA_BUFFER_OVERFLOW
     * @param event packet
     * @return link_type
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_data_buffer_overflow_get_link_type(const uint8_t * event){
        return event[2];
    }
    
    /**
     * @brief Get field handle from event HCI_EVENT_MAX_SLOTS_CHANGED
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t hci_event_max_slots_changed_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field lmp_max_slots from event HCI_EVENT_MAX_SLOTS_CHANGED
     * @param event packet
     * @return lmp_max_slots
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_max_slots_changed_get_lmp_max_slots(const uint8_t * event){
        return event[4];
    }
    
    /**
     * @brief Get field status from event HCI_EVENT_READ_CLOCK_OFFSET_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_read_clock_offset_complete_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field handle from event HCI_EVENT_READ_CLOCK_OFFSET_COMPLETE
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t hci_event_read_clock_offset_complete_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field clock_offset from event HCI_EVENT_READ_CLOCK_OFFSET_COMPLETE
     * @param event packet
     * @return clock_offset
     * @note: btstack_type 2
     */
    static inline uint16_t hci_event_read_clock_offset_complete_get_clock_offset(const uint8_t * event){
        return little_endian_read_16(event, 5);
    }
    
    /**
     * @brief Get field status from event HCI_EVENT_CONNECTION_PACKET_TYPE_CHANGED
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_connection_packet_type_changed_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field handle from event HCI_EVENT_CONNECTION_PACKET_TYPE_CHANGED
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t hci_event_connection_packet_type_changed_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field packet_types from event HCI_EVENT_CONNECTION_PACKET_TYPE_CHANGED
     * @param event packet
     * @return packet_types
     * @note: btstack_type 2
     */
    static inline uint16_t hci_event_connection_packet_type_changed_get_packet_types(const uint8_t * event){
        return little_endian_read_16(event, 5);
    }
    
    /**
     * @brief Get field num_responses from event HCI_EVENT_INQUIRY_RESULT_WITH_RSSI
     * @param event packet
     * @return num_responses
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_inquiry_result_with_rssi_get_num_responses(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field bd_addr from event HCI_EVENT_INQUIRY_RESULT_WITH_RSSI
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void hci_event_inquiry_result_with_rssi_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[3], bd_addr);    
    }
    /**
     * @brief Get field page_scan_repetition_mode from event HCI_EVENT_INQUIRY_RESULT_WITH_RSSI
     * @param event packet
     * @return page_scan_repetition_mode
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_inquiry_result_with_rssi_get_page_scan_repetition_mode(const uint8_t * event){
        return event[9];
    }
    /**
     * @brief Get field reserved from event HCI_EVENT_INQUIRY_RESULT_WITH_RSSI
     * @param event packet
     * @return reserved
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_inquiry_result_with_rssi_get_reserved(const uint8_t * event){
        return event[10];
    }
    /**
     * @brief Get field class_of_device from event HCI_EVENT_INQUIRY_RESULT_WITH_RSSI
     * @param event packet
     * @return class_of_device
     * @note: btstack_type 3
     */
    static inline uint32_t hci_event_inquiry_result_with_rssi_get_class_of_device(const uint8_t * event){
        return little_endian_read_24(event, 11);
    }
    /**
     * @brief Get field clock_offset from event HCI_EVENT_INQUIRY_RESULT_WITH_RSSI
     * @param event packet
     * @return clock_offset
     * @note: btstack_type 2
     */
    static inline uint16_t hci_event_inquiry_result_with_rssi_get_clock_offset(const uint8_t * event){
        return little_endian_read_16(event, 14);
    }
    /**
     * @brief Get field rssi from event HCI_EVENT_INQUIRY_RESULT_WITH_RSSI
     * @param event packet
     * @return rssi
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_inquiry_result_with_rssi_get_rssi(const uint8_t * event){
        return event[16];
    }
    
    /**
     * @brief Get field status from event HCI_EVENT_SYNCHRONOUS_CONNECTION_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_synchronous_connection_complete_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field handle from event HCI_EVENT_SYNCHRONOUS_CONNECTION_COMPLETE
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t hci_event_synchronous_connection_complete_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field bd_addr from event HCI_EVENT_SYNCHRONOUS_CONNECTION_COMPLETE
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void hci_event_synchronous_connection_complete_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[5], bd_addr);    
    }
    /**
     * @brief Get field link_type from event HCI_EVENT_SYNCHRONOUS_CONNECTION_COMPLETE
     * @param event packet
     * @return link_type
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_synchronous_connection_complete_get_link_type(const uint8_t * event){
        return event[11];
    }
    /**
     * @brief Get field transmission_interval from event HCI_EVENT_SYNCHRONOUS_CONNECTION_COMPLETE
     * @param event packet
     * @return transmission_interval
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_synchronous_connection_complete_get_transmission_interval(const uint8_t * event){
        return event[12];
    }
    /**
     * @brief Get field retransmission_interval from event HCI_EVENT_SYNCHRONOUS_CONNECTION_COMPLETE
     * @param event packet
     * @return retransmission_interval
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_synchronous_connection_complete_get_retransmission_interval(const uint8_t * event){
        return event[13];
    }
    /**
     * @brief Get field rx_packet_length from event HCI_EVENT_SYNCHRONOUS_CONNECTION_COMPLETE
     * @param event packet
     * @return rx_packet_length
     * @note: btstack_type 2
     */
    static inline uint16_t hci_event_synchronous_connection_complete_get_rx_packet_length(const uint8_t * event){
        return little_endian_read_16(event, 14);
    }
    /**
     * @brief Get field tx_packet_length from event HCI_EVENT_SYNCHRONOUS_CONNECTION_COMPLETE
     * @param event packet
     * @return tx_packet_length
     * @note: btstack_type 2
     */
    static inline uint16_t hci_event_synchronous_connection_complete_get_tx_packet_length(const uint8_t * event){
        return little_endian_read_16(event, 16);
    }
    /**
     * @brief Get field air_mode from event HCI_EVENT_SYNCHRONOUS_CONNECTION_COMPLETE
     * @param event packet
     * @return air_mode
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_synchronous_connection_complete_get_air_mode(const uint8_t * event){
        return event[18];
    }
    
    /**
     * @brief Get field num_responses from event HCI_EVENT_EXTENDED_INQUIRY_RESPONSE
     * @param event packet
     * @return num_responses
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_extended_inquiry_response_get_num_responses(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field bd_addr from event HCI_EVENT_EXTENDED_INQUIRY_RESPONSE
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void hci_event_extended_inquiry_response_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[3], bd_addr);    
    }
    /**
     * @brief Get field page_scan_repetition_mode from event HCI_EVENT_EXTENDED_INQUIRY_RESPONSE
     * @param event packet
     * @return page_scan_repetition_mode
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_extended_inquiry_response_get_page_scan_repetition_mode(const uint8_t * event){
        return event[9];
    }
    /**
     * @brief Get field reserved from event HCI_EVENT_EXTENDED_INQUIRY_RESPONSE
     * @param event packet
     * @return reserved
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_extended_inquiry_response_get_reserved(const uint8_t * event){
        return event[10];
    }
    /**
     * @brief Get field class_of_device from event HCI_EVENT_EXTENDED_INQUIRY_RESPONSE
     * @param event packet
     * @return class_of_device
     * @note: btstack_type 3
     */
    static inline uint32_t hci_event_extended_inquiry_response_get_class_of_device(const uint8_t * event){
        return little_endian_read_24(event, 11);
    }
    /**
     * @brief Get field clock_offset from event HCI_EVENT_EXTENDED_INQUIRY_RESPONSE
     * @param event packet
     * @return clock_offset
     * @note: btstack_type 2
     */
    static inline uint16_t hci_event_extended_inquiry_response_get_clock_offset(const uint8_t * event){
        return little_endian_read_16(event, 14);
    }
    /**
     * @brief Get field rssi from event HCI_EVENT_EXTENDED_INQUIRY_RESPONSE
     * @param event packet
     * @return rssi
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_extended_inquiry_response_get_rssi(const uint8_t * event){
        return event[16];
    }
    
    /**
     * @brief Get field status from event HCI_EVENT_ENCRYPTION_KEY_REFRESH_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_encryption_key_refresh_complete_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field handle from event HCI_EVENT_ENCRYPTION_KEY_REFRESH_COMPLETE
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t hci_event_encryption_key_refresh_complete_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    
    /**
     * @brief Get field bd_addr from event HCI_EVENT_USER_CONFIRMATION_REQUEST
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void hci_event_user_confirmation_request_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[2], bd_addr);    
    }
    /**
     * @brief Get field numeric_value from event HCI_EVENT_USER_CONFIRMATION_REQUEST
     * @param event packet
     * @return numeric_value
     * @note: btstack_type 4
     */
    static inline uint32_t hci_event_user_confirmation_request_get_numeric_value(const uint8_t * event){
        return little_endian_read_32(event, 8);
    }
    
    /**
     * @brief Get field bd_addr from event HCI_EVENT_USER_PASSKEY_REQUEST
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void hci_event_user_passkey_request_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[2], bd_addr);    
    }
    
    /**
     * @brief Get field bd_addr from event HCI_EVENT_REMOTE_OOB_DATA_REQUEST
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void hci_event_remote_oob_data_request_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[2], bd_addr);    
    }
    
    /**
     * @brief Get field status from event HCI_EVENT_SIMPLE_PAIRING_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_simple_pairing_complete_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field bd_addr from event HCI_EVENT_SIMPLE_PAIRING_COMPLETE
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void hci_event_simple_pairing_complete_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[3], bd_addr);    
    }
    
    /**
     * @brief Get field state from event BTSTACK_EVENT_STATE
     * @param event packet
     * @return state
     * @note: btstack_type 1
     */
    static inline uint8_t btstack_event_state_get_state(const uint8_t * event){
        return event[2];
    }
    
    /**
     * @brief Get field number_connections from event BTSTACK_EVENT_NR_CONNECTIONS_CHANGED
     * @param event packet
     * @return number_connections
     * @note: btstack_type 1
     */
    static inline uint8_t btstack_event_nr_connections_changed_get_number_connections(const uint8_t * event){
        return event[2];
    }
    
    
    /**
     * @brief Get field discoverable from event BTSTACK_EVENT_DISCOVERABLE_ENABLED
     * @param event packet
     * @return discoverable
     * @note: btstack_type 1
     */
    static inline uint8_t btstack_event_discoverable_enabled_get_discoverable(const uint8_t * event){
        return event[2];
    }
    
    /**
     * @brief Get field active from event HCI_EVENT_TRANSPORT_SLEEP_MODE
     * @param event packet
     * @return active
     * @note: btstack_type 1
     */
    static inline uint8_t hci_event_transport_sleep_mode_get_active(const uint8_t * event){
        return event[2];
    }
    
    /**
     * @brief Get field handle from event HCI_EVENT_SCO_CAN_SEND_NOW
     * @param event packet
     * @param Pointer to storage for handle
     * @note: btstack_type B
     */
    static inline void hci_event_sco_can_send_now_get_handle(const uint8_t * event, bd_addr_t handle){
        reverse_bd_addr(&event[2], handle);    
    }
    
    /**
     * @brief Get field status from event L2CAP_EVENT_CHANNEL_OPENED
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t l2cap_event_channel_opened_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field address from event L2CAP_EVENT_CHANNEL_OPENED
     * @param event packet
     * @param Pointer to storage for address
     * @note: btstack_type B
     */
    static inline void l2cap_event_channel_opened_get_address(const uint8_t * event, bd_addr_t address){
        reverse_bd_addr(&event[3], address);    
    }
    /**
     * @brief Get field handle from event L2CAP_EVENT_CHANNEL_OPENED
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t l2cap_event_channel_opened_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 9);
    }
    /**
     * @brief Get field psm from event L2CAP_EVENT_CHANNEL_OPENED
     * @param event packet
     * @return psm
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_channel_opened_get_psm(const uint8_t * event){
        return little_endian_read_16(event, 11);
    }
    /**
     * @brief Get field local_cid from event L2CAP_EVENT_CHANNEL_OPENED
     * @param event packet
     * @return local_cid
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_channel_opened_get_local_cid(const uint8_t * event){
        return little_endian_read_16(event, 13);
    }
    /**
     * @brief Get field remote_cid from event L2CAP_EVENT_CHANNEL_OPENED
     * @param event packet
     * @return remote_cid
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_channel_opened_get_remote_cid(const uint8_t * event){
        return little_endian_read_16(event, 15);
    }
    /**
     * @brief Get field local_mtu from event L2CAP_EVENT_CHANNEL_OPENED
     * @param event packet
     * @return local_mtu
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_channel_opened_get_local_mtu(const uint8_t * event){
        return little_endian_read_16(event, 17);
    }
    /**
     * @brief Get field remote_mtu from event L2CAP_EVENT_CHANNEL_OPENED
     * @param event packet
     * @return remote_mtu
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_channel_opened_get_remote_mtu(const uint8_t * event){
        return little_endian_read_16(event, 19);
    }
    /**
     * @brief Get field flush_timeout from event L2CAP_EVENT_CHANNEL_OPENED
     * @param event packet
     * @return flush_timeout
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_channel_opened_get_flush_timeout(const uint8_t * event){
        return little_endian_read_16(event, 21);
    }
    /**
     * @brief Get field incoming from event L2CAP_EVENT_CHANNEL_OPENED
     * @param event packet
     * @return incoming
     * @note: btstack_type 1
     */
    static inline uint8_t l2cap_event_channel_opened_get_incoming(const uint8_t * event){
        return event[23];
    }
    
    /**
     * @brief Get field local_cid from event L2CAP_EVENT_CHANNEL_CLOSED
     * @param event packet
     * @return local_cid
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_channel_closed_get_local_cid(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    
    /**
     * @brief Get field address from event L2CAP_EVENT_INCOMING_CONNECTION
     * @param event packet
     * @param Pointer to storage for address
     * @note: btstack_type B
     */
    static inline void l2cap_event_incoming_connection_get_address(const uint8_t * event, bd_addr_t address){
        reverse_bd_addr(&event[2], address);    
    }
    /**
     * @brief Get field handle from event L2CAP_EVENT_INCOMING_CONNECTION
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t l2cap_event_incoming_connection_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 8);
    }
    /**
     * @brief Get field psm from event L2CAP_EVENT_INCOMING_CONNECTION
     * @param event packet
     * @return psm
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_incoming_connection_get_psm(const uint8_t * event){
        return little_endian_read_16(event, 10);
    }
    /**
     * @brief Get field local_cid from event L2CAP_EVENT_INCOMING_CONNECTION
     * @param event packet
     * @return local_cid
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_incoming_connection_get_local_cid(const uint8_t * event){
        return little_endian_read_16(event, 12);
    }
    /**
     * @brief Get field remote_cid from event L2CAP_EVENT_INCOMING_CONNECTION
     * @param event packet
     * @return remote_cid
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_incoming_connection_get_remote_cid(const uint8_t * event){
        return little_endian_read_16(event, 14);
    }
    
    /**
     * @brief Get field handle from event L2CAP_EVENT_CONNECTION_PARAMETER_UPDATE_REQUEST
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t l2cap_event_connection_parameter_update_request_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field interval_min from event L2CAP_EVENT_CONNECTION_PARAMETER_UPDATE_REQUEST
     * @param event packet
     * @return interval_min
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_connection_parameter_update_request_get_interval_min(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    /**
     * @brief Get field interval_max from event L2CAP_EVENT_CONNECTION_PARAMETER_UPDATE_REQUEST
     * @param event packet
     * @return interval_max
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_connection_parameter_update_request_get_interval_max(const uint8_t * event){
        return little_endian_read_16(event, 6);
    }
    /**
     * @brief Get field latencey from event L2CAP_EVENT_CONNECTION_PARAMETER_UPDATE_REQUEST
     * @param event packet
     * @return latencey
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_connection_parameter_update_request_get_latencey(const uint8_t * event){
        return little_endian_read_16(event, 8);
    }
    /**
     * @brief Get field timeout_multiplier from event L2CAP_EVENT_CONNECTION_PARAMETER_UPDATE_REQUEST
     * @param event packet
     * @return timeout_multiplier
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_connection_parameter_update_request_get_timeout_multiplier(const uint8_t * event){
        return little_endian_read_16(event, 10);
    }
    
    /**
     * @brief Get field handle from event L2CAP_EVENT_CONNECTION_PARAMETER_UPDATE_RESPONSE
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t l2cap_event_connection_parameter_update_response_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field result from event L2CAP_EVENT_CONNECTION_PARAMETER_UPDATE_RESPONSE
     * @param event packet
     * @return result
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_connection_parameter_update_response_get_result(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    
    /**
     * @brief Get field local_cid from event L2CAP_EVENT_CAN_SEND_NOW
     * @param event packet
     * @return local_cid
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_can_send_now_get_local_cid(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    
    /**
     * @brief Get field address_type from event L2CAP_EVENT_LE_INCOMING_CONNECTION
     * @param event packet
     * @return address_type
     * @note: btstack_type 1
     */
    static inline uint8_t l2cap_event_le_incoming_connection_get_address_type(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field address from event L2CAP_EVENT_LE_INCOMING_CONNECTION
     * @param event packet
     * @param Pointer to storage for address
     * @note: btstack_type B
     */
    static inline void l2cap_event_le_incoming_connection_get_address(const uint8_t * event, bd_addr_t address){
        reverse_bd_addr(&event[3], address);    
    }
    /**
     * @brief Get field handle from event L2CAP_EVENT_LE_INCOMING_CONNECTION
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t l2cap_event_le_incoming_connection_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 9);
    }
    /**
     * @brief Get field psm from event L2CAP_EVENT_LE_INCOMING_CONNECTION
     * @param event packet
     * @return psm
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_le_incoming_connection_get_psm(const uint8_t * event){
        return little_endian_read_16(event, 11);
    }
    /**
     * @brief Get field local_cid from event L2CAP_EVENT_LE_INCOMING_CONNECTION
     * @param event packet
     * @return local_cid
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_le_incoming_connection_get_local_cid(const uint8_t * event){
        return little_endian_read_16(event, 13);
    }
    /**
     * @brief Get field remote_cid from event L2CAP_EVENT_LE_INCOMING_CONNECTION
     * @param event packet
     * @return remote_cid
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_le_incoming_connection_get_remote_cid(const uint8_t * event){
        return little_endian_read_16(event, 15);
    }
    /**
     * @brief Get field remote_mtu from event L2CAP_EVENT_LE_INCOMING_CONNECTION
     * @param event packet
     * @return remote_mtu
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_le_incoming_connection_get_remote_mtu(const uint8_t * event){
        return little_endian_read_16(event, 17);
    }
    
    /**
     * @brief Get field status from event L2CAP_EVENT_LE_CHANNEL_OPENED
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t l2cap_event_le_channel_opened_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field address_type from event L2CAP_EVENT_LE_CHANNEL_OPENED
     * @param event packet
     * @return address_type
     * @note: btstack_type 1
     */
    static inline uint8_t l2cap_event_le_channel_opened_get_address_type(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field address from event L2CAP_EVENT_LE_CHANNEL_OPENED
     * @param event packet
     * @param Pointer to storage for address
     * @note: btstack_type B
     */
    static inline void l2cap_event_le_channel_opened_get_address(const uint8_t * event, bd_addr_t address){
        reverse_bd_addr(&event[4], address);    
    }
    /**
     * @brief Get field handle from event L2CAP_EVENT_LE_CHANNEL_OPENED
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t l2cap_event_le_channel_opened_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 10);
    }
    /**
     * @brief Get field incoming from event L2CAP_EVENT_LE_CHANNEL_OPENED
     * @param event packet
     * @return incoming
     * @note: btstack_type 1
     */
    static inline uint8_t l2cap_event_le_channel_opened_get_incoming(const uint8_t * event){
        return event[12];
    }
    /**
     * @brief Get field psm from event L2CAP_EVENT_LE_CHANNEL_OPENED
     * @param event packet
     * @return psm
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_le_channel_opened_get_psm(const uint8_t * event){
        return little_endian_read_16(event, 13);
    }
    /**
     * @brief Get field local_cid from event L2CAP_EVENT_LE_CHANNEL_OPENED
     * @param event packet
     * @return local_cid
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_le_channel_opened_get_local_cid(const uint8_t * event){
        return little_endian_read_16(event, 15);
    }
    /**
     * @brief Get field remote_cid from event L2CAP_EVENT_LE_CHANNEL_OPENED
     * @param event packet
     * @return remote_cid
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_le_channel_opened_get_remote_cid(const uint8_t * event){
        return little_endian_read_16(event, 17);
    }
    /**
     * @brief Get field local_mtu from event L2CAP_EVENT_LE_CHANNEL_OPENED
     * @param event packet
     * @return local_mtu
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_le_channel_opened_get_local_mtu(const uint8_t * event){
        return little_endian_read_16(event, 19);
    }
    /**
     * @brief Get field remote_mtu from event L2CAP_EVENT_LE_CHANNEL_OPENED
     * @param event packet
     * @return remote_mtu
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_le_channel_opened_get_remote_mtu(const uint8_t * event){
        return little_endian_read_16(event, 21);
    }
    
    /**
     * @brief Get field local_cid from event L2CAP_EVENT_LE_CHANNEL_CLOSED
     * @param event packet
     * @return local_cid
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_le_channel_closed_get_local_cid(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    
    /**
     * @brief Get field local_cid from event L2CAP_EVENT_LE_CAN_SEND_NOW
     * @param event packet
     * @return local_cid
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_le_can_send_now_get_local_cid(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    
    /**
     * @brief Get field local_cid from event L2CAP_EVENT_LE_PACKET_SENT
     * @param event packet
     * @return local_cid
     * @note: btstack_type 2
     */
    static inline uint16_t l2cap_event_le_packet_sent_get_local_cid(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    
    /**
     * @brief Get field status from event RFCOMM_EVENT_CHANNEL_OPENED
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t rfcomm_event_channel_opened_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field bd_addr from event RFCOMM_EVENT_CHANNEL_OPENED
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void rfcomm_event_channel_opened_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[3], bd_addr);    
    }
    /**
     * @brief Get field con_handle from event RFCOMM_EVENT_CHANNEL_OPENED
     * @param event packet
     * @return con_handle
     * @note: btstack_type 2
     */
    static inline uint16_t rfcomm_event_channel_opened_get_con_handle(const uint8_t * event){
        return little_endian_read_16(event, 9);
    }
    /**
     * @brief Get field server_channel from event RFCOMM_EVENT_CHANNEL_OPENED
     * @param event packet
     * @return server_channel
     * @note: btstack_type 1
     */
    static inline uint8_t rfcomm_event_channel_opened_get_server_channel(const uint8_t * event){
        return event[11];
    }
    /**
     * @brief Get field rfcomm_cid from event RFCOMM_EVENT_CHANNEL_OPENED
     * @param event packet
     * @return rfcomm_cid
     * @note: btstack_type 2
     */
    static inline uint16_t rfcomm_event_channel_opened_get_rfcomm_cid(const uint8_t * event){
        return little_endian_read_16(event, 12);
    }
    /**
     * @brief Get field max_frame_size from event RFCOMM_EVENT_CHANNEL_OPENED
     * @param event packet
     * @return max_frame_size
     * @note: btstack_type 2
     */
    static inline uint16_t rfcomm_event_channel_opened_get_max_frame_size(const uint8_t * event){
        return little_endian_read_16(event, 14);
    }
    /**
     * @brief Get field incoming from event RFCOMM_EVENT_CHANNEL_OPENED
     * @param event packet
     * @return incoming
     * @note: btstack_type 1
     */
    static inline uint8_t rfcomm_event_channel_opened_get_incoming(const uint8_t * event){
        return event[16];
    }
    
    /**
     * @brief Get field rfcomm_cid from event RFCOMM_EVENT_CHANNEL_CLOSED
     * @param event packet
     * @return rfcomm_cid
     * @note: btstack_type 2
     */
    static inline uint16_t rfcomm_event_channel_closed_get_rfcomm_cid(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    
    /**
     * @brief Get field bd_addr from event RFCOMM_EVENT_INCOMING_CONNECTION
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void rfcomm_event_incoming_connection_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[2], bd_addr);    
    }
    /**
     * @brief Get field server_channel from event RFCOMM_EVENT_INCOMING_CONNECTION
     * @param event packet
     * @return server_channel
     * @note: btstack_type 1
     */
    static inline uint8_t rfcomm_event_incoming_connection_get_server_channel(const uint8_t * event){
        return event[8];
    }
    /**
     * @brief Get field rfcomm_cid from event RFCOMM_EVENT_INCOMING_CONNECTION
     * @param event packet
     * @return rfcomm_cid
     * @note: btstack_type 2
     */
    static inline uint16_t rfcomm_event_incoming_connection_get_rfcomm_cid(const uint8_t * event){
        return little_endian_read_16(event, 9);
    }
    
    /**
     * @brief Get field rfcomm_cid from event RFCOMM_EVENT_REMOTE_LINE_STATUS
     * @param event packet
     * @return rfcomm_cid
     * @note: btstack_type 2
     */
    static inline uint16_t rfcomm_event_remote_line_status_get_rfcomm_cid(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field line_status from event RFCOMM_EVENT_REMOTE_LINE_STATUS
     * @param event packet
     * @return line_status
     * @note: btstack_type 1
     */
    static inline uint8_t rfcomm_event_remote_line_status_get_line_status(const uint8_t * event){
        return event[4];
    }
    
    /**
     * @brief Get field rfcomm_cid from event RFCOMM_EVENT_REMOTE_MODEM_STATUS
     * @param event packet
     * @return rfcomm_cid
     * @note: btstack_type 2
     */
    static inline uint16_t rfcomm_event_remote_modem_status_get_rfcomm_cid(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field modem_status from event RFCOMM_EVENT_REMOTE_MODEM_STATUS
     * @param event packet
     * @return modem_status
     * @note: btstack_type 1
     */
    static inline uint8_t rfcomm_event_remote_modem_status_get_modem_status(const uint8_t * event){
        return event[4];
    }
    
    /**
     * @brief Get field rfcomm_cid from event RFCOMM_EVENT_CAN_SEND_NOW
     * @param event packet
     * @return rfcomm_cid
     * @note: btstack_type 2
     */
    static inline uint16_t rfcomm_event_can_send_now_get_rfcomm_cid(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    
    /**
     * @brief Get field status from event SDP_EVENT_QUERY_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t sdp_event_query_complete_get_status(const uint8_t * event){
        return event[2];
    }
    
    /**
     * @brief Get field rfcomm_channel from event SDP_EVENT_QUERY_RFCOMM_SERVICE
     * @param event packet
     * @return rfcomm_channel
     * @note: btstack_type 1
     */
    static inline uint8_t sdp_event_query_rfcomm_service_get_rfcomm_channel(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field name from event SDP_EVENT_QUERY_RFCOMM_SERVICE
     * @param event packet
     * @return name
     * @note: btstack_type T
     */
    static inline const char * sdp_event_query_rfcomm_service_get_name(const uint8_t * event){
        return (const char *) &event[3];
    }
    
    /**
     * @brief Get field record_id from event SDP_EVENT_QUERY_ATTRIBUTE_BYTE
     * @param event packet
     * @return record_id
     * @note: btstack_type 2
     */
    static inline uint16_t sdp_event_query_attribute_byte_get_record_id(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field attribute_id from event SDP_EVENT_QUERY_ATTRIBUTE_BYTE
     * @param event packet
     * @return attribute_id
     * @note: btstack_type 2
     */
    static inline uint16_t sdp_event_query_attribute_byte_get_attribute_id(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    /**
     * @brief Get field attribute_length from event SDP_EVENT_QUERY_ATTRIBUTE_BYTE
     * @param event packet
     * @return attribute_length
     * @note: btstack_type 2
     */
    static inline uint16_t sdp_event_query_attribute_byte_get_attribute_length(const uint8_t * event){
        return little_endian_read_16(event, 6);
    }
    /**
     * @brief Get field data_offset from event SDP_EVENT_QUERY_ATTRIBUTE_BYTE
     * @param event packet
     * @return data_offset
     * @note: btstack_type 2
     */
    static inline uint16_t sdp_event_query_attribute_byte_get_data_offset(const uint8_t * event){
        return little_endian_read_16(event, 8);
    }
    /**
     * @brief Get field data from event SDP_EVENT_QUERY_ATTRIBUTE_BYTE
     * @param event packet
     * @return data
     * @note: btstack_type 1
     */
    static inline uint8_t sdp_event_query_attribute_byte_get_data(const uint8_t * event){
        return event[10];
    }
    
    /**
     * @brief Get field record_id from event SDP_EVENT_QUERY_ATTRIBUTE_VALUE
     * @param event packet
     * @return record_id
     * @note: btstack_type 2
     */
    static inline uint16_t sdp_event_query_attribute_value_get_record_id(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field attribute_id from event SDP_EVENT_QUERY_ATTRIBUTE_VALUE
     * @param event packet
     * @return attribute_id
     * @note: btstack_type 2
     */
    static inline uint16_t sdp_event_query_attribute_value_get_attribute_id(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    /**
     * @brief Get field attribute_length from event SDP_EVENT_QUERY_ATTRIBUTE_VALUE
     * @param event packet
     * @return attribute_length
     * @note: btstack_type L
     */
    static inline int sdp_event_query_attribute_value_get_attribute_length(const uint8_t * event){
        return little_endian_read_16(event, 6);
    }
    /**
     * @brief Get field attribute_value from event SDP_EVENT_QUERY_ATTRIBUTE_VALUE
     * @param event packet
     * @return attribute_value
     * @note: btstack_type V
     */
    static inline const uint8_t * sdp_event_query_attribute_value_get_attribute_value(const uint8_t * event){
        return &event[8];
    }
    
    /**
     * @brief Get field total_count from event SDP_EVENT_QUERY_SERVICE_RECORD_HANDLE
     * @param event packet
     * @return total_count
     * @note: btstack_type 2
     */
    static inline uint16_t sdp_event_query_service_record_handle_get_total_count(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field record_index from event SDP_EVENT_QUERY_SERVICE_RECORD_HANDLE
     * @param event packet
     * @return record_index
     * @note: btstack_type 2
     */
    static inline uint16_t sdp_event_query_service_record_handle_get_record_index(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    /**
     * @brief Get field record_handle from event SDP_EVENT_QUERY_SERVICE_RECORD_HANDLE
     * @param event packet
     * @return record_handle
     * @note: btstack_type 4
     */
    static inline uint32_t sdp_event_query_service_record_handle_get_record_handle(const uint8_t * event){
        return little_endian_read_32(event, 6);
    }
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event GATT_EVENT_QUERY_COMPLETE
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t gatt_event_query_complete_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field status from event GATT_EVENT_QUERY_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t gatt_event_query_complete_get_status(const uint8_t * event){
        return event[4];
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event GATT_EVENT_SERVICE_QUERY_RESULT
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t gatt_event_service_query_result_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field service from event GATT_EVENT_SERVICE_QUERY_RESULT
     * @param event packet
     * @param Pointer to storage for service
     * @note: btstack_type X
     */
    static inline void gatt_event_service_query_result_get_service(const uint8_t * event, gatt_client_service_t * service){
        gatt_client_deserialize_service(event, 4, service);    
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event GATT_EVENT_CHARACTERISTIC_QUERY_RESULT
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t gatt_event_characteristic_query_result_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field characteristic from event GATT_EVENT_CHARACTERISTIC_QUERY_RESULT
     * @param event packet
     * @param Pointer to storage for characteristic
     * @note: btstack_type Y
     */
    static inline void gatt_event_characteristic_query_result_get_characteristic(const uint8_t * event, gatt_client_characteristic_t * characteristic){
        gatt_client_deserialize_characteristic(event, 4, characteristic);    
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event GATT_EVENT_INCLUDED_SERVICE_QUERY_RESULT
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t gatt_event_included_service_query_result_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field include_handle from event GATT_EVENT_INCLUDED_SERVICE_QUERY_RESULT
     * @param event packet
     * @return include_handle
     * @note: btstack_type 2
     */
    static inline uint16_t gatt_event_included_service_query_result_get_include_handle(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    /**
     * @brief Get field service from event GATT_EVENT_INCLUDED_SERVICE_QUERY_RESULT
     * @param event packet
     * @param Pointer to storage for service
     * @note: btstack_type X
     */
    static inline void gatt_event_included_service_query_result_get_service(const uint8_t * event, gatt_client_service_t * service){
        gatt_client_deserialize_service(event, 6, service);    
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event GATT_EVENT_ALL_CHARACTERISTIC_DESCRIPTORS_QUERY_RESULT
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t gatt_event_all_characteristic_descriptors_query_result_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field characteristic_descriptor from event GATT_EVENT_ALL_CHARACTERISTIC_DESCRIPTORS_QUERY_RESULT
     * @param event packet
     * @param Pointer to storage for characteristic_descriptor
     * @note: btstack_type Z
     */
    static inline void gatt_event_all_characteristic_descriptors_query_result_get_characteristic_descriptor(const uint8_t * event, gatt_client_characteristic_descriptor_t * characteristic_descriptor){
        gatt_client_deserialize_characteristic_descriptor(event, 4, characteristic_descriptor);    
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event GATT_EVENT_CHARACTERISTIC_VALUE_QUERY_RESULT
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t gatt_event_characteristic_value_query_result_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field value_handle from event GATT_EVENT_CHARACTERISTIC_VALUE_QUERY_RESULT
     * @param event packet
     * @return value_handle
     * @note: btstack_type 2
     */
    static inline uint16_t gatt_event_characteristic_value_query_result_get_value_handle(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    /**
     * @brief Get field value_length from event GATT_EVENT_CHARACTERISTIC_VALUE_QUERY_RESULT
     * @param event packet
     * @return value_length
     * @note: btstack_type L
     */
    static inline int gatt_event_characteristic_value_query_result_get_value_length(const uint8_t * event){
        return little_endian_read_16(event, 6);
    }
    /**
     * @brief Get field value from event GATT_EVENT_CHARACTERISTIC_VALUE_QUERY_RESULT
     * @param event packet
     * @return value
     * @note: btstack_type V
     */
    static inline const uint8_t * gatt_event_characteristic_value_query_result_get_value(const uint8_t * event){
        return &event[8];
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event GATT_EVENT_LONG_CHARACTERISTIC_VALUE_QUERY_RESULT
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t gatt_event_long_characteristic_value_query_result_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field value_handle from event GATT_EVENT_LONG_CHARACTERISTIC_VALUE_QUERY_RESULT
     * @param event packet
     * @return value_handle
     * @note: btstack_type 2
     */
    static inline uint16_t gatt_event_long_characteristic_value_query_result_get_value_handle(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    /**
     * @brief Get field value_offset from event GATT_EVENT_LONG_CHARACTERISTIC_VALUE_QUERY_RESULT
     * @param event packet
     * @return value_offset
     * @note: btstack_type 2
     */
    static inline uint16_t gatt_event_long_characteristic_value_query_result_get_value_offset(const uint8_t * event){
        return little_endian_read_16(event, 6);
    }
    /**
     * @brief Get field value_length from event GATT_EVENT_LONG_CHARACTERISTIC_VALUE_QUERY_RESULT
     * @param event packet
     * @return value_length
     * @note: btstack_type L
     */
    static inline int gatt_event_long_characteristic_value_query_result_get_value_length(const uint8_t * event){
        return little_endian_read_16(event, 8);
    }
    /**
     * @brief Get field value from event GATT_EVENT_LONG_CHARACTERISTIC_VALUE_QUERY_RESULT
     * @param event packet
     * @return value
     * @note: btstack_type V
     */
    static inline const uint8_t * gatt_event_long_characteristic_value_query_result_get_value(const uint8_t * event){
        return &event[10];
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event GATT_EVENT_NOTIFICATION
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t gatt_event_notification_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field value_handle from event GATT_EVENT_NOTIFICATION
     * @param event packet
     * @return value_handle
     * @note: btstack_type 2
     */
    static inline uint16_t gatt_event_notification_get_value_handle(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    /**
     * @brief Get field value_length from event GATT_EVENT_NOTIFICATION
     * @param event packet
     * @return value_length
     * @note: btstack_type L
     */
    static inline int gatt_event_notification_get_value_length(const uint8_t * event){
        return little_endian_read_16(event, 6);
    }
    /**
     * @brief Get field value from event GATT_EVENT_NOTIFICATION
     * @param event packet
     * @return value
     * @note: btstack_type V
     */
    static inline const uint8_t * gatt_event_notification_get_value(const uint8_t * event){
        return &event[8];
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event GATT_EVENT_INDICATION
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t gatt_event_indication_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field value_handle from event GATT_EVENT_INDICATION
     * @param event packet
     * @return value_handle
     * @note: btstack_type 2
     */
    static inline uint16_t gatt_event_indication_get_value_handle(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    /**
     * @brief Get field value_length from event GATT_EVENT_INDICATION
     * @param event packet
     * @return value_length
     * @note: btstack_type L
     */
    static inline int gatt_event_indication_get_value_length(const uint8_t * event){
        return little_endian_read_16(event, 6);
    }
    /**
     * @brief Get field value from event GATT_EVENT_INDICATION
     * @param event packet
     * @return value
     * @note: btstack_type V
     */
    static inline const uint8_t * gatt_event_indication_get_value(const uint8_t * event){
        return &event[8];
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event GATT_EVENT_CHARACTERISTIC_DESCRIPTOR_QUERY_RESULT
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t gatt_event_characteristic_descriptor_query_result_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field descriptor_handle from event GATT_EVENT_CHARACTERISTIC_DESCRIPTOR_QUERY_RESULT
     * @param event packet
     * @return descriptor_handle
     * @note: btstack_type 2
     */
    static inline uint16_t gatt_event_characteristic_descriptor_query_result_get_descriptor_handle(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    /**
     * @brief Get field descriptor_length from event GATT_EVENT_CHARACTERISTIC_DESCRIPTOR_QUERY_RESULT
     * @param event packet
     * @return descriptor_length
     * @note: btstack_type L
     */
    static inline int gatt_event_characteristic_descriptor_query_result_get_descriptor_length(const uint8_t * event){
        return little_endian_read_16(event, 6);
    }
    /**
     * @brief Get field descriptor from event GATT_EVENT_CHARACTERISTIC_DESCRIPTOR_QUERY_RESULT
     * @param event packet
     * @return descriptor
     * @note: btstack_type V
     */
    static inline const uint8_t * gatt_event_characteristic_descriptor_query_result_get_descriptor(const uint8_t * event){
        return &event[8];
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event GATT_EVENT_LONG_CHARACTERISTIC_DESCRIPTOR_QUERY_RESULT
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t gatt_event_long_characteristic_descriptor_query_result_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field descriptor_offset from event GATT_EVENT_LONG_CHARACTERISTIC_DESCRIPTOR_QUERY_RESULT
     * @param event packet
     * @return descriptor_offset
     * @note: btstack_type 2
     */
    static inline uint16_t gatt_event_long_characteristic_descriptor_query_result_get_descriptor_offset(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    /**
     * @brief Get field descriptor_length from event GATT_EVENT_LONG_CHARACTERISTIC_DESCRIPTOR_QUERY_RESULT
     * @param event packet
     * @return descriptor_length
     * @note: btstack_type L
     */
    static inline int gatt_event_long_characteristic_descriptor_query_result_get_descriptor_length(const uint8_t * event){
        return little_endian_read_16(event, 6);
    }
    /**
     * @brief Get field descriptor from event GATT_EVENT_LONG_CHARACTERISTIC_DESCRIPTOR_QUERY_RESULT
     * @param event packet
     * @return descriptor
     * @note: btstack_type V
     */
    static inline const uint8_t * gatt_event_long_characteristic_descriptor_query_result_get_descriptor(const uint8_t * event){
        return &event[8];
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event GATT_EVENT_MTU
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t gatt_event_mtu_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field MTU from event GATT_EVENT_MTU
     * @param event packet
     * @return MTU
     * @note: btstack_type 2
     */
    static inline uint16_t gatt_event_mtu_get_MTU(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    #endif
    
    /**
     * @brief Get field handle from event ATT_EVENT_MTU_EXCHANGE_COMPLETE
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t att_event_mtu_exchange_complete_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field MTU from event ATT_EVENT_MTU_EXCHANGE_COMPLETE
     * @param event packet
     * @return MTU
     * @note: btstack_type 2
     */
    static inline uint16_t att_event_mtu_exchange_complete_get_MTU(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    
    /**
     * @brief Get field status from event ATT_EVENT_HANDLE_VALUE_INDICATION_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t att_event_handle_value_indication_complete_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field conn_handle from event ATT_EVENT_HANDLE_VALUE_INDICATION_COMPLETE
     * @param event packet
     * @return conn_handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t att_event_handle_value_indication_complete_get_conn_handle(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field attribute_handle from event ATT_EVENT_HANDLE_VALUE_INDICATION_COMPLETE
     * @param event packet
     * @return attribute_handle
     * @note: btstack_type 2
     */
    static inline uint16_t att_event_handle_value_indication_complete_get_attribute_handle(const uint8_t * event){
        return little_endian_read_16(event, 5);
    }
    
    
    /**
     * @brief Get field status from event BNEP_EVENT_SERVICE_REGISTERED
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t bnep_event_service_registered_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field service_uuid from event BNEP_EVENT_SERVICE_REGISTERED
     * @param event packet
     * @return service_uuid
     * @note: btstack_type 2
     */
    static inline uint16_t bnep_event_service_registered_get_service_uuid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    
    /**
     * @brief Get field status from event BNEP_EVENT_CHANNEL_OPENED
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t bnep_event_channel_opened_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field bnep_cid from event BNEP_EVENT_CHANNEL_OPENED
     * @param event packet
     * @return bnep_cid
     * @note: btstack_type 2
     */
    static inline uint16_t bnep_event_channel_opened_get_bnep_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field source_uuid from event BNEP_EVENT_CHANNEL_OPENED
     * @param event packet
     * @return source_uuid
     * @note: btstack_type 2
     */
    static inline uint16_t bnep_event_channel_opened_get_source_uuid(const uint8_t * event){
        return little_endian_read_16(event, 5);
    }
    /**
     * @brief Get field destination_uuid from event BNEP_EVENT_CHANNEL_OPENED
     * @param event packet
     * @return destination_uuid
     * @note: btstack_type 2
     */
    static inline uint16_t bnep_event_channel_opened_get_destination_uuid(const uint8_t * event){
        return little_endian_read_16(event, 7);
    }
    /**
     * @brief Get field mtu from event BNEP_EVENT_CHANNEL_OPENED
     * @param event packet
     * @return mtu
     * @note: btstack_type 2
     */
    static inline uint16_t bnep_event_channel_opened_get_mtu(const uint8_t * event){
        return little_endian_read_16(event, 9);
    }
    /**
     * @brief Get field remote_address from event BNEP_EVENT_CHANNEL_OPENED
     * @param event packet
     * @param Pointer to storage for remote_address
     * @note: btstack_type B
     */
    static inline void bnep_event_channel_opened_get_remote_address(const uint8_t * event, bd_addr_t remote_address){
        reverse_bd_addr(&event[11], remote_address);    
    }
    
    /**
     * @brief Get field bnep_cid from event BNEP_EVENT_CHANNEL_CLOSED
     * @param event packet
     * @return bnep_cid
     * @note: btstack_type 2
     */
    static inline uint16_t bnep_event_channel_closed_get_bnep_cid(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field source_uuid from event BNEP_EVENT_CHANNEL_CLOSED
     * @param event packet
     * @return source_uuid
     * @note: btstack_type 2
     */
    static inline uint16_t bnep_event_channel_closed_get_source_uuid(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    /**
     * @brief Get field destination_uuid from event BNEP_EVENT_CHANNEL_CLOSED
     * @param event packet
     * @return destination_uuid
     * @note: btstack_type 2
     */
    static inline uint16_t bnep_event_channel_closed_get_destination_uuid(const uint8_t * event){
        return little_endian_read_16(event, 6);
    }
    /**
     * @brief Get field remote_address from event BNEP_EVENT_CHANNEL_CLOSED
     * @param event packet
     * @param Pointer to storage for remote_address
     * @note: btstack_type B
     */
    static inline void bnep_event_channel_closed_get_remote_address(const uint8_t * event, bd_addr_t remote_address){
        reverse_bd_addr(&event[8], remote_address);    
    }
    
    /**
     * @brief Get field bnep_cid from event BNEP_EVENT_CHANNEL_TIMEOUT
     * @param event packet
     * @return bnep_cid
     * @note: btstack_type 2
     */
    static inline uint16_t bnep_event_channel_timeout_get_bnep_cid(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field source_uuid from event BNEP_EVENT_CHANNEL_TIMEOUT
     * @param event packet
     * @return source_uuid
     * @note: btstack_type 2
     */
    static inline uint16_t bnep_event_channel_timeout_get_source_uuid(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    /**
     * @brief Get field destination_uuid from event BNEP_EVENT_CHANNEL_TIMEOUT
     * @param event packet
     * @return destination_uuid
     * @note: btstack_type 2
     */
    static inline uint16_t bnep_event_channel_timeout_get_destination_uuid(const uint8_t * event){
        return little_endian_read_16(event, 6);
    }
    /**
     * @brief Get field remote_address from event BNEP_EVENT_CHANNEL_TIMEOUT
     * @param event packet
     * @param Pointer to storage for remote_address
     * @note: btstack_type B
     */
    static inline void bnep_event_channel_timeout_get_remote_address(const uint8_t * event, bd_addr_t remote_address){
        reverse_bd_addr(&event[8], remote_address);    
    }
    /**
     * @brief Get field channel_state from event BNEP_EVENT_CHANNEL_TIMEOUT
     * @param event packet
     * @return channel_state
     * @note: btstack_type 1
     */
    static inline uint8_t bnep_event_channel_timeout_get_channel_state(const uint8_t * event){
        return event[14];
    }
    
    /**
     * @brief Get field bnep_cid from event BNEP_EVENT_CAN_SEND_NOW
     * @param event packet
     * @return bnep_cid
     * @note: btstack_type 2
     */
    static inline uint16_t bnep_event_can_send_now_get_bnep_cid(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field source_uuid from event BNEP_EVENT_CAN_SEND_NOW
     * @param event packet
     * @return source_uuid
     * @note: btstack_type 2
     */
    static inline uint16_t bnep_event_can_send_now_get_source_uuid(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    /**
     * @brief Get field destination_uuid from event BNEP_EVENT_CAN_SEND_NOW
     * @param event packet
     * @return destination_uuid
     * @note: btstack_type 2
     */
    static inline uint16_t bnep_event_can_send_now_get_destination_uuid(const uint8_t * event){
        return little_endian_read_16(event, 6);
    }
    /**
     * @brief Get field remote_address from event BNEP_EVENT_CAN_SEND_NOW
     * @param event packet
     * @param Pointer to storage for remote_address
     * @note: btstack_type B
     */
    static inline void bnep_event_can_send_now_get_remote_address(const uint8_t * event, bd_addr_t remote_address){
        reverse_bd_addr(&event[8], remote_address);    
    }
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event SM_EVENT_JUST_WORKS_REQUEST
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t sm_event_just_works_request_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field addr_type from event SM_EVENT_JUST_WORKS_REQUEST
     * @param event packet
     * @return addr_type
     * @note: btstack_type 1
     */
    static inline uint8_t sm_event_just_works_request_get_addr_type(const uint8_t * event){
        return event[4];
    }
    /**
     * @brief Get field address from event SM_EVENT_JUST_WORKS_REQUEST
     * @param event packet
     * @param Pointer to storage for address
     * @note: btstack_type B
     */
    static inline void sm_event_just_works_request_get_address(const uint8_t * event, bd_addr_t address){
        reverse_bd_addr(&event[5], address);    
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event SM_EVENT_JUST_WORKS_CANCEL
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t sm_event_just_works_cancel_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field addr_type from event SM_EVENT_JUST_WORKS_CANCEL
     * @param event packet
     * @return addr_type
     * @note: btstack_type 1
     */
    static inline uint8_t sm_event_just_works_cancel_get_addr_type(const uint8_t * event){
        return event[4];
    }
    /**
     * @brief Get field address from event SM_EVENT_JUST_WORKS_CANCEL
     * @param event packet
     * @param Pointer to storage for address
     * @note: btstack_type B
     */
    static inline void sm_event_just_works_cancel_get_address(const uint8_t * event, bd_addr_t address){
        reverse_bd_addr(&event[5], address);    
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event SM_EVENT_PASSKEY_DISPLAY_NUMBER
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t sm_event_passkey_display_number_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field addr_type from event SM_EVENT_PASSKEY_DISPLAY_NUMBER
     * @param event packet
     * @return addr_type
     * @note: btstack_type 1
     */
    static inline uint8_t sm_event_passkey_display_number_get_addr_type(const uint8_t * event){
        return event[4];
    }
    /**
     * @brief Get field address from event SM_EVENT_PASSKEY_DISPLAY_NUMBER
     * @param event packet
     * @param Pointer to storage for address
     * @note: btstack_type B
     */
    static inline void sm_event_passkey_display_number_get_address(const uint8_t * event, bd_addr_t address){
        reverse_bd_addr(&event[5], address);    
    }
    /**
     * @brief Get field passkey from event SM_EVENT_PASSKEY_DISPLAY_NUMBER
     * @param event packet
     * @return passkey
     * @note: btstack_type 4
     */
    static inline uint32_t sm_event_passkey_display_number_get_passkey(const uint8_t * event){
        return little_endian_read_32(event, 11);
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event SM_EVENT_PASSKEY_DISPLAY_CANCEL
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t sm_event_passkey_display_cancel_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field addr_type from event SM_EVENT_PASSKEY_DISPLAY_CANCEL
     * @param event packet
     * @return addr_type
     * @note: btstack_type 1
     */
    static inline uint8_t sm_event_passkey_display_cancel_get_addr_type(const uint8_t * event){
        return event[4];
    }
    /**
     * @brief Get field address from event SM_EVENT_PASSKEY_DISPLAY_CANCEL
     * @param event packet
     * @param Pointer to storage for address
     * @note: btstack_type B
     */
    static inline void sm_event_passkey_display_cancel_get_address(const uint8_t * event, bd_addr_t address){
        reverse_bd_addr(&event[5], address);    
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event SM_EVENT_PASSKEY_INPUT_NUMBER
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t sm_event_passkey_input_number_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field addr_type from event SM_EVENT_PASSKEY_INPUT_NUMBER
     * @param event packet
     * @return addr_type
     * @note: btstack_type 1
     */
    static inline uint8_t sm_event_passkey_input_number_get_addr_type(const uint8_t * event){
        return event[4];
    }
    /**
     * @brief Get field address from event SM_EVENT_PASSKEY_INPUT_NUMBER
     * @param event packet
     * @param Pointer to storage for address
     * @note: btstack_type B
     */
    static inline void sm_event_passkey_input_number_get_address(const uint8_t * event, bd_addr_t address){
        reverse_bd_addr(&event[5], address);    
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event SM_EVENT_PASSKEY_INPUT_CANCEL
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t sm_event_passkey_input_cancel_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field addr_type from event SM_EVENT_PASSKEY_INPUT_CANCEL
     * @param event packet
     * @return addr_type
     * @note: btstack_type 1
     */
    static inline uint8_t sm_event_passkey_input_cancel_get_addr_type(const uint8_t * event){
        return event[4];
    }
    /**
     * @brief Get field address from event SM_EVENT_PASSKEY_INPUT_CANCEL
     * @param event packet
     * @param Pointer to storage for address
     * @note: btstack_type B
     */
    static inline void sm_event_passkey_input_cancel_get_address(const uint8_t * event, bd_addr_t address){
        reverse_bd_addr(&event[5], address);    
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event SM_EVENT_NUMERIC_COMPARISON_REQUEST
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t sm_event_numeric_comparison_request_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field addr_type from event SM_EVENT_NUMERIC_COMPARISON_REQUEST
     * @param event packet
     * @return addr_type
     * @note: btstack_type 1
     */
    static inline uint8_t sm_event_numeric_comparison_request_get_addr_type(const uint8_t * event){
        return event[4];
    }
    /**
     * @brief Get field address from event SM_EVENT_NUMERIC_COMPARISON_REQUEST
     * @param event packet
     * @param Pointer to storage for address
     * @note: btstack_type B
     */
    static inline void sm_event_numeric_comparison_request_get_address(const uint8_t * event, bd_addr_t address){
        reverse_bd_addr(&event[5], address);    
    }
    /**
     * @brief Get field passkey from event SM_EVENT_NUMERIC_COMPARISON_REQUEST
     * @param event packet
     * @return passkey
     * @note: btstack_type 4
     */
    static inline uint32_t sm_event_numeric_comparison_request_get_passkey(const uint8_t * event){
        return little_endian_read_32(event, 11);
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event SM_EVENT_NUMERIC_COMPARISON_CANCEL
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t sm_event_numeric_comparison_cancel_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field addr_type from event SM_EVENT_NUMERIC_COMPARISON_CANCEL
     * @param event packet
     * @return addr_type
     * @note: btstack_type 1
     */
    static inline uint8_t sm_event_numeric_comparison_cancel_get_addr_type(const uint8_t * event){
        return event[4];
    }
    /**
     * @brief Get field address from event SM_EVENT_NUMERIC_COMPARISON_CANCEL
     * @param event packet
     * @param Pointer to storage for address
     * @note: btstack_type B
     */
    static inline void sm_event_numeric_comparison_cancel_get_address(const uint8_t * event, bd_addr_t address){
        reverse_bd_addr(&event[5], address);    
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event SM_EVENT_IDENTITY_RESOLVING_STARTED
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t sm_event_identity_resolving_started_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field addr_type from event SM_EVENT_IDENTITY_RESOLVING_STARTED
     * @param event packet
     * @return addr_type
     * @note: btstack_type 1
     */
    static inline uint8_t sm_event_identity_resolving_started_get_addr_type(const uint8_t * event){
        return event[4];
    }
    /**
     * @brief Get field address from event SM_EVENT_IDENTITY_RESOLVING_STARTED
     * @param event packet
     * @param Pointer to storage for address
     * @note: btstack_type B
     */
    static inline void sm_event_identity_resolving_started_get_address(const uint8_t * event, bd_addr_t address){
        reverse_bd_addr(&event[5], address);    
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event SM_EVENT_IDENTITY_RESOLVING_FAILED
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t sm_event_identity_resolving_failed_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field addr_type from event SM_EVENT_IDENTITY_RESOLVING_FAILED
     * @param event packet
     * @return addr_type
     * @note: btstack_type 1
     */
    static inline uint8_t sm_event_identity_resolving_failed_get_addr_type(const uint8_t * event){
        return event[4];
    }
    /**
     * @brief Get field address from event SM_EVENT_IDENTITY_RESOLVING_FAILED
     * @param event packet
     * @param Pointer to storage for address
     * @note: btstack_type B
     */
    static inline void sm_event_identity_resolving_failed_get_address(const uint8_t * event, bd_addr_t address){
        reverse_bd_addr(&event[5], address);    
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event SM_EVENT_IDENTITY_RESOLVING_SUCCEEDED
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t sm_event_identity_resolving_succeeded_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field addr_type from event SM_EVENT_IDENTITY_RESOLVING_SUCCEEDED
     * @param event packet
     * @return addr_type
     * @note: btstack_type 1
     */
    static inline uint8_t sm_event_identity_resolving_succeeded_get_addr_type(const uint8_t * event){
        return event[4];
    }
    /**
     * @brief Get field address from event SM_EVENT_IDENTITY_RESOLVING_SUCCEEDED
     * @param event packet
     * @param Pointer to storage for address
     * @note: btstack_type B
     */
    static inline void sm_event_identity_resolving_succeeded_get_address(const uint8_t * event, bd_addr_t address){
        reverse_bd_addr(&event[5], address);    
    }
    /**
     * @brief Get field identity_addr_type from event SM_EVENT_IDENTITY_RESOLVING_SUCCEEDED
     * @param event packet
     * @return identity_addr_type
     * @note: btstack_type 1
     */
    static inline uint8_t sm_event_identity_resolving_succeeded_get_identity_addr_type(const uint8_t * event){
        return event[11];
    }
    /**
     * @brief Get field identity_address from event SM_EVENT_IDENTITY_RESOLVING_SUCCEEDED
     * @param event packet
     * @param Pointer to storage for identity_address
     * @note: btstack_type B
     */
    static inline void sm_event_identity_resolving_succeeded_get_identity_address(const uint8_t * event, bd_addr_t identity_address){
        reverse_bd_addr(&event[12], identity_address);    
    }
    /**
     * @brief Get field index_internal from event SM_EVENT_IDENTITY_RESOLVING_SUCCEEDED
     * @param event packet
     * @return index_internal
     * @note: btstack_type 2
     */
    static inline uint16_t sm_event_identity_resolving_succeeded_get_index_internal(const uint8_t * event){
        return little_endian_read_16(event, 18);
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event SM_EVENT_AUTHORIZATION_REQUEST
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t sm_event_authorization_request_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field addr_type from event SM_EVENT_AUTHORIZATION_REQUEST
     * @param event packet
     * @return addr_type
     * @note: btstack_type 1
     */
    static inline uint8_t sm_event_authorization_request_get_addr_type(const uint8_t * event){
        return event[4];
    }
    /**
     * @brief Get field address from event SM_EVENT_AUTHORIZATION_REQUEST
     * @param event packet
     * @param Pointer to storage for address
     * @note: btstack_type B
     */
    static inline void sm_event_authorization_request_get_address(const uint8_t * event, bd_addr_t address){
        reverse_bd_addr(&event[5], address);    
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event SM_EVENT_AUTHORIZATION_RESULT
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t sm_event_authorization_result_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field addr_type from event SM_EVENT_AUTHORIZATION_RESULT
     * @param event packet
     * @return addr_type
     * @note: btstack_type 1
     */
    static inline uint8_t sm_event_authorization_result_get_addr_type(const uint8_t * event){
        return event[4];
    }
    /**
     * @brief Get field address from event SM_EVENT_AUTHORIZATION_RESULT
     * @param event packet
     * @param Pointer to storage for address
     * @note: btstack_type B
     */
    static inline void sm_event_authorization_result_get_address(const uint8_t * event, bd_addr_t address){
        reverse_bd_addr(&event[5], address);    
    }
    /**
     * @brief Get field authorization_result from event SM_EVENT_AUTHORIZATION_RESULT
     * @param event packet
     * @return authorization_result
     * @note: btstack_type 1
     */
    static inline uint8_t sm_event_authorization_result_get_authorization_result(const uint8_t * event){
        return event[11];
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event SM_EVENT_KEYPRESS_NOTIFICATION
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t sm_event_keypress_notification_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field action from event SM_EVENT_KEYPRESS_NOTIFICATION
     * @param event packet
     * @return action
     * @note: btstack_type 1
     */
    static inline uint8_t sm_event_keypress_notification_get_action(const uint8_t * event){
        return event[4];
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event SM_EVENT_IDENTITY_CREATED
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t sm_event_identity_created_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field addr_type from event SM_EVENT_IDENTITY_CREATED
     * @param event packet
     * @return addr_type
     * @note: btstack_type 1
     */
    static inline uint8_t sm_event_identity_created_get_addr_type(const uint8_t * event){
        return event[4];
    }
    /**
     * @brief Get field address from event SM_EVENT_IDENTITY_CREATED
     * @param event packet
     * @param Pointer to storage for address
     * @note: btstack_type B
     */
    static inline void sm_event_identity_created_get_address(const uint8_t * event, bd_addr_t address){
        reverse_bd_addr(&event[5], address);    
    }
    /**
     * @brief Get field identity_addr_type from event SM_EVENT_IDENTITY_CREATED
     * @param event packet
     * @return identity_addr_type
     * @note: btstack_type 1
     */
    static inline uint8_t sm_event_identity_created_get_identity_addr_type(const uint8_t * event){
        return event[11];
    }
    /**
     * @brief Get field identity_address from event SM_EVENT_IDENTITY_CREATED
     * @param event packet
     * @param Pointer to storage for identity_address
     * @note: btstack_type B
     */
    static inline void sm_event_identity_created_get_identity_address(const uint8_t * event, bd_addr_t identity_address){
        reverse_bd_addr(&event[12], identity_address);    
    }
    #endif
    
    /**
     * @brief Get field handle from event GAP_EVENT_SECURITY_LEVEL
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t gap_event_security_level_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 2);
    }
    /**
     * @brief Get field security_level from event GAP_EVENT_SECURITY_LEVEL
     * @param event packet
     * @return security_level
     * @note: btstack_type 1
     */
    static inline uint8_t gap_event_security_level_get_security_level(const uint8_t * event){
        return event[4];
    }
    
    /**
     * @brief Get field status from event GAP_EVENT_DEDICATED_BONDING_COMPLETED
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t gap_event_dedicated_bonding_completed_get_status(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field address from event GAP_EVENT_DEDICATED_BONDING_COMPLETED
     * @param event packet
     * @param Pointer to storage for address
     * @note: btstack_type B
     */
    static inline void gap_event_dedicated_bonding_completed_get_address(const uint8_t * event, bd_addr_t address){
        reverse_bd_addr(&event[3], address);    
    }
    
    /**
     * @brief Get field advertising_event_type from event GAP_EVENT_ADVERTISING_REPORT
     * @param event packet
     * @return advertising_event_type
     * @note: btstack_type 1
     */
    static inline uint8_t gap_event_advertising_report_get_advertising_event_type(const uint8_t * event){
        return event[2];
    }
    /**
     * @brief Get field address_type from event GAP_EVENT_ADVERTISING_REPORT
     * @param event packet
     * @return address_type
     * @note: btstack_type 1
     */
    static inline uint8_t gap_event_advertising_report_get_address_type(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field address from event GAP_EVENT_ADVERTISING_REPORT
     * @param event packet
     * @param Pointer to storage for address
     * @note: btstack_type B
     */
    static inline void gap_event_advertising_report_get_address(const uint8_t * event, bd_addr_t address){
        reverse_bd_addr(&event[4], address);    
    }
    /**
     * @brief Get field rssi from event GAP_EVENT_ADVERTISING_REPORT
     * @param event packet
     * @return rssi
     * @note: btstack_type 1
     */
    static inline uint8_t gap_event_advertising_report_get_rssi(const uint8_t * event){
        return event[10];
    }
    /**
     * @brief Get field data_length from event GAP_EVENT_ADVERTISING_REPORT
     * @param event packet
     * @return data_length
     * @note: btstack_type J
     */
    static inline int gap_event_advertising_report_get_data_length(const uint8_t * event){
        return event[11];
    }
    /**
     * @brief Get field data from event GAP_EVENT_ADVERTISING_REPORT
     * @param event packet
     * @return data
     * @note: btstack_type V
     */
    static inline const uint8_t * gap_event_advertising_report_get_data(const uint8_t * event){
        return &event[12];
    }
    
    /**
     * @brief Get field bd_addr from event GAP_EVENT_INQUIRY_RESULT
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void gap_event_inquiry_result_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[2], bd_addr);    
    }
    /**
     * @brief Get field page_scan_repetition_mode from event GAP_EVENT_INQUIRY_RESULT
     * @param event packet
     * @return page_scan_repetition_mode
     * @note: btstack_type 1
     */
    static inline uint8_t gap_event_inquiry_result_get_page_scan_repetition_mode(const uint8_t * event){
        return event[8];
    }
    /**
     * @brief Get field class_of_device from event GAP_EVENT_INQUIRY_RESULT
     * @param event packet
     * @return class_of_device
     * @note: btstack_type 3
     */
    static inline uint32_t gap_event_inquiry_result_get_class_of_device(const uint8_t * event){
        return little_endian_read_24(event, 9);
    }
    /**
     * @brief Get field clock_offset from event GAP_EVENT_INQUIRY_RESULT
     * @param event packet
     * @return clock_offset
     * @note: btstack_type 2
     */
    static inline uint16_t gap_event_inquiry_result_get_clock_offset(const uint8_t * event){
        return little_endian_read_16(event, 12);
    }
    /**
     * @brief Get field rssi_available from event GAP_EVENT_INQUIRY_RESULT
     * @param event packet
     * @return rssi_available
     * @note: btstack_type 1
     */
    static inline uint8_t gap_event_inquiry_result_get_rssi_available(const uint8_t * event){
        return event[14];
    }
    /**
     * @brief Get field rssi from event GAP_EVENT_INQUIRY_RESULT
     * @param event packet
     * @return rssi
     * @note: btstack_type 1
     */
    static inline uint8_t gap_event_inquiry_result_get_rssi(const uint8_t * event){
        return event[15];
    }
    /**
     * @brief Get field name_available from event GAP_EVENT_INQUIRY_RESULT
     * @param event packet
     * @return name_available
     * @note: btstack_type 1
     */
    static inline uint8_t gap_event_inquiry_result_get_name_available(const uint8_t * event){
        return event[16];
    }
    /**
     * @brief Get field name_len from event GAP_EVENT_INQUIRY_RESULT
     * @param event packet
     * @return name_len
     * @note: btstack_type J
     */
    static inline int gap_event_inquiry_result_get_name_len(const uint8_t * event){
        return event[17];
    }
    /**
     * @brief Get field name from event GAP_EVENT_INQUIRY_RESULT
     * @param event packet
     * @return name
     * @note: btstack_type V
     */
    static inline const uint8_t * gap_event_inquiry_result_get_name(const uint8_t * event){
        return &event[18];
    }
    
    /**
     * @brief Get field status from event GAP_EVENT_INQUIRY_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t gap_event_inquiry_complete_get_status(const uint8_t * event){
        return event[2];
    }
    
    /**
     * @brief Get field status from event HCI_SUBEVENT_LE_CONNECTION_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_subevent_le_connection_complete_get_status(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field connection_handle from event HCI_SUBEVENT_LE_CONNECTION_COMPLETE
     * @param event packet
     * @return connection_handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t hci_subevent_le_connection_complete_get_connection_handle(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    /**
     * @brief Get field role from event HCI_SUBEVENT_LE_CONNECTION_COMPLETE
     * @param event packet
     * @return role
     * @note: btstack_type 1
     */
    static inline uint8_t hci_subevent_le_connection_complete_get_role(const uint8_t * event){
        return event[6];
    }
    /**
     * @brief Get field peer_address_type from event HCI_SUBEVENT_LE_CONNECTION_COMPLETE
     * @param event packet
     * @return peer_address_type
     * @note: btstack_type 1
     */
    static inline uint8_t hci_subevent_le_connection_complete_get_peer_address_type(const uint8_t * event){
        return event[7];
    }
    /**
     * @brief Get field peer_address from event HCI_SUBEVENT_LE_CONNECTION_COMPLETE
     * @param event packet
     * @param Pointer to storage for peer_address
     * @note: btstack_type B
     */
    static inline void hci_subevent_le_connection_complete_get_peer_address(const uint8_t * event, bd_addr_t peer_address){
        reverse_bd_addr(&event[8], peer_address);    
    }
    /**
     * @brief Get field conn_interval from event HCI_SUBEVENT_LE_CONNECTION_COMPLETE
     * @param event packet
     * @return conn_interval
     * @note: btstack_type 2
     */
    static inline uint16_t hci_subevent_le_connection_complete_get_conn_interval(const uint8_t * event){
        return little_endian_read_16(event, 14);
    }
    /**
     * @brief Get field conn_latency from event HCI_SUBEVENT_LE_CONNECTION_COMPLETE
     * @param event packet
     * @return conn_latency
     * @note: btstack_type 2
     */
    static inline uint16_t hci_subevent_le_connection_complete_get_conn_latency(const uint8_t * event){
        return little_endian_read_16(event, 16);
    }
    /**
     * @brief Get field supervision_timeout from event HCI_SUBEVENT_LE_CONNECTION_COMPLETE
     * @param event packet
     * @return supervision_timeout
     * @note: btstack_type 2
     */
    static inline uint16_t hci_subevent_le_connection_complete_get_supervision_timeout(const uint8_t * event){
        return little_endian_read_16(event, 18);
    }
    /**
     * @brief Get field master_clock_accuracy from event HCI_SUBEVENT_LE_CONNECTION_COMPLETE
     * @param event packet
     * @return master_clock_accuracy
     * @note: btstack_type 1
     */
    static inline uint8_t hci_subevent_le_connection_complete_get_master_clock_accuracy(const uint8_t * event){
        return event[20];
    }
    
    /**
     * @brief Get field status from event HCI_SUBEVENT_LE_CONNECTION_UPDATE_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_subevent_le_connection_update_complete_get_status(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field connection_handle from event HCI_SUBEVENT_LE_CONNECTION_UPDATE_COMPLETE
     * @param event packet
     * @return connection_handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t hci_subevent_le_connection_update_complete_get_connection_handle(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    /**
     * @brief Get field conn_interval from event HCI_SUBEVENT_LE_CONNECTION_UPDATE_COMPLETE
     * @param event packet
     * @return conn_interval
     * @note: btstack_type 2
     */
    static inline uint16_t hci_subevent_le_connection_update_complete_get_conn_interval(const uint8_t * event){
        return little_endian_read_16(event, 6);
    }
    /**
     * @brief Get field conn_latency from event HCI_SUBEVENT_LE_CONNECTION_UPDATE_COMPLETE
     * @param event packet
     * @return conn_latency
     * @note: btstack_type 2
     */
    static inline uint16_t hci_subevent_le_connection_update_complete_get_conn_latency(const uint8_t * event){
        return little_endian_read_16(event, 8);
    }
    /**
     * @brief Get field supervision_timeout from event HCI_SUBEVENT_LE_CONNECTION_UPDATE_COMPLETE
     * @param event packet
     * @return supervision_timeout
     * @note: btstack_type 2
     */
    static inline uint16_t hci_subevent_le_connection_update_complete_get_supervision_timeout(const uint8_t * event){
        return little_endian_read_16(event, 10);
    }
    
    /**
     * @brief Get field connection_handle from event HCI_SUBEVENT_LE_READ_REMOTE_USED_FEATURES_COMPLETE
     * @param event packet
     * @return connection_handle
     * @note: btstack_type H
     */
    //  static inline hci_con_handle_t hci_subevent_le_read_remote_used_features_complete_get_connection_handle(const uint8_t * event){
    //      not implemented yet
    //  }
    /**
     * @brief Get field random_number from event HCI_SUBEVENT_LE_READ_REMOTE_USED_FEATURES_COMPLETE
     * @param event packet
     * @return random_number
     * @note: btstack_type D
     */
    //  static inline const uint8_t * hci_subevent_le_read_remote_used_features_complete_get_random_number(const uint8_t * event){
    //      not implemented yet
    //  }
    /**
     * @brief Get field encryption_diversifier from event HCI_SUBEVENT_LE_READ_REMOTE_USED_FEATURES_COMPLETE
     * @param event packet
     * @return encryption_diversifier
     * @note: btstack_type 2
     */
    //  static inline uint16_t hci_subevent_le_read_remote_used_features_complete_get_encryption_diversifier(const uint8_t * event){
    //      not implemented yet
    //  }
    
    /**
     * @brief Get field connection_handle from event HCI_SUBEVENT_LE_LONG_TERM_KEY_REQUEST
     * @param event packet
     * @return connection_handle
     * @note: btstack_type H
     */
    //  static inline hci_con_handle_t hci_subevent_le_long_term_key_request_get_connection_handle(const uint8_t * event){
    //      not implemented yet
    //  }
    /**
     * @brief Get field random_number from event HCI_SUBEVENT_LE_LONG_TERM_KEY_REQUEST
     * @param event packet
     * @return random_number
     * @note: btstack_type D
     */
    //  static inline const uint8_t * hci_subevent_le_long_term_key_request_get_random_number(const uint8_t * event){
    //      not implemented yet
    //  }
    /**
     * @brief Get field encryption_diversifier from event HCI_SUBEVENT_LE_LONG_TERM_KEY_REQUEST
     * @param event packet
     * @return encryption_diversifier
     * @note: btstack_type 2
     */
    //  static inline uint16_t hci_subevent_le_long_term_key_request_get_encryption_diversifier(const uint8_t * event){
    //      not implemented yet
    //  }
    
    /**
     * @brief Get field connection_handle from event HCI_SUBEVENT_LE_REMOTE_CONNECTION_PARAMETER_REQUEST
     * @param event packet
     * @return connection_handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t hci_subevent_le_remote_connection_parameter_request_get_connection_handle(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field interval_min from event HCI_SUBEVENT_LE_REMOTE_CONNECTION_PARAMETER_REQUEST
     * @param event packet
     * @return interval_min
     * @note: btstack_type 2
     */
    static inline uint16_t hci_subevent_le_remote_connection_parameter_request_get_interval_min(const uint8_t * event){
        return little_endian_read_16(event, 5);
    }
    /**
     * @brief Get field interval_max from event HCI_SUBEVENT_LE_REMOTE_CONNECTION_PARAMETER_REQUEST
     * @param event packet
     * @return interval_max
     * @note: btstack_type 2
     */
    static inline uint16_t hci_subevent_le_remote_connection_parameter_request_get_interval_max(const uint8_t * event){
        return little_endian_read_16(event, 7);
    }
    /**
     * @brief Get field latency from event HCI_SUBEVENT_LE_REMOTE_CONNECTION_PARAMETER_REQUEST
     * @param event packet
     * @return latency
     * @note: btstack_type 2
     */
    static inline uint16_t hci_subevent_le_remote_connection_parameter_request_get_latency(const uint8_t * event){
        return little_endian_read_16(event, 9);
    }
    /**
     * @brief Get field timeout from event HCI_SUBEVENT_LE_REMOTE_CONNECTION_PARAMETER_REQUEST
     * @param event packet
     * @return timeout
     * @note: btstack_type 2
     */
    static inline uint16_t hci_subevent_le_remote_connection_parameter_request_get_timeout(const uint8_t * event){
        return little_endian_read_16(event, 11);
    }
    
    /**
     * @brief Get field connection_handle from event HCI_SUBEVENT_LE_DATA_LENGTH_CHANGE
     * @param event packet
     * @return connection_handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t hci_subevent_le_data_length_change_get_connection_handle(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field max_tx_octets from event HCI_SUBEVENT_LE_DATA_LENGTH_CHANGE
     * @param event packet
     * @return max_tx_octets
     * @note: btstack_type 2
     */
    static inline uint16_t hci_subevent_le_data_length_change_get_max_tx_octets(const uint8_t * event){
        return little_endian_read_16(event, 5);
    }
    /**
     * @brief Get field max_tx_time from event HCI_SUBEVENT_LE_DATA_LENGTH_CHANGE
     * @param event packet
     * @return max_tx_time
     * @note: btstack_type 2
     */
    static inline uint16_t hci_subevent_le_data_length_change_get_max_tx_time(const uint8_t * event){
        return little_endian_read_16(event, 7);
    }
    /**
     * @brief Get field max_rx_octets from event HCI_SUBEVENT_LE_DATA_LENGTH_CHANGE
     * @param event packet
     * @return max_rx_octets
     * @note: btstack_type 2
     */
    static inline uint16_t hci_subevent_le_data_length_change_get_max_rx_octets(const uint8_t * event){
        return little_endian_read_16(event, 9);
    }
    /**
     * @brief Get field max_rx_time from event HCI_SUBEVENT_LE_DATA_LENGTH_CHANGE
     * @param event packet
     * @return max_rx_time
     * @note: btstack_type 2
     */
    static inline uint16_t hci_subevent_le_data_length_change_get_max_rx_time(const uint8_t * event){
        return little_endian_read_16(event, 11);
    }
    
    /**
     * @brief Get field status from event HCI_SUBEVENT_LE_READ_LOCAL_P256_PUBLIC_KEY_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_subevent_le_read_local_p256_public_key_complete_get_status(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field dhkey_x from event HCI_SUBEVENT_LE_READ_LOCAL_P256_PUBLIC_KEY_COMPLETE
     * @param event packet
     * @param Pointer to storage for dhkey_x
     * @note: btstack_type Q
     */
    static inline void hci_subevent_le_read_local_p256_public_key_complete_get_dhkey_x(const uint8_t * event, uint8_t * dhkey_x){
        reverse_bytes(&event[4], dhkey_x, 32);    
    }
    /**
     * @brief Get field dhkey_y from event HCI_SUBEVENT_LE_READ_LOCAL_P256_PUBLIC_KEY_COMPLETE
     * @param event packet
     * @param Pointer to storage for dhkey_y
     * @note: btstack_type Q
     */
    static inline void hci_subevent_le_read_local_p256_public_key_complete_get_dhkey_y(const uint8_t * event, uint8_t * dhkey_y){
        reverse_bytes(&event[36], dhkey_y, 32);    
    }
    
    /**
     * @brief Get field status from event HCI_SUBEVENT_LE_GENERATE_DHKEY_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_subevent_le_generate_dhkey_complete_get_status(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field dhkey_x from event HCI_SUBEVENT_LE_GENERATE_DHKEY_COMPLETE
     * @param event packet
     * @param Pointer to storage for dhkey_x
     * @note: btstack_type Q
     */
    static inline void hci_subevent_le_generate_dhkey_complete_get_dhkey_x(const uint8_t * event, uint8_t * dhkey_x){
        reverse_bytes(&event[4], dhkey_x, 32);    
    }
    /**
     * @brief Get field dhkey_y from event HCI_SUBEVENT_LE_GENERATE_DHKEY_COMPLETE
     * @param event packet
     * @param Pointer to storage for dhkey_y
     * @note: btstack_type Q
     */
    static inline void hci_subevent_le_generate_dhkey_complete_get_dhkey_y(const uint8_t * event, uint8_t * dhkey_y){
        reverse_bytes(&event[36], dhkey_y, 32);    
    }
    
    /**
     * @brief Get field status from event HCI_SUBEVENT_LE_ENHANCED_CONNECTION_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hci_subevent_le_enhanced_connection_complete_get_status(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field connection_handle from event HCI_SUBEVENT_LE_ENHANCED_CONNECTION_COMPLETE
     * @param event packet
     * @return connection_handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t hci_subevent_le_enhanced_connection_complete_get_connection_handle(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    /**
     * @brief Get field role from event HCI_SUBEVENT_LE_ENHANCED_CONNECTION_COMPLETE
     * @param event packet
     * @return role
     * @note: btstack_type 1
     */
    static inline uint8_t hci_subevent_le_enhanced_connection_complete_get_role(const uint8_t * event){
        return event[6];
    }
    /**
     * @brief Get field peer_address_type from event HCI_SUBEVENT_LE_ENHANCED_CONNECTION_COMPLETE
     * @param event packet
     * @return peer_address_type
     * @note: btstack_type 1
     */
    static inline uint8_t hci_subevent_le_enhanced_connection_complete_get_peer_address_type(const uint8_t * event){
        return event[7];
    }
    /**
     * @brief Get field perr_addresss from event HCI_SUBEVENT_LE_ENHANCED_CONNECTION_COMPLETE
     * @param event packet
     * @param Pointer to storage for perr_addresss
     * @note: btstack_type B
     */
    static inline void hci_subevent_le_enhanced_connection_complete_get_perr_addresss(const uint8_t * event, bd_addr_t perr_addresss){
        reverse_bd_addr(&event[8], perr_addresss);    
    }
    /**
     * @brief Get field local_resolvable_private_addres from event HCI_SUBEVENT_LE_ENHANCED_CONNECTION_COMPLETE
     * @param event packet
     * @param Pointer to storage for local_resolvable_private_addres
     * @note: btstack_type B
     */
    static inline void hci_subevent_le_enhanced_connection_complete_get_local_resolvable_private_addres(const uint8_t * event, bd_addr_t local_resolvable_private_addres){
        reverse_bd_addr(&event[14], local_resolvable_private_addres);    
    }
    /**
     * @brief Get field peer_resolvable_private_addres from event HCI_SUBEVENT_LE_ENHANCED_CONNECTION_COMPLETE
     * @param event packet
     * @param Pointer to storage for peer_resolvable_private_addres
     * @note: btstack_type B
     */
    static inline void hci_subevent_le_enhanced_connection_complete_get_peer_resolvable_private_addres(const uint8_t * event, bd_addr_t peer_resolvable_private_addres){
        reverse_bd_addr(&event[20], peer_resolvable_private_addres);    
    }
    /**
     * @brief Get field conn_interval from event HCI_SUBEVENT_LE_ENHANCED_CONNECTION_COMPLETE
     * @param event packet
     * @return conn_interval
     * @note: btstack_type 2
     */
    static inline uint16_t hci_subevent_le_enhanced_connection_complete_get_conn_interval(const uint8_t * event){
        return little_endian_read_16(event, 26);
    }
    /**
     * @brief Get field conn_latency from event HCI_SUBEVENT_LE_ENHANCED_CONNECTION_COMPLETE
     * @param event packet
     * @return conn_latency
     * @note: btstack_type 2
     */
    static inline uint16_t hci_subevent_le_enhanced_connection_complete_get_conn_latency(const uint8_t * event){
        return little_endian_read_16(event, 28);
    }
    /**
     * @brief Get field supervision_timeout from event HCI_SUBEVENT_LE_ENHANCED_CONNECTION_COMPLETE
     * @param event packet
     * @return supervision_timeout
     * @note: btstack_type 2
     */
    static inline uint16_t hci_subevent_le_enhanced_connection_complete_get_supervision_timeout(const uint8_t * event){
        return little_endian_read_16(event, 30);
    }
    /**
     * @brief Get field master_clock_accuracy from event HCI_SUBEVENT_LE_ENHANCED_CONNECTION_COMPLETE
     * @param event packet
     * @return master_clock_accuracy
     * @note: btstack_type 1
     */
    static inline uint8_t hci_subevent_le_enhanced_connection_complete_get_master_clock_accuracy(const uint8_t * event){
        return event[32];
    }
    
    /**
     * @brief Get field status from event HSP_SUBEVENT_RFCOMM_CONNECTION_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hsp_subevent_rfcomm_connection_complete_get_status(const uint8_t * event){
        return event[3];
    }
    
    /**
     * @brief Get field status from event HSP_SUBEVENT_RFCOMM_DISCONNECTION_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hsp_subevent_rfcomm_disconnection_complete_get_status(const uint8_t * event){
        return event[3];
    }
    
    /**
     * @brief Get field status from event HSP_SUBEVENT_AUDIO_CONNECTION_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hsp_subevent_audio_connection_complete_get_status(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field handle from event HSP_SUBEVENT_AUDIO_CONNECTION_COMPLETE
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t hsp_subevent_audio_connection_complete_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    
    /**
     * @brief Get field status from event HSP_SUBEVENT_AUDIO_DISCONNECTION_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hsp_subevent_audio_disconnection_complete_get_status(const uint8_t * event){
        return event[3];
    }
    
    
    /**
     * @brief Get field gain from event HSP_SUBEVENT_MICROPHONE_GAIN_CHANGED
     * @param event packet
     * @return gain
     * @note: btstack_type 1
     */
    static inline uint8_t hsp_subevent_microphone_gain_changed_get_gain(const uint8_t * event){
        return event[3];
    }
    
    /**
     * @brief Get field gain from event HSP_SUBEVENT_SPEAKER_GAIN_CHANGED
     * @param event packet
     * @return gain
     * @note: btstack_type 1
     */
    static inline uint8_t hsp_subevent_speaker_gain_changed_get_gain(const uint8_t * event){
        return event[3];
    }
    
    /**
     * @brief Get field value_length from event HSP_SUBEVENT_HS_COMMAND
     * @param event packet
     * @return value_length
     * @note: btstack_type J
     */
    static inline int hsp_subevent_hs_command_get_value_length(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field value from event HSP_SUBEVENT_HS_COMMAND
     * @param event packet
     * @return value
     * @note: btstack_type V
     */
    static inline const uint8_t * hsp_subevent_hs_command_get_value(const uint8_t * event){
        return &event[4];
    }
    
    /**
     * @brief Get field value_length from event HSP_SUBEVENT_AG_INDICATION
     * @param event packet
     * @return value_length
     * @note: btstack_type J
     */
    static inline int hsp_subevent_ag_indication_get_value_length(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field value from event HSP_SUBEVENT_AG_INDICATION
     * @param event packet
     * @return value
     * @note: btstack_type V
     */
    static inline const uint8_t * hsp_subevent_ag_indication_get_value(const uint8_t * event){
        return &event[4];
    }
    
    /**
     * @brief Get field status from event HFP_SUBEVENT_SERVICE_LEVEL_CONNECTION_ESTABLISHED
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_service_level_connection_established_get_status(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field con_handle from event HFP_SUBEVENT_SERVICE_LEVEL_CONNECTION_ESTABLISHED
     * @param event packet
     * @return con_handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t hfp_subevent_service_level_connection_established_get_con_handle(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    /**
     * @brief Get field bd_addr from event HFP_SUBEVENT_SERVICE_LEVEL_CONNECTION_ESTABLISHED
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void hfp_subevent_service_level_connection_established_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[6], bd_addr);    
    }
    
    
    /**
     * @brief Get field status from event HFP_SUBEVENT_AUDIO_CONNECTION_ESTABLISHED
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_audio_connection_established_get_status(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field handle from event HFP_SUBEVENT_AUDIO_CONNECTION_ESTABLISHED
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t hfp_subevent_audio_connection_established_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 4);
    }
    /**
     * @brief Get field bd_addr from event HFP_SUBEVENT_AUDIO_CONNECTION_ESTABLISHED
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void hfp_subevent_audio_connection_established_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[6], bd_addr);    
    }
    /**
     * @brief Get field negotiated_codec from event HFP_SUBEVENT_AUDIO_CONNECTION_ESTABLISHED
     * @param event packet
     * @return negotiated_codec
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_audio_connection_established_get_negotiated_codec(const uint8_t * event){
        return event[12];
    }
    
    
    /**
     * @brief Get field status from event HFP_SUBEVENT_COMPLETE
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_complete_get_status(const uint8_t * event){
        return event[3];
    }
    
    /**
     * @brief Get field indicator_index from event HFP_SUBEVENT_AG_INDICATOR_STATUS_CHANGED
     * @param event packet
     * @return indicator_index
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_ag_indicator_status_changed_get_indicator_index(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field indicator_status from event HFP_SUBEVENT_AG_INDICATOR_STATUS_CHANGED
     * @param event packet
     * @return indicator_status
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_ag_indicator_status_changed_get_indicator_status(const uint8_t * event){
        return event[4];
    }
    /**
     * @brief Get field indicator_name from event HFP_SUBEVENT_AG_INDICATOR_STATUS_CHANGED
     * @param event packet
     * @return indicator_name
     * @note: btstack_type T
     */
    static inline const char * hfp_subevent_ag_indicator_status_changed_get_indicator_name(const uint8_t * event){
        return (const char *) &event[5];
    }
    
    /**
     * @brief Get field network_operator_mode from event HFP_SUBEVENT_NETWORK_OPERATOR_CHANGED
     * @param event packet
     * @return network_operator_mode
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_network_operator_changed_get_network_operator_mode(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field network_operator_format from event HFP_SUBEVENT_NETWORK_OPERATOR_CHANGED
     * @param event packet
     * @return network_operator_format
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_network_operator_changed_get_network_operator_format(const uint8_t * event){
        return event[4];
    }
    /**
     * @brief Get field network_operator_name from event HFP_SUBEVENT_NETWORK_OPERATOR_CHANGED
     * @param event packet
     * @return network_operator_name
     * @note: btstack_type T
     */
    static inline const char * hfp_subevent_network_operator_changed_get_network_operator_name(const uint8_t * event){
        return (const char *) &event[5];
    }
    
    /**
     * @brief Get field error from event HFP_SUBEVENT_EXTENDED_AUDIO_GATEWAY_ERROR
     * @param event packet
     * @return error
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_extended_audio_gateway_error_get_error(const uint8_t * event){
        return event[3];
    }
    
    
    
    
    /**
     * @brief Get field number from event HFP_SUBEVENT_PLACE_CALL_WITH_NUMBER
     * @param event packet
     * @return number
     * @note: btstack_type T
     */
    static inline const char * hfp_subevent_place_call_with_number_get_number(const uint8_t * event){
        return (const char *) &event[3];
    }
    
    
    /**
     * @brief Get field number from event HFP_SUBEVENT_NUMBER_FOR_VOICE_TAG
     * @param event packet
     * @return number
     * @note: btstack_type T
     */
    static inline const char * hfp_subevent_number_for_voice_tag_get_number(const uint8_t * event){
        return (const char *) &event[3];
    }
    
    /**
     * @brief Get field dtmf from event HFP_SUBEVENT_TRANSMIT_DTMF_CODES
     * @param event packet
     * @return dtmf
     * @note: btstack_type T
     */
    static inline const char * hfp_subevent_transmit_dtmf_codes_get_dtmf(const uint8_t * event){
        return (const char *) &event[3];
    }
    
    
    
    
    /**
     * @brief Get field status from event HFP_SUBEVENT_SPEAKER_VOLUME
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_speaker_volume_get_status(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field gain from event HFP_SUBEVENT_SPEAKER_VOLUME
     * @param event packet
     * @return gain
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_speaker_volume_get_gain(const uint8_t * event){
        return event[4];
    }
    
    /**
     * @brief Get field status from event HFP_SUBEVENT_MICROPHONE_VOLUME
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_microphone_volume_get_status(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field gain from event HFP_SUBEVENT_MICROPHONE_VOLUME
     * @param event packet
     * @return gain
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_microphone_volume_get_gain(const uint8_t * event){
        return event[4];
    }
    
    /**
     * @brief Get field type from event HFP_SUBEVENT_CALL_WAITING_NOTIFICATION
     * @param event packet
     * @return type
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_call_waiting_notification_get_type(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field number from event HFP_SUBEVENT_CALL_WAITING_NOTIFICATION
     * @param event packet
     * @return number
     * @note: btstack_type T
     */
    static inline const char * hfp_subevent_call_waiting_notification_get_number(const uint8_t * event){
        return (const char *) &event[4];
    }
    
    /**
     * @brief Get field type from event HFP_SUBEVENT_CALLING_LINE_IDENTIFICATION_NOTIFICATION
     * @param event packet
     * @return type
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_calling_line_identification_notification_get_type(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field number from event HFP_SUBEVENT_CALLING_LINE_IDENTIFICATION_NOTIFICATION
     * @param event packet
     * @return number
     * @note: btstack_type T
     */
    static inline const char * hfp_subevent_calling_line_identification_notification_get_number(const uint8_t * event){
        return (const char *) &event[4];
    }
    
    /**
     * @brief Get field clcc_idx from event HFP_SUBEVENT_ENHANCED_CALL_STATUS
     * @param event packet
     * @return clcc_idx
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_enhanced_call_status_get_clcc_idx(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field clcc_dir from event HFP_SUBEVENT_ENHANCED_CALL_STATUS
     * @param event packet
     * @return clcc_dir
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_enhanced_call_status_get_clcc_dir(const uint8_t * event){
        return event[4];
    }
    /**
     * @brief Get field clcc_status from event HFP_SUBEVENT_ENHANCED_CALL_STATUS
     * @param event packet
     * @return clcc_status
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_enhanced_call_status_get_clcc_status(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field clcc_mpty from event HFP_SUBEVENT_ENHANCED_CALL_STATUS
     * @param event packet
     * @return clcc_mpty
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_enhanced_call_status_get_clcc_mpty(const uint8_t * event){
        return event[6];
    }
    /**
     * @brief Get field bnip_type from event HFP_SUBEVENT_ENHANCED_CALL_STATUS
     * @param event packet
     * @return bnip_type
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_enhanced_call_status_get_bnip_type(const uint8_t * event){
        return event[7];
    }
    /**
     * @brief Get field bnip_number from event HFP_SUBEVENT_ENHANCED_CALL_STATUS
     * @param event packet
     * @return bnip_number
     * @note: btstack_type T
     */
    static inline const char * hfp_subevent_enhanced_call_status_get_bnip_number(const uint8_t * event){
        return (const char *) &event[8];
    }
    
    /**
     * @brief Get field status from event HFP_SUBEVENT_SUBSCRIBER_NUMBER_INFORMATION
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_subscriber_number_information_get_status(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field bnip_type from event HFP_SUBEVENT_SUBSCRIBER_NUMBER_INFORMATION
     * @param event packet
     * @return bnip_type
     * @note: btstack_type 1
     */
    static inline uint8_t hfp_subevent_subscriber_number_information_get_bnip_type(const uint8_t * event){
        return event[4];
    }
    /**
     * @brief Get field bnip_number from event HFP_SUBEVENT_SUBSCRIBER_NUMBER_INFORMATION
     * @param event packet
     * @return bnip_number
     * @note: btstack_type T
     */
    static inline const char * hfp_subevent_subscriber_number_information_get_bnip_number(const uint8_t * event){
        return (const char *) &event[5];
    }
    
    /**
     * @brief Get field value from event HFP_SUBEVENT_RESPONSE_AND_HOLD_STATUS
     * @param event packet
     * @return value
     * @note: btstack_type T
     */
    static inline const char * hfp_subevent_response_and_hold_status_get_value(const uint8_t * event){
        return (const char *) &event[3];
    }
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event ANCS_SUBEVENT_CLIENT_CONNECTED
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t ancs_subevent_client_connected_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event ANCS_SUBEVENT_CLIENT_NOTIFICATION
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t ancs_subevent_client_notification_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field attribute_id from event ANCS_SUBEVENT_CLIENT_NOTIFICATION
     * @param event packet
     * @return attribute_id
     * @note: btstack_type 2
     */
    static inline uint16_t ancs_subevent_client_notification_get_attribute_id(const uint8_t * event){
        return little_endian_read_16(event, 5);
    }
    /**
     * @brief Get field text from event ANCS_SUBEVENT_CLIENT_NOTIFICATION
     * @param event packet
     * @return text
     * @note: btstack_type T
     */
    static inline const char * ancs_subevent_client_notification_get_text(const uint8_t * event){
        return (const char *) &event[7];
    }
    #endif
    
    #ifdef ENABLE_BLE
    /**
     * @brief Get field handle from event ANCS_SUBEVENT_CLIENT_DISCONNECTED
     * @param event packet
     * @return handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t ancs_subevent_client_disconnected_get_handle(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    #endif
    
    /**
     * @brief Get field avdtp_cid from event AVDTP_SUBEVENT_SIGNALING_ACCEPT
     * @param event packet
     * @return avdtp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avdtp_subevent_signaling_accept_get_avdtp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field local_seid from event AVDTP_SUBEVENT_SIGNALING_ACCEPT
     * @param event packet
     * @return local_seid
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_accept_get_local_seid(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field signal_identifier from event AVDTP_SUBEVENT_SIGNALING_ACCEPT
     * @param event packet
     * @return signal_identifier
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_accept_get_signal_identifier(const uint8_t * event){
        return event[6];
    }
    
    /**
     * @brief Get field avdtp_cid from event AVDTP_SUBEVENT_SIGNALING_REJECT
     * @param event packet
     * @return avdtp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avdtp_subevent_signaling_reject_get_avdtp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field local_seid from event AVDTP_SUBEVENT_SIGNALING_REJECT
     * @param event packet
     * @return local_seid
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_reject_get_local_seid(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field signal_identifier from event AVDTP_SUBEVENT_SIGNALING_REJECT
     * @param event packet
     * @return signal_identifier
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_reject_get_signal_identifier(const uint8_t * event){
        return event[6];
    }
    
    /**
     * @brief Get field avdtp_cid from event AVDTP_SUBEVENT_SIGNALING_GENERAL_REJECT
     * @param event packet
     * @return avdtp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avdtp_subevent_signaling_general_reject_get_avdtp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field local_seid from event AVDTP_SUBEVENT_SIGNALING_GENERAL_REJECT
     * @param event packet
     * @return local_seid
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_general_reject_get_local_seid(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field signal_identifier from event AVDTP_SUBEVENT_SIGNALING_GENERAL_REJECT
     * @param event packet
     * @return signal_identifier
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_general_reject_get_signal_identifier(const uint8_t * event){
        return event[6];
    }
    
    /**
     * @brief Get field avdtp_cid from event AVDTP_SUBEVENT_SIGNALING_CONNECTION_ESTABLISHED
     * @param event packet
     * @return avdtp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avdtp_subevent_signaling_connection_established_get_avdtp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field bd_addr from event AVDTP_SUBEVENT_SIGNALING_CONNECTION_ESTABLISHED
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void avdtp_subevent_signaling_connection_established_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[5], bd_addr);    
    }
    /**
     * @brief Get field status from event AVDTP_SUBEVENT_SIGNALING_CONNECTION_ESTABLISHED
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_connection_established_get_status(const uint8_t * event){
        return event[11];
    }
    
    /**
     * @brief Get field avdtp_cid from event AVDTP_SUBEVENT_SIGNALING_CONNECTION_RELEASED
     * @param event packet
     * @return avdtp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avdtp_subevent_signaling_connection_released_get_avdtp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    
    /**
     * @brief Get field avdtp_cid from event AVDTP_SUBEVENT_SIGNALING_SEP_FOUND
     * @param event packet
     * @return avdtp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avdtp_subevent_signaling_sep_found_get_avdtp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field remote_seid from event AVDTP_SUBEVENT_SIGNALING_SEP_FOUND
     * @param event packet
     * @return remote_seid
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_sep_found_get_remote_seid(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field in_use from event AVDTP_SUBEVENT_SIGNALING_SEP_FOUND
     * @param event packet
     * @return in_use
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_sep_found_get_in_use(const uint8_t * event){
        return event[6];
    }
    /**
     * @brief Get field media_type from event AVDTP_SUBEVENT_SIGNALING_SEP_FOUND
     * @param event packet
     * @return media_type
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_sep_found_get_media_type(const uint8_t * event){
        return event[7];
    }
    /**
     * @brief Get field sep_type from event AVDTP_SUBEVENT_SIGNALING_SEP_FOUND
     * @param event packet
     * @return sep_type
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_sep_found_get_sep_type(const uint8_t * event){
        return event[8];
    }
    
    /**
     * @brief Get field avdtp_cid from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CAPABILITY
     * @param event packet
     * @return avdtp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avdtp_subevent_signaling_media_codec_sbc_capability_get_avdtp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field local_seid from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CAPABILITY
     * @param event packet
     * @return local_seid
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_capability_get_local_seid(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field remote_seid from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CAPABILITY
     * @param event packet
     * @return remote_seid
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_capability_get_remote_seid(const uint8_t * event){
        return event[6];
    }
    /**
     * @brief Get field media_type from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CAPABILITY
     * @param event packet
     * @return media_type
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_capability_get_media_type(const uint8_t * event){
        return event[7];
    }
    /**
     * @brief Get field sampling_frequency_bitmap from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CAPABILITY
     * @param event packet
     * @return sampling_frequency_bitmap
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_capability_get_sampling_frequency_bitmap(const uint8_t * event){
        return event[8];
    }
    /**
     * @brief Get field channel_mode_bitmap from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CAPABILITY
     * @param event packet
     * @return channel_mode_bitmap
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_capability_get_channel_mode_bitmap(const uint8_t * event){
        return event[9];
    }
    /**
     * @brief Get field block_length_bitmap from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CAPABILITY
     * @param event packet
     * @return block_length_bitmap
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_capability_get_block_length_bitmap(const uint8_t * event){
        return event[10];
    }
    /**
     * @brief Get field subbands_bitmap from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CAPABILITY
     * @param event packet
     * @return subbands_bitmap
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_capability_get_subbands_bitmap(const uint8_t * event){
        return event[11];
    }
    /**
     * @brief Get field allocation_method_bitmap from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CAPABILITY
     * @param event packet
     * @return allocation_method_bitmap
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_capability_get_allocation_method_bitmap(const uint8_t * event){
        return event[12];
    }
    /**
     * @brief Get field min_bitpool_value from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CAPABILITY
     * @param event packet
     * @return min_bitpool_value
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_capability_get_min_bitpool_value(const uint8_t * event){
        return event[13];
    }
    /**
     * @brief Get field max_bitpool_value from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CAPABILITY
     * @param event packet
     * @return max_bitpool_value
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_capability_get_max_bitpool_value(const uint8_t * event){
        return event[14];
    }
    
    /**
     * @brief Get field avdtp_cid from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CAPABILITY
     * @param event packet
     * @return avdtp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avdtp_subevent_signaling_media_codec_other_capability_get_avdtp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field local_seid from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CAPABILITY
     * @param event packet
     * @return local_seid
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_other_capability_get_local_seid(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field remote_seid from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CAPABILITY
     * @param event packet
     * @return remote_seid
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_other_capability_get_remote_seid(const uint8_t * event){
        return event[6];
    }
    /**
     * @brief Get field media_type from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CAPABILITY
     * @param event packet
     * @return media_type
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_other_capability_get_media_type(const uint8_t * event){
        return event[7];
    }
    /**
     * @brief Get field media_codec_type from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CAPABILITY
     * @param event packet
     * @return media_codec_type
     * @note: btstack_type 2
     */
    static inline uint16_t avdtp_subevent_signaling_media_codec_other_capability_get_media_codec_type(const uint8_t * event){
        return little_endian_read_16(event, 8);
    }
    /**
     * @brief Get field media_codec_information_len from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CAPABILITY
     * @param event packet
     * @return media_codec_information_len
     * @note: btstack_type L
     */
    static inline int avdtp_subevent_signaling_media_codec_other_capability_get_media_codec_information_len(const uint8_t * event){
        return little_endian_read_16(event, 10);
    }
    /**
     * @brief Get field media_codec_information from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CAPABILITY
     * @param event packet
     * @return media_codec_information
     * @note: btstack_type V
     */
    static inline const uint8_t * avdtp_subevent_signaling_media_codec_other_capability_get_media_codec_information(const uint8_t * event){
        return &event[12];
    }
    
    /**
     * @brief Get field avdtp_cid from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return avdtp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avdtp_subevent_signaling_media_codec_sbc_configuration_get_avdtp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field local_seid from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return local_seid
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_configuration_get_local_seid(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field remote_seid from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return remote_seid
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_configuration_get_remote_seid(const uint8_t * event){
        return event[6];
    }
    /**
     * @brief Get field reconfigure from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return reconfigure
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_configuration_get_reconfigure(const uint8_t * event){
        return event[7];
    }
    /**
     * @brief Get field media_type from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return media_type
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_configuration_get_media_type(const uint8_t * event){
        return event[8];
    }
    /**
     * @brief Get field sampling_frequency from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return sampling_frequency
     * @note: btstack_type 2
     */
    static inline uint16_t avdtp_subevent_signaling_media_codec_sbc_configuration_get_sampling_frequency(const uint8_t * event){
        return little_endian_read_16(event, 9);
    }
    /**
     * @brief Get field channel_mode from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return channel_mode
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_configuration_get_channel_mode(const uint8_t * event){
        return event[11];
    }
    /**
     * @brief Get field num_channels from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return num_channels
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_configuration_get_num_channels(const uint8_t * event){
        return event[12];
    }
    /**
     * @brief Get field block_length from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return block_length
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_configuration_get_block_length(const uint8_t * event){
        return event[13];
    }
    /**
     * @brief Get field subbands from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return subbands
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_configuration_get_subbands(const uint8_t * event){
        return event[14];
    }
    /**
     * @brief Get field allocation_method from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return allocation_method
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_configuration_get_allocation_method(const uint8_t * event){
        return event[15];
    }
    /**
     * @brief Get field min_bitpool_value from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return min_bitpool_value
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_configuration_get_min_bitpool_value(const uint8_t * event){
        return event[16];
    }
    /**
     * @brief Get field max_bitpool_value from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return max_bitpool_value
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_sbc_configuration_get_max_bitpool_value(const uint8_t * event){
        return event[17];
    }
    
    /**
     * @brief Get field avdtp_cid from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CONFIGURATION
     * @param event packet
     * @return avdtp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avdtp_subevent_signaling_media_codec_other_configuration_get_avdtp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field local_seid from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CONFIGURATION
     * @param event packet
     * @return local_seid
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_other_configuration_get_local_seid(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field remote_seid from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CONFIGURATION
     * @param event packet
     * @return remote_seid
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_other_configuration_get_remote_seid(const uint8_t * event){
        return event[6];
    }
    /**
     * @brief Get field reconfigure from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CONFIGURATION
     * @param event packet
     * @return reconfigure
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_other_configuration_get_reconfigure(const uint8_t * event){
        return event[7];
    }
    /**
     * @brief Get field media_type from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CONFIGURATION
     * @param event packet
     * @return media_type
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_signaling_media_codec_other_configuration_get_media_type(const uint8_t * event){
        return event[8];
    }
    /**
     * @brief Get field media_codec_type from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CONFIGURATION
     * @param event packet
     * @return media_codec_type
     * @note: btstack_type 2
     */
    static inline uint16_t avdtp_subevent_signaling_media_codec_other_configuration_get_media_codec_type(const uint8_t * event){
        return little_endian_read_16(event, 9);
    }
    /**
     * @brief Get field media_codec_information_len from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CONFIGURATION
     * @param event packet
     * @return media_codec_information_len
     * @note: btstack_type L
     */
    static inline int avdtp_subevent_signaling_media_codec_other_configuration_get_media_codec_information_len(const uint8_t * event){
        return little_endian_read_16(event, 11);
    }
    /**
     * @brief Get field media_codec_information from event AVDTP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CONFIGURATION
     * @param event packet
     * @return media_codec_information
     * @note: btstack_type V
     */
    static inline const uint8_t * avdtp_subevent_signaling_media_codec_other_configuration_get_media_codec_information(const uint8_t * event){
        return &event[13];
    }
    
    /**
     * @brief Get field avdtp_cid from event AVDTP_SUBEVENT_STREAMING_CONNECTION_ESTABLISHED
     * @param event packet
     * @return avdtp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avdtp_subevent_streaming_connection_established_get_avdtp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field local_seid from event AVDTP_SUBEVENT_STREAMING_CONNECTION_ESTABLISHED
     * @param event packet
     * @return local_seid
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_streaming_connection_established_get_local_seid(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field remote_seid from event AVDTP_SUBEVENT_STREAMING_CONNECTION_ESTABLISHED
     * @param event packet
     * @return remote_seid
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_streaming_connection_established_get_remote_seid(const uint8_t * event){
        return event[6];
    }
    /**
     * @brief Get field status from event AVDTP_SUBEVENT_STREAMING_CONNECTION_ESTABLISHED
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_streaming_connection_established_get_status(const uint8_t * event){
        return event[7];
    }
    
    /**
     * @brief Get field avdtp_cid from event AVDTP_SUBEVENT_STREAMING_CONNECTION_RELEASED
     * @param event packet
     * @return avdtp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avdtp_subevent_streaming_connection_released_get_avdtp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field local_seid from event AVDTP_SUBEVENT_STREAMING_CONNECTION_RELEASED
     * @param event packet
     * @return local_seid
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_streaming_connection_released_get_local_seid(const uint8_t * event){
        return event[5];
    }
    
    /**
     * @brief Get field avdtp_cid from event AVDTP_SUBEVENT_STREAMING_CAN_SEND_MEDIA_PACKET_NOW
     * @param event packet
     * @return avdtp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avdtp_subevent_streaming_can_send_media_packet_now_get_avdtp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field local_seid from event AVDTP_SUBEVENT_STREAMING_CAN_SEND_MEDIA_PACKET_NOW
     * @param event packet
     * @return local_seid
     * @note: btstack_type 1
     */
    static inline uint8_t avdtp_subevent_streaming_can_send_media_packet_now_get_local_seid(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field sequence_number from event AVDTP_SUBEVENT_STREAMING_CAN_SEND_MEDIA_PACKET_NOW
     * @param event packet
     * @return sequence_number
     * @note: btstack_type 2
     */
    static inline uint16_t avdtp_subevent_streaming_can_send_media_packet_now_get_sequence_number(const uint8_t * event){
        return little_endian_read_16(event, 6);
    }
    
    /**
     * @brief Get field a2dp_cid from event A2DP_SUBEVENT_STREAMING_CAN_SEND_MEDIA_PACKET_NOW
     * @param event packet
     * @return a2dp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t a2dp_subevent_streaming_can_send_media_packet_now_get_a2dp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field local_seid from event A2DP_SUBEVENT_STREAMING_CAN_SEND_MEDIA_PACKET_NOW
     * @param event packet
     * @return local_seid
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_streaming_can_send_media_packet_now_get_local_seid(const uint8_t * event){
        return event[5];
    }
    
    /**
     * @brief Get field a2dp_cid from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return a2dp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t a2dp_subevent_signaling_media_codec_sbc_configuration_get_a2dp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field int_seid from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return int_seid
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_signaling_media_codec_sbc_configuration_get_int_seid(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field acp_seid from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return acp_seid
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_signaling_media_codec_sbc_configuration_get_acp_seid(const uint8_t * event){
        return event[6];
    }
    /**
     * @brief Get field reconfigure from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return reconfigure
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_signaling_media_codec_sbc_configuration_get_reconfigure(const uint8_t * event){
        return event[7];
    }
    /**
     * @brief Get field media_type from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return media_type
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_signaling_media_codec_sbc_configuration_get_media_type(const uint8_t * event){
        return event[8];
    }
    /**
     * @brief Get field sampling_frequency from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return sampling_frequency
     * @note: btstack_type 2
     */
    static inline uint16_t a2dp_subevent_signaling_media_codec_sbc_configuration_get_sampling_frequency(const uint8_t * event){
        return little_endian_read_16(event, 9);
    }
    /**
     * @brief Get field channel_mode from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return channel_mode
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_signaling_media_codec_sbc_configuration_get_channel_mode(const uint8_t * event){
        return event[11];
    }
    /**
     * @brief Get field num_channels from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return num_channels
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_signaling_media_codec_sbc_configuration_get_num_channels(const uint8_t * event){
        return event[12];
    }
    /**
     * @brief Get field block_length from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return block_length
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_signaling_media_codec_sbc_configuration_get_block_length(const uint8_t * event){
        return event[13];
    }
    /**
     * @brief Get field subbands from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return subbands
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_signaling_media_codec_sbc_configuration_get_subbands(const uint8_t * event){
        return event[14];
    }
    /**
     * @brief Get field allocation_method from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return allocation_method
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_signaling_media_codec_sbc_configuration_get_allocation_method(const uint8_t * event){
        return event[15];
    }
    /**
     * @brief Get field min_bitpool_value from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return min_bitpool_value
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_signaling_media_codec_sbc_configuration_get_min_bitpool_value(const uint8_t * event){
        return event[16];
    }
    /**
     * @brief Get field max_bitpool_value from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION
     * @param event packet
     * @return max_bitpool_value
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_signaling_media_codec_sbc_configuration_get_max_bitpool_value(const uint8_t * event){
        return event[17];
    }
    
    /**
     * @brief Get field a2dp_cid from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CONFIGURATION
     * @param event packet
     * @return a2dp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t a2dp_subevent_signaling_media_codec_other_configuration_get_a2dp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field int_seid from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CONFIGURATION
     * @param event packet
     * @return int_seid
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_signaling_media_codec_other_configuration_get_int_seid(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field acp_seid from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CONFIGURATION
     * @param event packet
     * @return acp_seid
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_signaling_media_codec_other_configuration_get_acp_seid(const uint8_t * event){
        return event[6];
    }
    /**
     * @brief Get field reconfigure from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CONFIGURATION
     * @param event packet
     * @return reconfigure
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_signaling_media_codec_other_configuration_get_reconfigure(const uint8_t * event){
        return event[7];
    }
    /**
     * @brief Get field media_type from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CONFIGURATION
     * @param event packet
     * @return media_type
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_signaling_media_codec_other_configuration_get_media_type(const uint8_t * event){
        return event[8];
    }
    /**
     * @brief Get field media_codec_type from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CONFIGURATION
     * @param event packet
     * @return media_codec_type
     * @note: btstack_type 2
     */
    static inline uint16_t a2dp_subevent_signaling_media_codec_other_configuration_get_media_codec_type(const uint8_t * event){
        return little_endian_read_16(event, 9);
    }
    /**
     * @brief Get field media_codec_information_len from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CONFIGURATION
     * @param event packet
     * @return media_codec_information_len
     * @note: btstack_type L
     */
    static inline int a2dp_subevent_signaling_media_codec_other_configuration_get_media_codec_information_len(const uint8_t * event){
        return little_endian_read_16(event, 11);
    }
    /**
     * @brief Get field media_codec_information from event A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_OTHER_CONFIGURATION
     * @param event packet
     * @return media_codec_information
     * @note: btstack_type V
     */
    static inline const uint8_t * a2dp_subevent_signaling_media_codec_other_configuration_get_media_codec_information(const uint8_t * event){
        return &event[13];
    }
    
    /**
     * @brief Get field a2dp_cid from event A2DP_SUBEVENT_STREAM_ESTABLISHED
     * @param event packet
     * @return a2dp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t a2dp_subevent_stream_established_get_a2dp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field local_seid from event A2DP_SUBEVENT_STREAM_ESTABLISHED
     * @param event packet
     * @return local_seid
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_stream_established_get_local_seid(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field remote_seid from event A2DP_SUBEVENT_STREAM_ESTABLISHED
     * @param event packet
     * @return remote_seid
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_stream_established_get_remote_seid(const uint8_t * event){
        return event[6];
    }
    /**
     * @brief Get field status from event A2DP_SUBEVENT_STREAM_ESTABLISHED
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_stream_established_get_status(const uint8_t * event){
        return event[7];
    }
    
    /**
     * @brief Get field a2dp_cid from event A2DP_SUBEVENT_STREAM_STARTED
     * @param event packet
     * @return a2dp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t a2dp_subevent_stream_started_get_a2dp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field local_seid from event A2DP_SUBEVENT_STREAM_STARTED
     * @param event packet
     * @return local_seid
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_stream_started_get_local_seid(const uint8_t * event){
        return event[5];
    }
    
    /**
     * @brief Get field a2dp_cid from event A2DP_SUBEVENT_STREAM_SUSPENDED
     * @param event packet
     * @return a2dp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t a2dp_subevent_stream_suspended_get_a2dp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field local_seid from event A2DP_SUBEVENT_STREAM_SUSPENDED
     * @param event packet
     * @return local_seid
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_stream_suspended_get_local_seid(const uint8_t * event){
        return event[5];
    }
    
    /**
     * @brief Get field a2dp_cid from event A2DP_SUBEVENT_STREAM_RELEASED
     * @param event packet
     * @return a2dp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t a2dp_subevent_stream_released_get_a2dp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field local_seid from event A2DP_SUBEVENT_STREAM_RELEASED
     * @param event packet
     * @return local_seid
     * @note: btstack_type 1
     */
    static inline uint8_t a2dp_subevent_stream_released_get_local_seid(const uint8_t * event){
        return event[5];
    }
    
    /**
     * @brief Get field status from event AVRCP_SUBEVENT_CONNECTION_ESTABLISHED
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_connection_established_get_status(const uint8_t * event){
        return event[3];
    }
    /**
     * @brief Get field bd_addr from event AVRCP_SUBEVENT_CONNECTION_ESTABLISHED
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void avrcp_subevent_connection_established_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[4], bd_addr);    
    }
    /**
     * @brief Get field avrcp_cid from event AVRCP_SUBEVENT_CONNECTION_ESTABLISHED
     * @param event packet
     * @return avrcp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avrcp_subevent_connection_established_get_avrcp_cid(const uint8_t * event){
        return little_endian_read_16(event, 10);
    }
    
    /**
     * @brief Get field avrcp_cid from event AVRCP_SUBEVENT_CONNECTION_RELEASED
     * @param event packet
     * @return avrcp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avrcp_subevent_connection_released_get_avrcp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    
    /**
     * @brief Get field avrcp_cid from event AVRCP_SUBEVENT_NOW_PLAYING_INFO
     * @param event packet
     * @return avrcp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avrcp_subevent_now_playing_info_get_avrcp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field command_type from event AVRCP_SUBEVENT_NOW_PLAYING_INFO
     * @param event packet
     * @return command_type
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_now_playing_info_get_command_type(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field track from event AVRCP_SUBEVENT_NOW_PLAYING_INFO
     * @param event packet
     * @return track
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_now_playing_info_get_track(const uint8_t * event){
        return event[6];
    }
    /**
     * @brief Get field total_tracks from event AVRCP_SUBEVENT_NOW_PLAYING_INFO
     * @param event packet
     * @return total_tracks
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_now_playing_info_get_total_tracks(const uint8_t * event){
        return event[7];
    }
    /**
     * @brief Get field song_length from event AVRCP_SUBEVENT_NOW_PLAYING_INFO
     * @param event packet
     * @return song_length
     * @note: btstack_type 4
     */
    static inline uint32_t avrcp_subevent_now_playing_info_get_song_length(const uint8_t * event){
        return little_endian_read_32(event, 8);
    }
    /**
     * @brief Get field title_len from event AVRCP_SUBEVENT_NOW_PLAYING_INFO
     * @param event packet
     * @return title_len
     * @note: btstack_type J
     */
    static inline int avrcp_subevent_now_playing_info_get_title_len(const uint8_t * event){
        return event[12];
    }
    /**
     * @brief Get field title from event AVRCP_SUBEVENT_NOW_PLAYING_INFO
     * @param event packet
     * @return title
     * @note: btstack_type V
     */
    static inline const uint8_t * avrcp_subevent_now_playing_info_get_title(const uint8_t * event){
        return &event[13];
    }
    /**
     * @brief Get field artist_len from event AVRCP_SUBEVENT_NOW_PLAYING_INFO
     * @param event packet
     * @return artist_len
     * @note: btstack_type J
     */
    static inline int avrcp_subevent_now_playing_info_get_artist_len(const uint8_t * event){
        return event[13 + event[12]];
    }
    /**
     * @brief Get field artist from event AVRCP_SUBEVENT_NOW_PLAYING_INFO
     * @param event packet
     * @return artist
     * @note: btstack_type V
     */
    static inline const uint8_t * avrcp_subevent_now_playing_info_get_artist(const uint8_t * event){
        return &event[13 + event[12] + 1];
    }
    /**
     * @brief Get field album_len from event AVRCP_SUBEVENT_NOW_PLAYING_INFO
     * @param event packet
     * @return album_len
     * @note: btstack_type J
     */
    static inline int avrcp_subevent_now_playing_info_get_album_len(const uint8_t * event){
        return event[13 + event[12] + 1 + event[13 + event[12]]];
    }
    /**
     * @brief Get field album from event AVRCP_SUBEVENT_NOW_PLAYING_INFO
     * @param event packet
     * @return album
     * @note: btstack_type V
     */
    static inline const uint8_t * avrcp_subevent_now_playing_info_get_album(const uint8_t * event){
        return &event[13 + event[12] + 1 + event[13 + event[12]] + 1];
    }
    /**
     * @brief Get field genre_len from event AVRCP_SUBEVENT_NOW_PLAYING_INFO
     * @param event packet
     * @return genre_len
     * @note: btstack_type J
     */
    static inline int avrcp_subevent_now_playing_info_get_genre_len(const uint8_t * event){
        return event[13 + event[12] + 1 + event[13 + event[12]] + 1 + event[13 + event[12] + 1 + event[13 + event[12]]]];
    }
    /**
     * @brief Get field genre from event AVRCP_SUBEVENT_NOW_PLAYING_INFO
     * @param event packet
     * @return genre
     * @note: btstack_type V
     */
    static inline const uint8_t * avrcp_subevent_now_playing_info_get_genre(const uint8_t * event){
        return &event[13 + event[12] + 1 + event[13 + event[12]] + 1 + event[13 + event[12] + 1 + event[13 + event[12]]] + 1];
    }
    
    /**
     * @brief Get field avrcp_cid from event AVRCP_SUBEVENT_SHUFFLE_AND_REPEAT_MODE
     * @param event packet
     * @return avrcp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avrcp_subevent_shuffle_and_repeat_mode_get_avrcp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field command_type from event AVRCP_SUBEVENT_SHUFFLE_AND_REPEAT_MODE
     * @param event packet
     * @return command_type
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_shuffle_and_repeat_mode_get_command_type(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field repeat_mode from event AVRCP_SUBEVENT_SHUFFLE_AND_REPEAT_MODE
     * @param event packet
     * @return repeat_mode
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_shuffle_and_repeat_mode_get_repeat_mode(const uint8_t * event){
        return event[6];
    }
    /**
     * @brief Get field shuffle_mode from event AVRCP_SUBEVENT_SHUFFLE_AND_REPEAT_MODE
     * @param event packet
     * @return shuffle_mode
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_shuffle_and_repeat_mode_get_shuffle_mode(const uint8_t * event){
        return event[7];
    }
    
    /**
     * @brief Get field avrcp_cid from event AVRCP_SUBEVENT_PLAY_STATUS
     * @param event packet
     * @return avrcp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avrcp_subevent_play_status_get_avrcp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field command_type from event AVRCP_SUBEVENT_PLAY_STATUS
     * @param event packet
     * @return command_type
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_play_status_get_command_type(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field song_length from event AVRCP_SUBEVENT_PLAY_STATUS
     * @param event packet
     * @return song_length
     * @note: btstack_type 4
     */
    static inline uint32_t avrcp_subevent_play_status_get_song_length(const uint8_t * event){
        return little_endian_read_32(event, 6);
    }
    /**
     * @brief Get field song_position from event AVRCP_SUBEVENT_PLAY_STATUS
     * @param event packet
     * @return song_position
     * @note: btstack_type 4
     */
    static inline uint32_t avrcp_subevent_play_status_get_song_position(const uint8_t * event){
        return little_endian_read_32(event, 10);
    }
    /**
     * @brief Get field play_status from event AVRCP_SUBEVENT_PLAY_STATUS
     * @param event packet
     * @return play_status
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_play_status_get_play_status(const uint8_t * event){
        return event[14];
    }
    
    /**
     * @brief Get field avrcp_cid from event AVRCP_SUBEVENT_NOTIFICATION_PLAYBACK_STATUS_CHANGED
     * @param event packet
     * @return avrcp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avrcp_subevent_notification_playback_status_changed_get_avrcp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field command_type from event AVRCP_SUBEVENT_NOTIFICATION_PLAYBACK_STATUS_CHANGED
     * @param event packet
     * @return command_type
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_notification_playback_status_changed_get_command_type(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field play_status from event AVRCP_SUBEVENT_NOTIFICATION_PLAYBACK_STATUS_CHANGED
     * @param event packet
     * @return play_status
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_notification_playback_status_changed_get_play_status(const uint8_t * event){
        return event[6];
    }
    
    /**
     * @brief Get field avrcp_cid from event AVRCP_SUBEVENT_NOTIFICATION_TRACK_CHANGED
     * @param event packet
     * @return avrcp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avrcp_subevent_notification_track_changed_get_avrcp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field command_type from event AVRCP_SUBEVENT_NOTIFICATION_TRACK_CHANGED
     * @param event packet
     * @return command_type
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_notification_track_changed_get_command_type(const uint8_t * event){
        return event[5];
    }
    
    /**
     * @brief Get field avrcp_cid from event AVRCP_SUBEVENT_NOTIFICATION_NOW_PLAYING_CONTENT_CHANGED
     * @param event packet
     * @return avrcp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avrcp_subevent_notification_now_playing_content_changed_get_avrcp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field command_type from event AVRCP_SUBEVENT_NOTIFICATION_NOW_PLAYING_CONTENT_CHANGED
     * @param event packet
     * @return command_type
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_notification_now_playing_content_changed_get_command_type(const uint8_t * event){
        return event[5];
    }
    
    /**
     * @brief Get field avrcp_cid from event AVRCP_SUBEVENT_NOTIFICATION_AVAILABLE_PLAYERS_CHANGED
     * @param event packet
     * @return avrcp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avrcp_subevent_notification_available_players_changed_get_avrcp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field command_type from event AVRCP_SUBEVENT_NOTIFICATION_AVAILABLE_PLAYERS_CHANGED
     * @param event packet
     * @return command_type
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_notification_available_players_changed_get_command_type(const uint8_t * event){
        return event[5];
    }
    
    /**
     * @brief Get field avrcp_cid from event AVRCP_SUBEVENT_NOTIFICATION_VOLUME_CHANGED
     * @param event packet
     * @return avrcp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avrcp_subevent_notification_volume_changed_get_avrcp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field command_type from event AVRCP_SUBEVENT_NOTIFICATION_VOLUME_CHANGED
     * @param event packet
     * @return command_type
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_notification_volume_changed_get_command_type(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field absolute_volume from event AVRCP_SUBEVENT_NOTIFICATION_VOLUME_CHANGED
     * @param event packet
     * @return absolute_volume
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_notification_volume_changed_get_absolute_volume(const uint8_t * event){
        return event[6];
    }
    
    /**
     * @brief Get field avrcp_cid from event AVRCP_SUBEVENT_SET_ABSOLUTE_VOLUME_RESPONSE
     * @param event packet
     * @return avrcp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avrcp_subevent_set_absolute_volume_response_get_avrcp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field command_type from event AVRCP_SUBEVENT_SET_ABSOLUTE_VOLUME_RESPONSE
     * @param event packet
     * @return command_type
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_set_absolute_volume_response_get_command_type(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field absolute_volume from event AVRCP_SUBEVENT_SET_ABSOLUTE_VOLUME_RESPONSE
     * @param event packet
     * @return absolute_volume
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_set_absolute_volume_response_get_absolute_volume(const uint8_t * event){
        return event[6];
    }
    
    /**
     * @brief Get field avrcp_cid from event AVRCP_SUBEVENT_ENABLE_NOTIFICATION_COMPLETE
     * @param event packet
     * @return avrcp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avrcp_subevent_enable_notification_complete_get_avrcp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field command_type from event AVRCP_SUBEVENT_ENABLE_NOTIFICATION_COMPLETE
     * @param event packet
     * @return command_type
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_enable_notification_complete_get_command_type(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field notification_id from event AVRCP_SUBEVENT_ENABLE_NOTIFICATION_COMPLETE
     * @param event packet
     * @return notification_id
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_enable_notification_complete_get_notification_id(const uint8_t * event){
        return event[6];
    }
    
    /**
     * @brief Get field avrcp_cid from event AVRCP_SUBEVENT_OPERATION_START
     * @param event packet
     * @return avrcp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avrcp_subevent_operation_start_get_avrcp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field command_type from event AVRCP_SUBEVENT_OPERATION_START
     * @param event packet
     * @return command_type
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_operation_start_get_command_type(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field operation_id from event AVRCP_SUBEVENT_OPERATION_START
     * @param event packet
     * @return operation_id
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_operation_start_get_operation_id(const uint8_t * event){
        return event[6];
    }
    
    /**
     * @brief Get field avrcp_cid from event AVRCP_SUBEVENT_OPERATION_COMPLETE
     * @param event packet
     * @return avrcp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avrcp_subevent_operation_complete_get_avrcp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field command_type from event AVRCP_SUBEVENT_OPERATION_COMPLETE
     * @param event packet
     * @return command_type
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_operation_complete_get_command_type(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field operation_id from event AVRCP_SUBEVENT_OPERATION_COMPLETE
     * @param event packet
     * @return operation_id
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_operation_complete_get_operation_id(const uint8_t * event){
        return event[6];
    }
    
    /**
     * @brief Get field avrcp_cid from event AVRCP_SUBEVENT_PLAYER_APPLICATION_VALUE_RESPONSE
     * @param event packet
     * @return avrcp_cid
     * @note: btstack_type 2
     */
    static inline uint16_t avrcp_subevent_player_application_value_response_get_avrcp_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field command_type from event AVRCP_SUBEVENT_PLAYER_APPLICATION_VALUE_RESPONSE
     * @param event packet
     * @return command_type
     * @note: btstack_type 1
     */
    static inline uint8_t avrcp_subevent_player_application_value_response_get_command_type(const uint8_t * event){
        return event[5];
    }
    
    /**
     * @brief Get field goep_cid from event GOEP_SUBEVENT_CONNECTION_OPENED
     * @param event packet
     * @return goep_cid
     * @note: btstack_type 2
     */
    static inline uint16_t goep_subevent_connection_opened_get_goep_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field status from event GOEP_SUBEVENT_CONNECTION_OPENED
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t goep_subevent_connection_opened_get_status(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field bd_addr from event GOEP_SUBEVENT_CONNECTION_OPENED
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void goep_subevent_connection_opened_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[6], bd_addr);    
    }
    /**
     * @brief Get field con_handle from event GOEP_SUBEVENT_CONNECTION_OPENED
     * @param event packet
     * @return con_handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t goep_subevent_connection_opened_get_con_handle(const uint8_t * event){
        return little_endian_read_16(event, 12);
    }
    /**
     * @brief Get field incoming from event GOEP_SUBEVENT_CONNECTION_OPENED
     * @param event packet
     * @return incoming
     * @note: btstack_type 1
     */
    static inline uint8_t goep_subevent_connection_opened_get_incoming(const uint8_t * event){
        return event[14];
    }
    
    /**
     * @brief Get field goep_cid from event GOEP_SUBEVENT_CONNECTION_CLOSED
     * @param event packet
     * @return goep_cid
     * @note: btstack_type 2
     */
    static inline uint16_t goep_subevent_connection_closed_get_goep_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    
    /**
     * @brief Get field goep_cid from event GOEP_SUBEVENT_CAN_SEND_NOW
     * @param event packet
     * @return goep_cid
     * @note: btstack_type 2
     */
    static inline uint16_t goep_subevent_can_send_now_get_goep_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    
    /**
     * @brief Get field pbap_cid from event PBAP_SUBEVENT_CONNECTION_OPENED
     * @param event packet
     * @return pbap_cid
     * @note: btstack_type 2
     */
    static inline uint16_t pbap_subevent_connection_opened_get_pbap_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field status from event PBAP_SUBEVENT_CONNECTION_OPENED
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t pbap_subevent_connection_opened_get_status(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field bd_addr from event PBAP_SUBEVENT_CONNECTION_OPENED
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void pbap_subevent_connection_opened_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[6], bd_addr);    
    }
    /**
     * @brief Get field con_handle from event PBAP_SUBEVENT_CONNECTION_OPENED
     * @param event packet
     * @return con_handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t pbap_subevent_connection_opened_get_con_handle(const uint8_t * event){
        return little_endian_read_16(event, 12);
    }
    /**
     * @brief Get field incoming from event PBAP_SUBEVENT_CONNECTION_OPENED
     * @param event packet
     * @return incoming
     * @note: btstack_type 1
     */
    static inline uint8_t pbap_subevent_connection_opened_get_incoming(const uint8_t * event){
        return event[14];
    }
    
    /**
     * @brief Get field goep_cid from event PBAP_SUBEVENT_CONNECTION_CLOSED
     * @param event packet
     * @return goep_cid
     * @note: btstack_type 2
     */
    static inline uint16_t pbap_subevent_connection_closed_get_goep_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    
    /**
     * @brief Get field goep_cid from event PBAP_SUBEVENT_OPERATION_COMPLETED
     * @param event packet
     * @return goep_cid
     * @note: btstack_type 2
     */
    static inline uint16_t pbap_subevent_operation_completed_get_goep_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field status from event PBAP_SUBEVENT_OPERATION_COMPLETED
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t pbap_subevent_operation_completed_get_status(const uint8_t * event){
        return event[5];
    }
    
    /**
     * @brief Get field hid_cid from event HID_SUBEVENT_CONNECTION_OPENED
     * @param event packet
     * @return hid_cid
     * @note: btstack_type 2
     */
    static inline uint16_t hid_subevent_connection_opened_get_hid_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    /**
     * @brief Get field status from event HID_SUBEVENT_CONNECTION_OPENED
     * @param event packet
     * @return status
     * @note: btstack_type 1
     */
    static inline uint8_t hid_subevent_connection_opened_get_status(const uint8_t * event){
        return event[5];
    }
    /**
     * @brief Get field bd_addr from event HID_SUBEVENT_CONNECTION_OPENED
     * @param event packet
     * @param Pointer to storage for bd_addr
     * @note: btstack_type B
     */
    static inline void hid_subevent_connection_opened_get_bd_addr(const uint8_t * event, bd_addr_t bd_addr){
        reverse_bd_addr(&event[6], bd_addr);    
    }
    /**
     * @brief Get field con_handle from event HID_SUBEVENT_CONNECTION_OPENED
     * @param event packet
     * @return con_handle
     * @note: btstack_type H
     */
    static inline hci_con_handle_t hid_subevent_connection_opened_get_con_handle(const uint8_t * event){
        return little_endian_read_16(event, 12);
    }
    /**
     * @brief Get field incoming from event HID_SUBEVENT_CONNECTION_OPENED
     * @param event packet
     * @return incoming
     * @note: btstack_type 1
     */
    static inline uint8_t hid_subevent_connection_opened_get_incoming(const uint8_t * event){
        return event[14];
    }
    
    /**
     * @brief Get field hid_cid from event HID_SUBEVENT_CONNECTION_CLOSED
     * @param event packet
     * @return hid_cid
     * @note: btstack_type 2
     */
    static inline uint16_t hid_subevent_connection_closed_get_hid_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    
    /**
     * @brief Get field hid_cid from event HID_SUBEVENT_CAN_SEND_NOW
     * @param event packet
     * @return hid_cid
     * @note: btstack_type 2
     */
    static inline uint16_t hid_subevent_can_send_now_get_hid_cid(const uint8_t * event){
        return little_endian_read_16(event, 3);
    }
    
    
    


## BTstack Memory Management API {#sec:btMemoryAPIAppendix}

    
    /**
     * @brief Initializes BTstack memory pools.
     */
    void btstack_memory_init(void);
    


## BTstack Linked List API {#sec:btListAPIAppendix}

    	
    typedef struct btstack_linked_item {
        struct btstack_linked_item *next; // <-- next element in list, or NULL
    } btstack_linked_item_t;
    
    typedef btstack_linked_item_t * btstack_linked_list_t;
    
    typedef struct {
    	int advance_on_next;
        btstack_linked_item_t * prev;	// points to the item before the current one
        btstack_linked_item_t * curr;	// points to the current item (to detect item removal)
    } btstack_linked_list_iterator_t;
    
    
    // test if list is empty
    int                     btstack_linked_list_empty(btstack_linked_list_t * list);
    // add item to list as first element
    void                    btstack_linked_list_add(btstack_linked_list_t * list, btstack_linked_item_t *item);       
    // add item to list as last element
    void                    btstack_linked_list_add_tail(btstack_linked_list_t * list, btstack_linked_item_t *item);
    // pop (get + remove) first element
    btstack_linked_item_t * btstack_linked_list_pop(btstack_linked_list_t * list);
    // remove item from list
    int                     btstack_linked_list_remove(btstack_linked_list_t * list, btstack_linked_item_t *item); 
    // get first element
    btstack_linked_item_t * btstack_linked_list_get_first_item(btstack_linked_list_t * list);
    // find the last item in the list
    btstack_linked_item_t * btstack_linked_list_get_last_item(btstack_linked_list_t * list);   
    
    /**
     * @brief Counts number of items in list
     * @returns number of items in list
     */
    int btstack_linked_list_count(btstack_linked_list_t * list);
    
    //
    // iterator for linked lists. allows to remove current element.
    // robust against removal of current element by btstack_linked_list_remove.
    //
    void            btstack_linked_list_iterator_init(btstack_linked_list_iterator_t * it, btstack_linked_list_t * list);
    int             btstack_linked_list_iterator_has_next(btstack_linked_list_iterator_t * it);
    btstack_linked_item_t * btstack_linked_list_iterator_next(btstack_linked_list_iterator_t * it);
    void            btstack_linked_list_iterator_remove(btstack_linked_list_iterator_t * it);
    


## Run Loop API {#sec:runLoopAPIAppendix}

    
    /**
     * @brief Init main run loop. Must be called before any other run loop call.
     *  
     * Use btstack_run_loop_$(btstack_run_loop_TYPE)_get_instance() from btstack_run_loop_$(btstack_run_loop_TYPE).h to get instance 
     */
    void btstack_run_loop_init(const btstack_run_loop_t * run_loop);
    
    /**
     * @brief Set timer based on current time in milliseconds.
     */
    void btstack_run_loop_set_timer(btstack_timer_source_t * ts, uint32_t timeout_in_ms);
    
    /**
     * @brief Set callback that will be executed when timer expires.
     */
    void btstack_run_loop_set_timer_handler(btstack_timer_source_t * ts, void (*process)(btstack_timer_source_t *_ts));
    
    /**
     * @brief Set context for this timer
     */
    void btstack_run_loop_set_timer_context(btstack_timer_source_t * ts, void * context);
    
    /**
     * @brief Get context for this timer
     */
    void * btstack_run_loop_get_timer_context(btstack_timer_source_t * ts);
    
    /**
     * @brief Add timer source.
     */
    void btstack_run_loop_add_timer(btstack_timer_source_t * timer); 
    
    /**
     * @brief Remove timer source.
     */
    int  btstack_run_loop_remove_timer(btstack_timer_source_t * timer);
    
    /**
     * @brief Get current time in ms
     * @note 32-bit ms counter will overflow after approx. 52 days
     */
    uint32_t btstack_run_loop_get_time_ms(void);
    
    /**
     * @brief Set data source callback.
     */
    void btstack_run_loop_set_data_source_handler(btstack_data_source_t * data_source, void (*process)(btstack_data_source_t *_ds, btstack_data_source_callback_type_t callback_type));
    
    /**
     * @brief Set data source file descriptor. 
     * @param data_source
     * @param fd file descriptor
     * @note No effect if port doensn't have file descriptors
     */
    void btstack_run_loop_set_data_source_fd(btstack_data_source_t * data_source, int fd);
    
    /**
     * @brief Get data source file descriptor. 
     * @param data_source
     */
    int btstack_run_loop_get_data_source_fd(btstack_data_source_t * data_source);
    
    /**
     * @brief Enable callbacks for a data source
     * @param data_source to remove
     * @param callback types to enable
     */
    void btstack_run_loop_enable_data_source_callbacks(btstack_data_source_t * data_source, uint16_t callbacks);
    
    /**
     * @brief Enable callbacks for a data source
     * @param data_source to remove
     * @param callback types to disable
     */
    void btstack_run_loop_disable_data_source_callbacks(btstack_data_source_t * data_source, uint16_t callbacks);
    
    /**
     * @brief Add data source to run loop
     * @param data_source to add
     */
    void btstack_run_loop_add_data_source(btstack_data_source_t * data_source);
    
    /**
     * @brief Remove data source from run loop
     * @param data_source to remove
     */
    int btstack_run_loop_remove_data_source(btstack_data_source_t * data_source);
    
    /**
     * @brief Execute configured run loop. This function does not return.
     */
    void btstack_run_loop_execute(void);
    


## Common Utils API {#sec:btUtilAPIAppendix}

    
    /**
     * @brief Minimum function for uint32_t
     * @param a
     * @param b
     * @return value
     */
    uint32_t btstack_min(uint32_t a, uint32_t b);
    
    /**
     * @brief Maximum function for uint32_t
     * @param a
     * @param b
     * @return value
     */
    uint32_t btstack_max(uint32_t a, uint32_t b);
    
    	
    /** 
     * @brief Read 16/24/32 bit little endian value from buffer
     * @param buffer
     * @param position in buffer
     * @return value
     */
    uint16_t little_endian_read_16(const uint8_t * buffer, int position);
    uint32_t little_endian_read_24(const uint8_t * buffer, int position);
    uint32_t little_endian_read_32(const uint8_t * buffer, int position);
    
    /** 
     * @brief Write 16/32 bit little endian value into buffer
     * @param buffer
     * @param position in buffer
     * @param value
     */
    void little_endian_store_16(uint8_t *buffer, uint16_t position, uint16_t value);
    void little_endian_store_32(uint8_t *buffer, uint16_t position, uint32_t value);
    
    /** 
     * @brief Read 16/24/32 bit big endian value from buffer
     * @param buffer
     * @param position in buffer
     * @return value
     */
    uint32_t big_endian_read_16( const uint8_t * buffer, int pos);
    uint32_t big_endian_read_24( const uint8_t * buffer, int pos);
    uint32_t big_endian_read_32( const uint8_t * buffer, int pos);
    
    /** 
     * @brief Write 16/32 bit big endian value into buffer
     * @param buffer
     * @param position in buffer
     * @param value
     */
    void big_endian_store_16(uint8_t *buffer, uint16_t pos, uint16_t value);
    void big_endian_store_24(uint8_t *buffer, uint16_t pos, uint32_t value);
    void big_endian_store_32(uint8_t *buffer, uint16_t pos, uint32_t value);
    
    
    /**
     * @brief Swap bytes in 16 bit integer
     */
    static inline uint16_t btstack_flip_16(uint16_t value){
        return (uint16_t)((value & 0xff) << 8) | (value >> 8);
    }
    
    /** 
     * @brief Check for big endian system
     * @returns 1 if on big endian
     */
    static inline int btstack_is_big_endian(void){
    	uint16_t sample = 0x0100;
    	return *(uint8_t*) &sample;
    }
    
    /** 
     * @brief Check for little endian system
     * @returns 1 if on little endian
     */
    static inline int btstack_is_little_endian(void){
    	uint16_t sample = 0x0001;
    	return *(uint8_t*) &sample;
    }
    
    /**
     * @brief Copy from source to destination and reverse byte order
     * @param src
     * @param dest
     * @param len
     */
    void reverse_bytes  (const uint8_t *src, uint8_t * dest, int len);
    
    /**
     * @brief Wrapper around reverse_bytes for common buffer sizes
     * @param src
     * @param dest
     */
    void reverse_24 (const uint8_t *src, uint8_t * dest);
    void reverse_48 (const uint8_t *src, uint8_t * dest);
    void reverse_56 (const uint8_t *src, uint8_t * dest);
    void reverse_64 (const uint8_t *src, uint8_t * dest);
    void reverse_128(const uint8_t *src, uint8_t * dest);
    void reverse_256(const uint8_t *src, uint8_t * dest);
    
    void reverse_bd_addr(const bd_addr_t src, bd_addr_t dest);
    
    /** 
     * @brief ASCII character for 4-bit nibble
     * @return character
     */
    char char_for_nibble(int nibble);
    
    /**
     * @brif 4-bit nibble from ASCII character
     * @return value
     */
    int nibble_for_char(char c);
    
    /**
     * @brief Compare two Bluetooth addresses
     * @param a
     * @param b
     * @return true if equal
     */
    int bd_addr_cmp(const bd_addr_t a, const bd_addr_t b);
    
    /**
     * @brief Copy Bluetooth address
     * @param dest
     * @param src
     */
    void bd_addr_copy(bd_addr_t dest, const bd_addr_t src);
    
    /**
     * @brief Use printf to write hexdump as single line of data
     */
    void printf_hexdump(const void *data, int size);
    
    /**
     * @brief Create human readable representation for UUID128
     * @note uses fixed global buffer
     * @return pointer to UUID128 string
     */
    char * uuid128_to_str(const uint8_t * uuid);
    
    /**
     * @brief Create human readable represenationt of Bluetooth address
     * @note uses fixed global buffer
     * @return pointer to Bluetooth address string
     */
    char * bd_addr_to_str(const bd_addr_t addr);
    
    /** 
     * @brief Parse Bluetooth address
     * @param address_string
     * @param buffer for parsed address
     * @return 1 if string was parsed successfully
     */
    int sscanf_bd_addr(const char * addr_string, bd_addr_t addr);
    
    /**
     * @brief Constructs UUID128 from 16 or 32 bit UUID using Bluetooth base UUID
     * @param uuid128 output buffer
     * @param short_uuid
     */
    void uuid_add_bluetooth_prefix(uint8_t * uuid128, uint32_t short_uuid);
    
    /**
     * @brief Checks if UUID128 has Bluetooth base UUID prefix
     * @param uui128 to test
     * @return 1 if it can be expressed as UUID32
     */
    int  uuid_has_bluetooth_prefix(const uint8_t * uuid128);
    
    /**
     * @brief Parse unsigned number 
     * @param str to parse
     * @return value
     */
    uint32_t btstack_atoi(const char *str);
    


## GAP API {#sec:gapAPIAppendix}

    
    // Classic + LE
    
    /**
     * @brief Disconnect connection with handle
     * @param handle
     */
    uint8_t gap_disconnect(hci_con_handle_t handle);
    
    /**
     * @brief Get connection type
     * @param con_handle
     * @result connection_type
     */
    gap_connection_type_t gap_get_connection_type(hci_con_handle_t connection_handle);
    
    // Classic
    
    /** 
     * @brief Sets local name.
     * @note has to be done before stack starts up
     * @param name is not copied, make sure memory is accessible during stack startup
     */
    void gap_set_local_name(const char * local_name);
    
    /**
     * @brief Set Extended Inquiry Response data
     * @param eir_data size 240 bytes, is not copied make sure memory is accessible during stack startup
     * @note has to be done before stack starts up
     */
    void gap_set_extended_inquiry_response(const uint8_t * data); 
    
    /**
     * @brief Set class of device that will be set during Bluetooth init.
     * @note has to be done before stack starts up
     */
    void gap_set_class_of_device(uint32_t class_of_device);
    
    /**
     * @brief Enable/disable bonding. Default is enabled.
     * @param enabled
     */
    void gap_set_bondable_mode(int enabled);
    
    /**  
     * @brief Get bondable mode.
     * @return 1 if bondable
     */
    int gap_get_bondable_mode(void);
    
    /* Configure Secure Simple Pairing */
    
    /**
     * @brief Enable will enable SSP during init.
     */
    void gap_ssp_set_enable(int enable);
    
    /**
     * @brief Set IO Capability. BTstack will return capability to SSP requests
     */
    void gap_ssp_set_io_capability(int ssp_io_capability);
    
    /**
     * @brief Set Authentication Requirements using during SSP
     */
    void gap_ssp_set_authentication_requirement(int authentication_requirement);
    
    /**
     * @brief If set, BTstack will confirm a numeric comparison and enter '000000' if requested.
     */
    void gap_ssp_set_auto_accept(int auto_accept);
    
    /**
     * @brief Start dedicated bonding with device. Disconnect after bonding.
     * @param device
     * @param request MITM protection
     * @return error, if max num acl connections active
     * @result GAP_DEDICATED_BONDING_COMPLETE
     */
    int gap_dedicated_bonding(bd_addr_t device, int mitm_protection_required);
    
    gap_security_level_t gap_security_level_for_link_key_type(link_key_type_t link_key_type);
    gap_security_level_t gap_security_level(hci_con_handle_t con_handle);
    
    void gap_request_security_level(hci_con_handle_t con_handle, gap_security_level_t level);
    
    int  gap_mitm_protection_required_for_security_level(gap_security_level_t level);
    
    // LE
    
    /**
     * @brief Set parameters for LE Scan
     */
    void gap_set_scan_parameters(uint8_t scan_type, uint16_t scan_interval, uint16_t scan_window);
    
    /**
     * @brief Start LE Scan 
     */
    void gap_start_scan(void);
    
    /**
     * @brief Stop LE Scan
     */
    void gap_stop_scan(void);
    
    /**
     * @brief Enable privacy by using random addresses
     * @param random_address_type to use (incl. OFF)
     */
    void gap_random_address_set_mode(gap_random_address_type_t random_address_type);
    
    /**
     * @brief Get privacy mode
     */
    gap_random_address_type_t gap_random_address_get_mode(void);
    
    /**
     * @brief Sets update period for random address
     * @param period_ms in ms
     */
     void gap_random_address_set_update_period(int period_ms);
    
    /** 
     * @brief Sets a fixed random address for advertising
     * @param addr
     * @note Sets random address mode to type off
     */
    void gap_random_address_set(bd_addr_t addr);
    
    /**
     * @brief Set Advertisement Data
     * @param advertising_data_length
     * @param advertising_data (max 31 octets)
     * @note data is not copied, pointer has to stay valid
     */
    void gap_advertisements_set_data(uint8_t advertising_data_length, uint8_t * advertising_data);
    
    /**
     * @brief Set Advertisement Paramters
     * @param adv_int_min
     * @param adv_int_max
     * @param adv_type
     * @param direct_address_type
     * @param direct_address
     * @param channel_map
     * @param filter_policy
     * @note own_address_type is used from gap_random_address_set_mode
     */
    void gap_advertisements_set_params(uint16_t adv_int_min, uint16_t adv_int_max, uint8_t adv_type,
    	uint8_t direct_address_typ, bd_addr_t direct_address, uint8_t channel_map, uint8_t filter_policy);
    
    /** 
     * @brief Enable/Disable Advertisements. OFF by default.
     * @param enabled
     */
    void gap_advertisements_enable(int enabled);
    
    /** 
     * @brief Set Scan Response Data
     *
     * @note For scan response data, scannable undirected advertising (ADV_SCAN_IND) need to be used
     *
     * @param advertising_data_length
     * @param advertising_data (max 31 octets)
     * @note data is not copied, pointer has to stay valid
     */
    void gap_scan_response_set_data(uint8_t scan_response_data_length, uint8_t * scan_response_data);
    
    /**
     * @brief Set connection parameters for outgoing connections
     * @param conn_interval_min (unit: 1.25ms), default: 10 ms
     * @param conn_interval_max (unit: 1.25ms), default: 30 ms
     * @param conn_latency, default: 4
     * @param supervision_timeout (unit: 10ms), default: 720 ms
     * @param min_ce_length (unit: 0.625ms), default: 10 ms
     * @param max_ce_length (unit: 0.625ms), default: 30 ms
     */
    
    void gap_set_connection_parameters(uint16_t conn_interval_min, uint16_t conn_interval_max,
    	uint16_t conn_latency, uint16_t supervision_timeout, uint16_t min_ce_length, uint16_t max_ce_length);
    
    /**
     * @brief Request an update of the connection parameter for a given LE connection
     * @param handle
     * @param conn_interval_min (unit: 1.25ms)
     * @param conn_interval_max (unit: 1.25ms)
     * @param conn_latency
     * @param supervision_timeout (unit: 10ms)
     * @returns 0 if ok
     */
    int gap_request_connection_parameter_update(hci_con_handle_t con_handle, uint16_t conn_interval_min,
    	uint16_t conn_interval_max, uint16_t conn_latency, uint16_t supervision_timeout);
    
    /**
     * @brief Updates the connection parameters for a given LE connection
     * @param handle
     * @param conn_interval_min (unit: 1.25ms)
     * @param conn_interval_max (unit: 1.25ms)
     * @param conn_latency
     * @param supervision_timeout (unit: 10ms)
     * @returns 0 if ok
     */
    int gap_update_connection_parameters(hci_con_handle_t con_handle, uint16_t conn_interval_min,
    	uint16_t conn_interval_max, uint16_t conn_latency, uint16_t supervision_timeout);
    
    /**
     * @brief Set accepted connection parameter range
     * @param range
     */
    void gap_get_connection_parameter_range(le_connection_parameter_range_t * range);
    
    /**
     * @brief Get accepted connection parameter range
     * @param range
     */
    void gap_set_connection_parameter_range(le_connection_parameter_range_t * range);
    
    /**
     * @brief Connect to remote LE device
     */
    uint8_t gap_connect(bd_addr_t addr, bd_addr_type_t addr_type);
    
    /**
     * @brief Cancel connection process initiated by gap_connect
     */
    uint8_t gap_connect_cancel(void);
    
    /**
     * @brief Auto Connection Establishment - Start Connecting to device
     * @param address_typ
     * @param address
     * @returns 0 if ok
     */
    int gap_auto_connection_start(bd_addr_type_t address_typ, bd_addr_t address);
    
    /**
     * @brief Auto Connection Establishment - Stop Connecting to device
     * @param address_typ
     * @param address
     * @returns 0 if ok
     */
    int gap_auto_connection_stop(bd_addr_type_t address_typ, bd_addr_t address);
    
    /**
     * @brief Auto Connection Establishment - Stop everything
     * @note  Convenience function to stop all active auto connection attempts
     */
    void gap_auto_connection_stop_all(void);
    
    // Classic
    
    /**
     * @brief Override page scan mode. Page scan mode enabled by l2cap when services are registered
     * @note Might be used to reduce power consumption while Bluetooth module stays powered but no (new)
     *       connections are expected
     */
    void gap_connectable_control(uint8_t enable);
    
    /**
     * @brief Allows to control if device is discoverable. OFF by default.
     */
    void gap_discoverable_control(uint8_t enable);
    
    /**
     * @brief Gets local address.
     */
    void gap_local_bd_addr(bd_addr_t address_buffer);
    
    /**
     * @brief Deletes link key for remote device with baseband address.
     * @param addr
     */
    void gap_drop_link_key_for_bd_addr(bd_addr_t addr);
    
    /** 
     * @brief Store link key for remote device with baseband address
     * @param addr
     * @param link_key
     * @param link_key_type
     */
    void gap_store_link_key_for_bd_addr(bd_addr_t addr, link_key_t link_key, link_key_type_t type);
    
    /**
     * @brief Start GAP Classic Inquiry
     * @param duration in 1.28s units
     * @return 0 if ok
     * @events: GAP_EVENT_INQUIRY_RESULT, GAP_EVENT_INQUIRY_COMPLETE
     */
    int gap_inquiry_start(uint8_t duration_in_1280ms_units);
    
    /**
     * @brief Stop GAP Classic Inquiry
     * @brief Stop GAP Classic Inquiry
     * @returns 0 if ok
     * @events: GAP_EVENT_INQUIRY_COMPLETE
     */
    int gap_inquiry_stop(void);
    
    /**
     * @brief Remote Name Request
     * @param addr
     * @param page_scan_repetition_mode
     * @param clock_offset only used when bit 15 is set - pass 0 if not known
     * @events: HCI_EVENT_REMOTE_NAME_REQUEST_COMPLETE
     */
    int gap_remote_name_request(bd_addr_t addr, uint8_t page_scan_repetition_mode, uint16_t clock_offset);
    
    /**
     * @brief Legacy Pairing Pin Code Response
     * @param addr
     * @param pin
     * @return 0 if ok
     */
    int gap_pin_code_response(bd_addr_t addr, const char * pin);
    
    /**
     * @brief Abort Legacy Pairing
     * @param addr
     * @param pin
     * @return 0 if ok
     */
    int gap_pin_code_negative(bd_addr_t addr);
    
    /**
     * @brief SSP Passkey Response
     * @param addr
     * @param passkey [0..999999]
     * @return 0 if ok
     */
    int gap_ssp_passkey_response(bd_addr_t addr, uint32_t passkey);
    
    /**
     * @brief Abort SSP Passkey Entry/Pairing
     * @param addr
     * @param pin
     * @return 0 if ok
     */
    int gap_ssp_passkey_negative(bd_addr_t addr);
    
    /**
     * @brief Accept SSP Numeric Comparison
     * @param addr
     * @param passkey
     * @return 0 if ok
     */
    int gap_ssp_confirmation_response(bd_addr_t addr);
    
    /**
     * @brief Abort SSP Numeric Comparison/Pairing
     * @param addr
     * @param pin
     * @return 0 if ok
     */
    int gap_ssp_confirmation_negative(bd_addr_t addr);
    
    
    
    // LE
    
    /**
     * @brief Get own addr type and address used for LE
     */
    void gap_le_get_own_address(uint8_t * addr_type, bd_addr_t addr);
    
    


## HCI API {#sec:hciAPIAppendix}

    
        
    // HCI init and configuration
    
    
    /**
     * @brief Set up HCI. Needs to be called before any other function.
     */
    void hci_init(const hci_transport_t *transport, const void *config);
    
    /**
     * @brief Configure Bluetooth chipset driver. Has to be called before power on, or right after receiving the local version information.
     */
    void hci_set_chipset(const btstack_chipset_t *chipset_driver);
    
    /**
     * @brief Configure Bluetooth hardware control. Has to be called before power on.
     */
    void hci_set_control(const btstack_control_t *hardware_control);
    
    /**
     * @brief Configure Bluetooth hardware control. Has to be called before power on.
     */
    void hci_set_link_key_db(btstack_link_key_db_t const * link_key_db);
    
    /**
     * @brief Set callback for Bluetooth Hardware Error
     */
    void hci_set_hardware_error_callback(void (*fn)(uint8_t error));
    
    /**
     * @brief Set Public BD ADDR - passed on to Bluetooth chipset during init if supported in bt_control_h
     */
    void hci_set_bd_addr(bd_addr_t addr);
    
    /** 
     * @brief Configure Voice Setting for use with SCO data in HSP/HFP
     */
    void hci_set_sco_voice_setting(uint16_t voice_setting);
    
    /**
     * @brief Get SCO Voice Setting
     * @return current voice setting
     */
    uint16_t hci_get_sco_voice_setting(void);
    
    /**
     * @brief Set inquiry mode: standard, with RSSI, with RSSI + Extended Inquiry Results. Has to be called before power on.
     * @param inquriy_mode see bluetooth_defines.h
     */
    void hci_set_inquiry_mode(inquiry_mode_t mode);
    
    /**
     * @brief Requests the change of BTstack power mode.
     */
    int  hci_power_control(HCI_POWER_MODE mode);
    
    /**
     * @brief Shutdown HCI
     */
    void hci_close(void);
    
    
    // Callback registration
    
    
    /**
     * @brief Add event packet handler. 
     */
    void hci_add_event_handler(btstack_packet_callback_registration_t * callback_handler);
    
    /**
     * @brief Registers a packet handler for ACL data. Used by L2CAP
     */
    void hci_register_acl_packet_handler(btstack_packet_handler_t handler);
    
    /**
     * @brief Registers a packet handler for SCO data. Used for HSP and HFP profiles.
     */
    void hci_register_sco_packet_handler(btstack_packet_handler_t handler);
    
    
    // Sending HCI Commands
    
    /** 
     * @brief Check if CMD packet can be sent to controller
     */
    int hci_can_send_command_packet_now(void);
    
    /**
     * @brief Creates and sends HCI command packets based on a template and a list of parameters. Will return error if outgoing data buffer is occupied. 
     */
    int hci_send_cmd(const hci_cmd_t *cmd, ...);
    
    
    // Sending SCO Packets
    
    /** @brief Get SCO packet length for current SCO Voice setting
     *  @note  Using SCO packets of the exact length is required for USB transfer
     *  @return Length of SCO packets in bytes (not audio frames) incl. 3 byte header
     */
    int hci_get_sco_packet_length(void);
    
    /**
     * @brief Request emission of HCI_EVENT_SCO_CAN_SEND_NOW as soon as possible
     * @note HCI_EVENT_SCO_CAN_SEND_NOW might be emitted during call to this function
     *       so packet handler should be ready to handle it
     */
    void hci_request_sco_can_send_now_event(void);
    
    /**
     * @brief Check HCI packet buffer and if SCO packet can be sent to controller
     */
    int hci_can_send_sco_packet_now(void);
    
    /**
     * @brief Check if SCO packet can be sent to controller
     */
    int hci_can_send_prepared_sco_packet_now(void);
    
    /**
     * @brief Send SCO packet prepared in HCI packet buffer
     */
    int hci_send_sco_packet_buffer(int size);
    
    
    // Outgoing packet buffer, also used for SCO packets
    // see hci_can_send_prepared_sco_packet_now amn hci_send_sco_packet_buffer
    
    /**
     * Reserves outgoing packet buffer.
     * @return 1 on success
     */
    int hci_reserve_packet_buffer(void);
    
    /**
     * Get pointer for outgoing packet buffer
     */
    uint8_t* hci_get_outgoing_packet_buffer(void);
    
    /**
     * Release outgoing packet buffer\
     * @note only called instead of hci_send_preparared
     */
    void hci_release_packet_buffer(void);
    
    


## HCI Logging API {#sec:hciTraceAPIAppendix}

    
    typedef enum {
        HCI_DUMP_BLUEZ = 0,
        HCI_DUMP_PACKETLOGGER,
        HCI_DUMP_STDOUT
    } hci_dump_format_t;
    
    /*
     * @brief 
     */
    void hci_dump_open(const char *filename, hci_dump_format_t format);
    
    /*
     * @brief 
     */
    void hci_dump_set_max_packets(int packets); // -1 for unlimited
    
    /*
     * @brief 
     */
    void hci_dump_packet(uint8_t packet_type, uint8_t in, uint8_t *packet, uint16_t len);
    
    /*
     * @brief 
     */
    void hci_dump_log(int log_level, const char * format, ...)
    #ifdef __GNUC__
    __attribute__ ((format (__printf__, 2, 3)));
    #endif
    ;
    
    /*
     * @brief 
     */
    void hci_dump_enable_log_level(int log_level, int enable);
    
    /*
     * @brief 
     */
    void hci_dump_close(void);
    


## HCI Transport API {#sec:hciTransportAPIAppendix}

    
    /* HCI packet types */
    typedef struct {
        /**
         * transport name 
         */
        const char * name;
    
        /**
         * init transport
         * @param transport_config
         */
        void   (*init) (const void *transport_config);
    
        /**
         * open transport connection
         */
        int    (*open)(void);
    
        /**
         * close transport connection
         */
        int    (*close)(void);
    
        /**
         * register packet handler for HCI packets: ACL, SCO, and Events
         */
        void   (*register_packet_handler)(void (*handler)(uint8_t packet_type, uint8_t *packet, uint16_t size));
    
        /**
         * support async transport layers, e.g. IRQ driven without buffers
         */
        int    (*can_send_packet_now)(uint8_t packet_type);
    
        /**
         * send packet
         */
        int    (*send_packet)(uint8_t packet_type, uint8_t *packet, int size);
    
        /**
         * extension for UART transport implementations
         */
        int    (*set_baudrate)(uint32_t baudrate);
    
        /**
         * extension for UART H5 on CSR: reset BCSP/H5 Link
         */
        void   (*reset_link)(void);
    
        /**
         * extension for USB transport implementations: config SCO connections
         */
        void   (*set_sco_config)(uint16_t voice_setting, int num_connections);
    
    } hci_transport_t;
    
    typedef enum {
        HCI_TRANSPORT_CONFIG_UART,
        HCI_TRANSPORT_CONFIG_USB
    } hci_transport_config_type_t;
    
    typedef struct {
        hci_transport_config_type_t type;
    } hci_transport_config_t;
    
    typedef struct {
        hci_transport_config_type_t type; // == HCI_TRANSPORT_CONFIG_UART
        uint32_t   baudrate_init; // initial baud rate
        uint32_t   baudrate_main; // = 0: same as initial baudrate
        int        flowcontrol;   // 
        const char *device_name;
    } hci_transport_config_uart_t;
    
    
    // inline various hci_transport_X.h files
    
    /*
     * @brief Setup H4 instance with uart_driver
     * @param uart_driver to use 
     */
    const hci_transport_t * hci_transport_h4_instance(const btstack_uart_block_t * uart_driver);
    
    /*
     * @brief Setup H5 instance with uart_driver
     * @param uart_driver to use 
     */
    const hci_transport_t * hci_transport_h5_instance(const btstack_uart_block_t * uart_driver);
    
    /*
     * @brief Enable H5 Low Power Mode: enter sleep mode after x ms of inactivity
     * @param inactivity_timeout_ms or 0 for off
     */
    void hci_transport_h5_set_auto_sleep(uint16_t inactivity_timeout_ms);
    
    /*
     * @brief Enable BSCP mode H5, by enabling event parity
     */
    void hci_transport_h5_enable_bcsp_mode(void);
    
    /*
     * @brief
     */
    const hci_transport_t * hci_transport_usb_instance(void);
    
    /**
     * @brief Specify USB Bluetooth device via port numbers from root to device
     */
    void hci_transport_usb_set_path(int len, uint8_t * port_numbers);
    


## L2CAP API {#sec:l2capAPIAppendix}

    
    /** 
     * @brief Set up L2CAP and register L2CAP with HCI layer.
     */
    void l2cap_init(void);
    
    /** 
     * @brief Registers packet handler for LE Connection Parameter Update events
     */
    void l2cap_register_packet_handler(void (*handler)(uint8_t packet_type, uint16_t channel, uint8_t *packet, uint16_t size));
    
    /** 
     * @brief Get max MTU for Classic connections based on btstack configuration
     */
    uint16_t l2cap_max_mtu(void);
    
    /** 
     * @brief Get max MTU for LE connections based on btstack configuration
     */
    uint16_t l2cap_max_le_mtu(void);
    
    /** 
     * @brief Creates L2CAP channel to the PSM of a remote device with baseband address. A new baseband connection will be initiated if necessary.
     * @param packet_handler
     * @param address
     * @param psm
     * @param mtu
     * @param local_cid
     * @return status
     */
    uint8_t l2cap_create_channel(btstack_packet_handler_t packet_handler, bd_addr_t address, uint16_t psm, uint16_t mtu, uint16_t * out_local_cid);
    
    /** 
     * @brief Creates L2CAP channel to the PSM of a remote device with baseband address using Enhanced Retransmission Mode. 
     *        A new baseband connection will be initiated if necessary.
     * @param packet_handler
     * @param address
     * @param psm
     * @param ertm_config
     * @param buffer to store reassembled rx packet, out-of-order packets and unacknowledged outgoing packets with their tretransmission timers
     * @param size of buffer
     * @param local_cid
     * @return status
     */
    uint8_t l2cap_create_ertm_channel(btstack_packet_handler_t packet_handler, bd_addr_t address, uint16_t psm, 
        l2cap_ertm_config_t * ertm_contig, uint8_t * buffer, uint32_t size, uint16_t * out_local_cid);
    
    /** 
     * @brief Disconnects L2CAP channel with given identifier. 
     */
    void l2cap_disconnect(uint16_t local_cid, uint8_t reason);
    
    /** 
     * @brief Queries the maximal transfer unit (MTU) for L2CAP channel with given identifier. 
     */
    uint16_t l2cap_get_remote_mtu_for_local_cid(uint16_t local_cid);
    
    /** 
     * @brief Sends L2CAP data packet to the channel with given identifier.
     */
    int l2cap_send(uint16_t local_cid, uint8_t *data, uint16_t len);
    
    /** 
     * @brief Registers L2CAP service with given PSM and MTU, and assigns a packet handler.
     */
    uint8_t l2cap_register_service(btstack_packet_handler_t packet_handler, uint16_t psm, uint16_t mtu, gap_security_level_t security_level);
    
    /** 
     * @brief Unregisters L2CAP service with given PSM.
     */
    uint8_t l2cap_unregister_service(uint16_t psm);
    
    /** 
     * @brief Accepts incoming L2CAP connection.
     */
    void l2cap_accept_connection(uint16_t local_cid);
    
    /** 
     * @brief Accepts incoming L2CAP connection for Enhanced Retransmission Mode
     * @param local_cid
     * @param ertm_config
     * @param buffer to store reassembled rx packet, out-of-order packets and unacknowledged outgoing packets with their tretransmission timers
     * @param size of buffer
     * @return status
     */
    uint8_t l2cap_accept_ertm_connection(uint16_t local_cid, l2cap_ertm_config_t * ertm_contig, uint8_t * buffer, uint32_t size);
    
    /** 
     * @brief Deny incoming L2CAP connection.
     */
    void l2cap_decline_connection(uint16_t local_cid);
    
    /** 
     * @brief Check if outgoing buffer is available and that there's space on the Bluetooth module
     */
    int  l2cap_can_send_packet_now(uint16_t local_cid);    
    
    /** 
     * @brief Request emission of L2CAP_EVENT_CAN_SEND_NOW as soon as possible
     * @note L2CAP_EVENT_CAN_SEND_NOW might be emitted during call to this function
     *       so packet handler should be ready to handle it
     * @param local_cid
     */
    void l2cap_request_can_send_now_event(uint16_t local_cid);
    
    /** 
     * @brief Reserve outgoing buffer
     */
    int  l2cap_reserve_packet_buffer(void);
    
    /** 
     * @brief Get outgoing buffer and prepare data.
     */
    uint8_t *l2cap_get_outgoing_buffer(void);
    
    /** 
     * @brief Send L2CAP packet prepared in outgoing buffer to channel
     */
    int l2cap_send_prepared(uint16_t local_cid, uint16_t len);
    
    /** 
     * @brief Release outgoing buffer (only needed if l2cap_send_prepared is not called)
     */
    void l2cap_release_packet_buffer(void);
    
    
    //
    // LE Connection Oriented Channels feature with the LE Credit Based Flow Control Mode == LE Data Channel
    //
    
    
    /**
     * @brief Register L2CAP LE Data Channel service
     * @note MTU and initial credits are specified in l2cap_le_accept_connection(..) call
     * @param packet_handler
     * @param psm
     * @param security_level
     */
    uint8_t l2cap_le_register_service(btstack_packet_handler_t packet_handler, uint16_t psm, gap_security_level_t security_level);
    
    /**
     * @brief Unregister L2CAP LE Data Channel service
     * @param psm
     */
    
    uint8_t l2cap_le_unregister_service(uint16_t psm);
    
    /*
     * @brief Accept incoming LE Data Channel connection
     * @param local_cid             L2CAP LE Data Channel Identifier
     * @param receive_buffer        buffer used for reassembly of L2CAP LE Information Frames into service data unit (SDU) with given MTU
     * @param receive_buffer_size   buffer size equals MTU
     * @param initial_credits       Number of initial credits provided to peer or L2CAP_LE_AUTOMATIC_CREDITS to enable automatic credits
     */
    
    uint8_t l2cap_le_accept_connection(uint16_t local_cid, uint8_t * receive_sdu_buffer, uint16_t mtu, uint16_t initial_credits);
    
    /** 
     * @brief Deny incoming LE Data Channel connection due to resource constraints
     * @param local_cid             L2CAP LE Data Channel Identifier
     */
    
    uint8_t l2cap_le_decline_connection(uint16_t local_cid);
    
    /**
     * @brief Create LE Data Channel
     * @param packet_handler        Packet handler for this connection
     * @param con_handle            ACL-LE HCI Connction Handle
     * @param psm                   Service PSM to connect to
     * @param receive_buffer        buffer used for reassembly of L2CAP LE Information Frames into service data unit (SDU) with given MTU
     * @param receive_buffer_size   buffer size equals MTU
     * @param initial_credits       Number of initial credits provided to peer or L2CAP_LE_AUTOMATIC_CREDITS to enable automatic credits
     * @param security_level        Minimum required security level
     * @param out_local_cid         L2CAP LE Channel Identifier is stored here
     */
    uint8_t l2cap_le_create_channel(btstack_packet_handler_t packet_handler, hci_con_handle_t con_handle, 
        uint16_t psm, uint8_t * receive_sdu_buffer, uint16_t mtu, uint16_t initial_credits, gap_security_level_t security_level,
        uint16_t * out_local_cid);
    
    /**
     * @brief Provide credtis for LE Data Channel
     * @param local_cid             L2CAP LE Data Channel Identifier
     * @param credits               Number additional credits for peer
     */
    uint8_t l2cap_le_provide_credits(uint16_t cid, uint16_t credits);
    
    /**
     * @brief Check if packet can be scheduled for transmission
     * @param local_cid             L2CAP LE Data Channel Identifier
     */
    int l2cap_le_can_send_now(uint16_t cid);
    
    /**
     * @brief Request emission of L2CAP_EVENT_LE_CAN_SEND_NOW as soon as possible
     * @note L2CAP_EVENT_CAN_SEND_NOW might be emitted during call to this function
     *       so packet handler should be ready to handle it
     * @param local_cid             L2CAP LE Data Channel Identifier
     */
    uint8_t l2cap_le_request_can_send_now_event(uint16_t cid);
    
    /**
     * @brief Send data via LE Data Channel
     * @note Since data larger then the maximum PDU needs to be segmented into multiple PDUs, data needs to stay valid until ... event
     * @param local_cid             L2CAP LE Data Channel Identifier
     * @param data                  data to send
     * @param size                  data size
     */
    uint8_t l2cap_le_send_data(uint16_t cid, uint8_t * data, uint16_t size);
    
    /**
     * @brief Disconnect from LE Data Channel
     * @param local_cid             L2CAP LE Data Channel Identifier
     */
    uint8_t l2cap_le_disconnect(uint16_t cid);
    
