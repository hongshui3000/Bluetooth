package com.bluekitchen.btstack;

public interface PacketHandler {
	void handlePacket(Packet packet);
}
